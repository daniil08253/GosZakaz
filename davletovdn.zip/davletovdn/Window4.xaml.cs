﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace davletovdn
{
    /// <summary>
    /// Логика взаимодействия для Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        public Window4()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Hide();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            
            Window1 window1 = new Window1();
            DB.db.Student.Add(new Student
            {
                Зачетка = ЗачеткаBox.Text,
                Фамилия = ФамилияBox.Text,
                Имя = ИмяBox.Text,
                Отчество = ОтчествоBox.Text,
                Группа = ГруппаBox.Text,
                Факультет = ФамилияBox.Text,
                Курс = КурсBox.Text,
                
            });
            DB.db.SaveChanges();
            MessageBox.Show("Готово, обновите");
            window1.Table.ItemsSource = DB.db.Student.ToList();

        }
    }
}
