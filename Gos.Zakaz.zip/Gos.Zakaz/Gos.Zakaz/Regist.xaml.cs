﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Gos.Zakaz
{
    /// <summary>
    /// Логика взаимодействия для Regist.xaml
    /// </summary>
    public partial class Regist : Window
    {
        public Regist()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            if (pass.Password == "")
            {
                pass.Background = Brushes.Red;
                MessageBox.Show("Заполните пароль", "Государственый заказ по Челябинской Области", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            if (Login.Text == "")
            {
                Login.Background = Brushes.Red;
                MessageBox.Show("Заполните логин", "Государственый заказ по Челябинской Области", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            if (Login.Text == "" && pass.Password == "")
            {
                Login.Background = Brushes.Red;
                pass.Background = Brushes.Red;
                MessageBox.Show("Заполните логин и пароль", "Государственый заказ по Челябинской Области", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }
    }
}
