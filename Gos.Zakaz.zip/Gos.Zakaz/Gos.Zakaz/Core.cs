﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Gos.Zakaz
{
    class Core
    {
        public static MySqlConnection mySql = new MySqlConnection("server=localhost;user=root;password=admin;databases=гос.заказ.челяб");
    }
}
