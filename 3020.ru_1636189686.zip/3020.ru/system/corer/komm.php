<?php
class komm {

	public function kammid(int $id): void {
		global $usemi,$user,$functions;
		$dell = NULL;
		$komm = DB::$dbs->queryFetch('SELECT idus,id,message,time,images,repost,zakrep,url,repostchto,messageobr,ids,chto FROM komm WHERE id = ? LIMIT 1', [$id]);
		switch (isset($komm['chto'])) {
			case $komm['chto'] == 'user':
				$qqq = DB::$dbs->queryFetch('SELECT id FROM user WHERE id = ? LIMIT 1', [$komm['ids']]);
				if(isset($user['id']) and ($user['id'] == $qqq['id'] or $komm['idus'] == $user['id'])) {
					$dell = '<span title="Удалить комментарий" onclick="fawd3thwe9g(\'/ajs/dellkomm/'.$komm['id'].'/\');">Удалить</span> | ';
				}
			break;
			case $komm['chto'] == 'photo':
				$qqq = DB::$dbs->queryFetch('SELECT id,idus FROM photo WHERE id = ? LIMIT 1', [$komm['ids']]);
				if(isset($user['id']) and ($user['id'] == $qqq['idus'] or $komm['idus'] == $user['id'])) {
					$dell = '<span title="Удалить комментарий" onclick="fawd3thwe9g(\'/ajs/dellkomm/'.$komm['id'].'/\');">Удалить</span> | ';
				}
			break;
			case $komm['chto'] == 'uservideo':
				$qqq = DB::$dbs->queryFetch('SELECT id,idus FROM video_us WHERE id = ? LIMIT 1', [$komm['ids']]);
				if(isset($user['id']) and ($user['id'] == $qqq['idus'] or $komm['idus'] == $user['id'])) {
					$dell = '<span title="Удалить комментарий" onclick="fawd3thwe9g(\'/ajs/dellkomm/'.$komm['id'].'/\');">Удалить</span> | ';
				}
			break;
			case $komm['chto'] == 'userwallkomm':
				$wall = DB::$dbs->queryFetch('SELECT id,idus,ids FROM komm WHERE id = ? LIMIT 1', [$komm['ids']]);
				$qqq = DB::$dbs->queryFetch('SELECT id FROM user WHERE id = ? LIMIT 1', [$wall['ids']]);
				if(isset($user['id']) and ($user['id'] == $qqq['id'] or $komm['idus'] == $user['id'])) {
					$dell = '<span title="Удалить комментарий" onclick="fawd3thwe9g(\'/ajs/dellkomm/'.$komm['id'].'/\');">Удалить</span> | ';
				}
			break;
			case $komm['chto'] == 'usernotes':
				$qqq = DB::$dbs->queryFetch('SELECT id,idus FROM notes WHERE id = ? LIMIT 1', [$komm['ids']]);
				if(isset($user['id']) and ($user['id'] == $qqq['idus'] or $komm['idus'] == $user['id'])) {
					$dell = '<span title="Удалить комментарий" onclick="fawd3thwe9g(\'/ajs/dellkomm/'.$komm['id'].'/\');">Удалить</span> | ';
				}
			break;
			default:
				exit('Не известный раздел еомментария.');
			break;
		}
		/// ?>
		<div class="row _postes _postes2" id="posts_<?php echo $komm['id'];?>">
			<div class="cs6">
				<?php echo $usemi->avas(['id' => $komm['idus'], 'mini' => 1, 'url' => 1]); ?>
			</div>
			<div class="col">
				<div class="_0q3j8guyr9w8g">
					<div class="_jfjw84guyiu"><span><?php echo $usemi->logins(['id' => $komm['idus'], 'name' => 3, 'url' => 1]);?></span> <?php echo isset($komm['repost']) ? 'поделился' : NULL;?></div>
				</div>
				<?php echo isset($komm['message']) ? '<div class="_textdaw3tg4r">'.(isset($komm['messageobr']) ? '<span id="text_id'.$komm['id'].'">'.nl2br($komm['messageobr']).'</span><div class="_fajw8f39tggh9" onclick="$(this).remove();$(\'#text_id'.$komm['id'].'\').remove();$(\'#text_idshow'.$komm['id'].'\').css({display:\'block\'});">показать полностью..</div><div id="text_idshow'.$komm['id'].'" style="display:none;">'.nl2br($komm['message']).'</div>' : nl2br($komm['message'])).'</div>' : NULL;
				if(isset($komm['images']) and empty($komm['repostchto'])) {
					$photo = DB::$dbs->queryFetch('SELECT id,photo FROM photo WHERE id = ? LIMIT 1', [$komm['images']]);
					if(isset($photo['id'])): ?>
						<div class="_imageaswfa83"><img src="<?php echo CDN;?>/photo/<?php echo $photo['photo'];?>"></div>
					<?php endif;
				}
				if($komm['chto'] == 'user') { // если стена пользователя то показываем репосты
					switch ($komm['repostchto']) {
						/// репост комментариев
						case 'komm':
							echo self::idcomm(['id' => $komm['repost']]);
						break;
						/// репост фотографии
						case 'photo':
							$photo = DB::$dbs->queryFetch('SELECT id,photo,idus,time FROM photo WHERE id = ? LIMIT 1', [$komm['repost']]); 
							if(isset($photo['id'])): ?>
								<div class="row _postes _postes3" id="posts_<?php echo $komm['id'];?>">
									<div class="cs6 _e8gh9ghffg0">
										<?php echo $usemi->avas(['id' => $photo['idus'], 'mini' => 1, 'url' => 1]);?>
									</div>
									<div class="col">
										<div class="_0q3j8guyr9w8g _wjd83t98gh9rhg9">
											<div class="_jfjw84guyiu"><span><img src="/style/images/published.gif"><?php echo $usemi->logins(['id' => $photo['idus'], 'name' => 3, 'url' => 1]);?></span> опубликовал</div>
											<div class="_timefjfaw39"><a href="<?php echo DOMAIN2;?>/<?php echo $komm['url'];?>"><?php echo $functions->times($photo['time']);?></a></div>
										</div>
										<div class="_textdaw3tg4r"><img src="<?php echo CDN;?>/photo/<?php echo $photo['photo'];?>"></div>
									</div>
								</div>
							<?php else: ?>
								<div class="_textdaw3tg4r">Фото удалено!</div>
							<?php endif;
						break;
						/// Репост видео
						case 'video':
							$video = DB::$dbs->queryFetch('SELECT id,url,idus,time,imag FROM video WHERE id = ? LIMIT 1', [$komm['repost']]);
							if(isset($video['id'])): ?>
								<div class="row _postes _postes3" id="posts_<?php echo $komm['id'];?>">
									<div class="cs6 _e8gh9ghffg0">
										<?php echo $usemi->avas(['id' => $video['idus'], 'mini' => 1, 'url' => 1]);?>
									</div>
									<div class="col">
										<div class="_0q3j8guyr9w8g _wjd83t98gh9rhg9">
											<div class="_jfjw84guyiu"><span><img src="/style/images/published.gif"><?php echo $usemi->logins(['id' => $video['idus'], 'name' => 3, 'url' => 1]);?></span> опубликовал</div>
											<div class="_timefjfaw39"><a href="<?php echo DOMAIN2;?>/<?php echo $komm['url'];?>"><?php echo $functions->times($video['time']);?></a></div>
										</div>
										<div id="video_id<?php echo $video['id'];?>" class="_textdaw3tg4r _fr38qtq8g8ef8w"><span>Запустить</span><img onclick="autoPlayVideoYo('<?php echo $video['id'];?>','<?php echo $video['url'];?>','100%','140px');" class="_f0tg8084w0h48ghw8" src="<?php echo CDN;?>/video/<?php echo $video['imag'];?>"></div>
									</div>
								</div>
							<?php else: ?>
								<div class="_textdaw3tg4r">Видео удалено!</div>
							<?php endif;
						break;
					}
				} ?>
				<div class="_gwef84hg9dwef"><?php echo $functions->times($komm['time']);?></div>
				<?php $repas = DB::$dbs->querySingle('SELECT COUNT(id) FROM komm WHERE repost = ?',[$komm['id']]) > 0 ? '('.DB::$dbs->querySingle('SELECT COUNT(id) FROM komm WHERE repost = ?',[$komm['id']]).')' : NULL;
				$kommes = DB::$dbs->querySingle('SELECT COUNT(id) FROM komm WHERE ids = ? and chto = ?',[$komm['id'],'userwallkomm']) > 0 ? '('.DB::$dbs->querySingle('SELECT COUNT(id) FROM komm WHERE ids = ? and chto = ?',[$komm['id'],'userwallkomm']).')' : NULL; 
				?>
				<div class="_3qghr9gh9w4h9">
					<?php if(isset($user['id'])) {
						echo $dell; ?><span onclick="return false;" href="/ajs/pr/repost/komm/<?php echo $komm['id'];?>/" class="_dawd021hhwggh">Поделиться <?php echo $repas;?></span> | <?php echo $komm['chto'] == 'user' ? '<a href="'.DOMAIN2.'/wall'.$komm['ids'].'_'.$komm['id'].'">Комментарии '.$kommes.'</a>' : '<span>Ответить</span>';
					} else { ?>
						<span class="_dawd021hhwggh">Поделиться <?php echo $repas;?></span><?php echo $komm['chto'] == 'user' ? '<a href="'.DOMAIN2.'/wall'.$komm['ids'].'_'.$komm['id'].'"> | Комментарии '.$kommes.'</a>' : NULL;?>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php	
		///
	}


	public function kommes($opt = []): void
	{
		global $usemi,$user,$functions;
		if(DB::$dbs->querySingle('SELECT COUNT(id) FROM komm WHERE ids = ? and chto = ?',[$opt['id'],$opt['chto']]) == 0) { ?>
			<div style="padding: 0 10px;text-align: center;">Пока нет сообщений</div>
		<?php } else {
			////
			$sql1 = DB::$dbs->querySql('SELECT id FROM komm WHERE ids = ? and chto = ? ORDER BY zakrep DESC, time DESC LIMIT 10',[$opt['id'],$opt['chto']])->fetchAll(PDO::FETCH_ASSOC);
			foreach ($sql1 as $sqlls => $komm) { 
				echo self::kammid($komm['id']);
			}
		}
	}
	
	public function idcomm($opt = []): void
	{
		global $usemi,$user,$functions;
		$komm = DB::$dbs->queryFetch('SELECT idus,id,message,time,images,url,messageobr FROM komm WHERE id = ? LIMIT 1', [$opt['id']]);
		if(isset($komm['id'])) { ?>
		<div class="row _postes _postes3" id="posts_<?php echo $komm['id'];?>">
			<div class="cs6 _e8gh9ghffg0">
				<?php echo $usemi->avas(['id' => $komm['idus'], 'mini' => 1, 'url' => 1]);?>
			</div>
			<div class="col">
				<div class="_0q3j8guyr9w8g _wjd83t98gh9rhg9">
					<div class="_jfjw84guyiu"><span><img src="/style/images/published.gif"><?php echo $usemi->logins(['id' => $komm['idus'], 'name' => 3, 'url' => 1]);?></span> написал</div>
					<div class="_timefjfaw39"><a href="<?php echo DOMAIN2;?>/<?php echo $komm['url'];?>"><?php echo $functions->times($komm['time']);?></a></div>
				</div>
				<?php echo isset($komm['message']) ? '<div class="_textdaw3tg4r">'.(isset($komm['messageobr']) ? '<span id="text_id'.$komm['id'].'">'.nl2br($komm['messageobr']).'</span><div class="_fajw8f39tggh9" onclick="$(this).remove();$(\'#text_id'.$komm['id'].'\').remove();$(\'#text_idshow'.$komm['id'].'\').css({display:\'block\'});">показать полностью..</div><div id="text_idshow'.$komm['id'].'" style="display:none;">'.nl2br($komm['message']).'</div>' : nl2br($komm['message'])).'</div>' : NULL;
				if(isset($komm['images'])):
					$photo = DB::$dbs->queryFetch('SELECT id,photo FROM photo WHERE id = ? LIMIT 1', [$komm['images']]);
					if(empty($photo['id'])): else: ?>
						<div class="_imageaswfa83"><img src="<?php echo CDN;?>/photo/m/<?php echo $photo['photo'];?>"></div>
					<?php endif;
				endif; ?>
			</div>
		</div>
		<?php } else { ?>
			<div class="_foie9fh39ur0"><span class="material-icons"> info </span>Удалено</div>
		<?php }
	}

	public function aktivkomm($opt = []): void 
	{ ?>
		<div class="_f0rt9ug80wu00j" onfocusin="expand_wall_textarea();">
			<form action="" id="ajax_form" method="post" enctype="multipart/form-data" style="margin:0;" onsubmit="return false;">
				<input type="file" class="postFileSel" id="postFilePic" name="file" accept="image/*" style="display:none;">
				<textarea onkeyup="this.style.height = '1px';this.style.height = (this.scrollHeight + 6) + 'px';" class="_jf08g8w489wgri" id="wall-post-input" placeholder="Написать" name="text" style="width: 100%;resize: none;" class="expanded-textarea"></textarea>
				<div id="post-buttons" style="display: none;">
					<div class="post-upload">
							Вложение: <span>(unknown)</span>
					</div>
					<input onclick="saveform ('/ajs/addkomm/<?php echo $opt['chto'];?>/<?php echo $opt['id'];?>/','#ajax_form');return false;" type="submit" value="Написать" class="button">
					<div class="_fja08th4398tgj" class="hidden">
						<a onclick="$('._j0f8grhg94w9g').toggleClass('hidden'); return false;" href="">
								Прикрепить
						</a>
						<div class="_j0f8grhg94w9g hidden">
							<span onclick="document.querySelector('input[name=file]').click();">
								Прикрепить фото
							</span>
							<span class="_graffitys">
								Прикрепить графити
							</span>
						</div>
					</div>
				</div>
			</form>
		</div>
	<?php }
}


