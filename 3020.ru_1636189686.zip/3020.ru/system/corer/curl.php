<?php class curl {
	// 3020.ru - скрипты тут
	// тута cdn 
	public function curlload($arr = [], $dir = NULL) {
		$ch = curl_init('https://адресс/upload.php?dir='.$dir);  
		curl_setopt($ch, CURLOPT_POST, 1);  
		curl_setopt($ch, CURLOPT_POSTFIELDS, $arr);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HEADER, false);
		$res = curl_exec($ch);
		curl_close($ch);
		return json_decode($res);
	}
	public function delete($dir = NULL) {
		$ch = curl_init('https://адресс/delete.php?dir='.$dir);  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
		curl_setopt($ch, CURLOPT_POST, 1);
		$res = curl_exec($ch);
		curl_close($ch);
		return json_decode($res);
	}
}