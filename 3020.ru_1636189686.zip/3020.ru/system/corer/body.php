<?php
class Body{             
	private $title = 'Накрутка в социальных сетях подписчиков и лайков бесплатно'; 
	private $description = '⭐ Бесплатная накрутка лайков в социальных сетях. Накрутка подписчиков, просмотров и комментариев. Быстро, безопасно, без блокировок.';
	private $keywords = '';
	private $hais = '';
	// вывод титл
	public function SetTitle ($param) {
		return $this->title = $param;   
	}
	// вывод верха
	public function SetHais ($param) {
		return $this->hais = $param;   
	}
	// вывод дескриптион
	public function SetDescription ($param) {
		return $this->description = $param; 
	}   
	// вывод ключей
	public function SetKeywords ($param) {
		return $this->keywords = $param;    
	}
	// Настройка верха сайта
	public function GetHeader($opt = []) {
		global $functions,$user;
		?>
	 	<!DOCTYPE html>
		<html lang="ru">
			<head>
				<meta charset="utf-8" />
				<meta name="viewport" content="width=device-width, initial-scale=1" />
				<link rel="preconnect" href="//fonts.gstatic.com" crossorigin />
				<link rel="preconnect" href="//fonts.googleapis.com" crossorigin />
				<link rel="preconnect" href="//cdn.wiq.su" crossorigin />
				<link rel="stylesheet" href="/style/css/style.css?v=<?php echo time();?>" />
				<link rel="shortcut icon" href="/style/images/favicon.ico" />
				<link href="//fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
				<title><?php echo $this->title;?></title>
			</head>
			<body class="<?php echo isset($user['id']) ? '_while' : '_while';?>">
				
				<audio><source></audio>
				<div class="dimmer"></div>
				<header>
					<div class="container">
						<div class="row _header">
							<div class="cs7 _logos">
								VKphp
							</div>
							<div class="col">
								<ul class="_navtops">
									<?php if(isset($user['id'])): ?>
										<li><a href="">Группы</a></li><li><a href="">Поддержать</a></li><li><a href="">Поиск</a></li><li><a href="">Помощь</a></li><li><a href="">Выйти</a></li>
									<?php else: ?>
										<li><a href="<?php echo DOMAIN2;?>/aut/">Вход</a></li><li><a href="<?php echo DOMAIN2;?>/reg/">Регистрация</a></li><li><a href="">Помощь</a></li>
									<?php endif; ?>  
								</ul>
							</div>
						</div>
					</div>
				</header>
				<main class="container">
					<div class="row">
						<?php if(isset($user['id'])):?>
							<div class="cs2 _dwa8du73yf">
								<ul class="_navuser">
									<span class="_09eug8ruggu"><a href="<?php echo DOMAIN2;?>/red/osn/">ред</a></span>
									<li><a href="<?php echo DOMAIN2;?>/<?php echo $user['url'];?>">Моя страница</a></li>
									<li><a href="<?php echo DOMAIN2;?>/friends<?php echo $user['id'];?>">Мои друзья <?php echo ((DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE cogo = ?',[$user['id']]) > 0) ? '<strong>('.DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE cogo = ?',[$user['id']]).')</strong>' : NULL);?></a></li>
									<li><a href="<?php echo DOMAIN2;?>/albums<?php echo $user['id'];?>">Мои фотографии</a></li>
									<li><a href="<?php echo DOMAIN2;?>/video<?php echo $user['id'];?>">Мои видеозаписи</a></li>
									<li><a href="<?php echo DOMAIN2;?>/audio<?php echo $user['id'];?>">Мои аудиозаписи</a></li>
									<li><a href="<?php echo DOMAIN2;?>/notes<?php echo $user['id'];?>">Мои заметки</a></li>
									<li><a href="<?php echo DOMAIN2;?>/audio<?php echo $user['id'];?>">Мои группы</a></li>
									<li><a href="<?php echo DOMAIN2;?>/audio<?php echo $user['id'];?>">Мои новости</a></li>
									<li><a href="<?php echo DOMAIN2;?>/audio<?php echo $user['id'];?>">Мои ответы</a></li>
									<li><a href="<?php echo DOMAIN2;?>/settings">Мои настройки</a></li>
								</ul>
							</div>
						<?php else: ?>
							<div class="cs2 _dwa8du73yf">
								<form class="_formautsda" id="ajax_form2" action="" method="post" onsubmit="return false;">
									<div class="_rfuifh3478">
										<div class="_nameadf">Электронная почта:</div>
										<input class="_ijaowidj4378t9" type="text" maxlength="100" name="email" value="" placeholder="Email">
									</div>
									<div class="_rfuifh3478">
										<div class="_nameadf">Пароль:</div>
										<input class="_ijaowidj4378t9" type="password" maxlength="100" name="password" value="" placeholder="Password">
									</div>
									<div class="">
										<div><input onclick="saveform ('/ajs/aut/','#ajax_form2');return false;" class="_30tuq8euf9ufgw _t8uyr89gy38yg" type="submit" name="add" value="Авторизация"></div>
									</div>
									<div style="margin-top: 10px;"><a href="">Забыли пароль?</a></div>
								</form>
							</div>	
						<?php endif; 
						/*<div><a href="<?php echo DOMAIN2;?>/reg/" class="_30tuq8euf9ufgw _t8uyr89gy38yg">Регистрация</a></div>
						*/?>
						<div class="col">
							<div class="_83u98dwyh8d">
								<div id="oshhb"></div>
								<div id="content">
									<div class="_titler"><?php echo $this->hais;?></div>
		<?php
	}
	public function GetFooter($opt = []) {
		global $generrat,$user; 
		/* Gen: <?php echo round((float) microtime() - $generrat, 4);?> |  */?>
									<?php if(isset($user['id']) and $user['id'] == 1): ?>
										<script rel="preload" defer src="<?php echo DOMAIN2;?>/style/js/umbrella.min.js"></script>
										<script rel="preload" defer src="<?php echo DOMAIN2;?>/style/js/al_wall1995s.js?id=<?php echo time();?>"></script>
									<?php else: ?>
										<script rel="preload" defer src="<?php echo DOMAIN2;?>/style/js/umbrella.min.js"></script>
										<script rel="preload" defer src="<?php echo DOMAIN2;?>/style/js/al_wall.js?id=<?php echo time();?>"></script>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
					<div class="_asf3qt8ghr99h">
						<div class="_rfwifh3899ffw">
							<div class="_0wafj83htg098r">
							<div class="_0ifwt89g9rg9rge" id="play" onclick="dellMusic();"><span class="material-icons">close</span></div>
							</div>
							<div style="" class="_asf3qt8ghr99h-bars"><div class="_asf3qt8ghr99h-bar"></div></div>
							<div style="width: 10%;" id="_asf3qt8ghr99h-play"></div>
							<div class="_idawidwadh73f9uh"></div>
							<div id="timer"></div>
							<div class="_goplay" id="2"></div>
						</div>
						
					</div>
				</main>
				<footer class="container">
					<div class="row">
						<div class="cs1"></div>
						<div class="col _footersdw">
							<a href="">Блог</a><a href="">Помощь</a><a href="">Выбрать язык</a><a href="">Приватность</a>
							<div style="margin-top: 20px;font-size: 15px;">
								PHP: 8.1</div>
							</div>
						</div>
					</div>
				</footer>
				<script src="<?php echo DOMAIN2;?>/style/js/jquery-3.6.0.min.js"></script>
				<?php if(isset($user['id']) and $user['id'] == 1): ?>
					<script src="<?php echo DOMAIN2;?>/style/js/js1995s.js?id=<?php echo time();?>"></script>
					<script src="<?php echo DOMAIN2;?>/style/js/player1995s.js?id=<?php echo time();?>"></script>
				<?php else: ?>
					<script src="<?php echo DOMAIN2;?>/style/js/js.js?id=<?php echo time();?>"></script>
					<script src="<?php echo DOMAIN2;?>/style/js/player.js?id=<?php echo time();?>"></script>
				<?php endif; ?>
				
			</body>
		</html>
		<?php
	}
}
?>