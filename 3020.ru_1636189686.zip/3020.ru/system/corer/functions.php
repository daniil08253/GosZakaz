<?php
class functions {
	//функция фильтрации текста лучшая
	public function htmlred($var) {
		return trim(htmlspecialchars($var, ENT_QUOTES, 'UTF-8'));
	}
	//функция фильтрации чисел вынес в отдельую что бы модить потом
	public function ints(int $var) {
		return filter_var($var, FILTER_VALIDATE_INT);
	}
	public function randdj8iad(int $var) {
		$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyz';
		return substr(str_shuffle($permitted_chars), 0, $var);
	}
	public function validateDate($date, $format = 'Y-m-d H:i:s') {
		$d = DateTime::createFromFormat($format, $date);
		return $d && $d->format($format) == $date;
	}
	/// Склонение
	function slv($num, $titles): string
	{
		$cases = [2, 0, 1, 1, 1, 2];
    return $num.' '.$titles[($num % 100 > 4 && $num % 100 < 20) ? 2 : $cases[min($num % 10, 5)]];
	}
	// функция со временем
	function times(int $time): string
	{ 
		switch (date('j n Y', $time)) {
			case date('j n Y'): 
				return 'Сегодня в ' . date('H:i', $time) .''; 
			break;

			case date('j n Y', $_SERVER['REQUEST_TIME'] - 86400): 
				return 'Вчера в ' . date('H:i', $time).''; 
			break;

			default: 
				return strtr(date('j M Y', $time), ['Jan' => 'Янв', 
				'Feb' => 'Фев', 
				'Mar' => 'Марта', 
				'Apr' => 'Апр', 
				'May' => 'Мая', 
				'Jun' => 'Июня', 
				'Jul' => 'Июля', 
				'Aug' => 'Авг', 
				'Sep' => 'Сент', 
				'Oct' => 'Октября', 
				'Nov' => 'Ноя', 
				'Dec' => 'Дек']); 
			break; 
		}
	}
	// Функция ресайза изображений
	public static function img_resize($src, $dest, $width, $height, $rgb=0xFFFFFF, $quality=100) {
		if (!file_exists($src)) return false;
		$size = getimagesize($src);
		if ($size === false) return false;
		$format = strtolower(substr($size['mime'], strpos($size['mime'], '/')+1));
		$icfunc = "imagecreatefrom" . $format;
		if (!function_exists($icfunc)) return false;
		$x_ratio = $width / $size[0];
		$y_ratio = $height / $size[1];
		$ratio = min($x_ratio, $y_ratio);
		$use_x_ratio = false;   //($x_ratio == $ratio);
		$new_width = !$use_x_ratio  ? $width  : floor($size[0] * $ratio);
		$new_height = !$use_x_ratio ? $height : floor($size[1] * $ratio);
		$new_left = $use_x_ratio ? 0 : floor(($width - $new_width) / 2);
		$new_top = !$use_x_ratio ? 0 : floor(($height - $new_height) / 2);
		$isrc = $icfunc($src);
		$idest = imagecreatetruecolor($width, $height);
		imagefill($idest, 0, 0, $rgb);
		imagecopyresampled($idest, $isrc, $new_left, $new_top, 0, 0, $new_width+1, $new_height, $size[0], $size[1]);
		imageJPEG($idest, $dest, $quality);
		imagedestroy($isrc);
		imagedestroy($idest);
		return true;
	}
	// Ссылка для ютьюб что бы получить ид видео
	public function getYouTubeVideoID($url) {
		$os = ['youtube.com', 'youtu.be', 'www.youtube.com'];
		$name = parse_url($url, PHP_URL_HOST);
		if (in_array($name, $os)) {
			if ($name == 'youtu.be') {
				$pieces = explode('/', $url);
				$fas = $pieces[3];
			} else {
				$queryString = parse_url($url, PHP_URL_QUERY);
				parse_str($queryString, $params);
				if (isset($params['v']) && strlen($params['v']) > 0) {
					$fas = $params['v'];
				} else {
					$fas = FALSE;
				}
			}
		} else {
			$fas = FALSE;
		}
		return $fas;
	}
	// Обрезаем текст
	public function wph_cut_by_words($maxlen, $text) {  
		$len = (mb_strlen($text, 'UTF-8') > $maxlen)? mb_strripos(mb_substr($text, 0, $maxlen, 'UTF-8'), ' ') : $maxlen;
		$cutStr = mb_substr($text, 0, $len);
		$temp = (mb_strlen($text, 'UTF-8') > $maxlen)? $cutStr : $cutStr;
		return $temp;
	}
	//
}
?>