<?php
class usemi {
	// Аватар пользователя
	public function avas($opt = []) {
		$user = DB::$dbs->queryFetch('SELECT avatar,id,url FROM user WHERE id = ? LIMIT 1', [$opt['id']]);
		if(isset($user['id'])):
			$mini = isset($opt['mini']) ? CDN.'/photo/m/' : CDN.'/photo/';
			switch (isset($user['id'])):
				case isset($user['avatar']):
					$photo = DB::$dbs->queryFetch('SELECT photo,id FROM photo WHERE id = ? LIMIT 1', [$user['avatar']]);
					$avatar = "<img src='{$mini}{$photo['photo']}'>";
				break;
				default:
					$avatar = "<img src='{$mini}/camera_200.png'>";
					$photo = null;
				break;
			endswitch;
			$url = match (isset($avatar)) {
				isset($opt['url']) and $opt['url'] == 1 and isset($photo['photo']) => "<a href='".DOMAIN2."/{$user['url']}'>{$avatar}</a>",
				isset($opt['url']) and $opt['url'] == 2 and isset($photo['photo']) => "<a href='".DOMAIN2."/photo{$user['id']}_{$photo['id']}'>{$avatar}</a>",
				default => $avatar
			};
			return $url;
		else:
			return 'no';
		endif;
	}
	// Определяем возраст
	public function vozrast($birthday)
	{
	  $diff = date('Ymd') - date('Ymd', strtotime($birthday));
		$date = substr($diff, 0, -4);
		return !empty($date) ? $date : 0;
  }
	// Логин пользователя
	public function logins($opt = []): string 
	{
		$user = DB::$dbs->queryFetch('SELECT name,fame,url FROM user WHERE id = ? LIMIT 1', [$opt['id']]);
		$name = match (isset($opt['name'])) {
			$opt['name'] == 1 => $user['name'],
			$opt['name'] == 2 => $user['fame'],
			default => $user['name'].' '.$user['fame']
		};
		return isset($opt['url']) ? "<a href='".DOMAIN2."/{$user['url']}'>{$name}</a>" : $name;
	}
	//
	function reitings(int $opt): array
	{
		$user = DB::$dbs->queryFetch('SELECT interests,status,telegram,avatar,rate,gorate FROM user WHERE id = ? LIMIT 1', [$opt]);
		$rate = $user['rate'];
		$rate += (isset($user['interests'])) ? 20 : 0;
		$rate += (isset($user['status'])) ? 10 : 0;
		$rate += (isset($user['telegram'])) ? 10 : 0;
		$rate += (isset($user['avatar'])) ? 30 : 0;
		$skok = 100 * $rate / $user['gorate'];
		$d = ['rate' => $rate, 'skok' => $skok];
		return [
			'rate' => $rate,
			'skok' => $skok
		];
	}
}
?>