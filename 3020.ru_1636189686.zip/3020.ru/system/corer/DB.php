<?php
class PDO_ extends PDO {
	function __construct($dsn, $username, $password) {
		parent::__construct($dsn, $username, $password);
		$this -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$this -> setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
		$this -> setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
	}

	function prepare($sql, $params = []) {
		$stmt = parent::prepare($sql, [
		PDO::ATTR_STATEMENT_CLASS => ['PDOStatement_']]);
		return $stmt;
	}

	function querySql($sql, $params = []) {
		$stmt = $this -> prepare($sql);
		$stmt -> execute($params);
		return $stmt;
	}

	function querySingle($sql, $params = []) {
		$stmt = $this -> querySql($sql, $params);
		return $stmt -> fetchColumn(0);
	}

	function queryFetch($sql, $params = []) {
		$stmt = $this -> querySql($sql, $params);
		return $stmt -> fetch();
	}

	function queryCounter() {
		return self::$counter;
	}
}
// ----------------------------------------------------//
class PDOStatement_ extends PDOStatement {
	function execute($params = []) {
		$params = func_num_args() == 1 ? func_get_arg(0) : func_get_args();
		if (!is_array($params)):
			$params = [$params];
		endif;
		parent::execute($params);
		return $this;
	}

	function fetchSingle() {
		return $this -> fetchColumn(0);
	}

	function fetchAssoc() {
		$this -> setFetchMode(PDO::FETCH_NUM);
		$data = [];
		while ($row = $this -> fetch()):
			$data[$row[0]] = $row[1];
		endwhile;
		return $data;
	}
}
class DB {
	static $dbs;
	public function __construct($opt = []) {
		try {
			self :: $dbs = new PDO_("mysql:dbname={$opt['connect']['user']};host={$opt['connect']['host']}", $opt['connect']['dbname'], $opt['connect']['password']);
			self :: $dbs -> exec('SET CHARACTER SET '.$opt['connect']['charset']);
			self :: $dbs -> exec('SET NAMES '.$opt['connect']['namess']);
		}catch (PDOException $e) {
			die('Ошибка подключения к БД: '.$e -> getMessage());
		}
	}
}
?>