<?php
// 3020.ru - скрипты для вас можно скачать тут
class core{
	private $db;
	public function __construct() {
		return $this->getUserData();
	}
	protected function getUserData() {
		if (isset($_COOKIE['token'])):
			return $this->authentification($_COOKIE['token']);
		endif;
		return [];
	}
	private function authentification(string $token): array {
		$req = DB::$dbs->querySql('SELECT * FROM user WHERE token = ? LIMIT 1',[$token]);
		if ($req->rowCount()) {
			$this->userData = $req->fetch();
			DB::$dbs->querySql('UPDATE user SET datalast = ? WHERE id = ?',[time(),$this->userData['id']]);
			/*
			//
			if($this->userData['datalast'] > (time() - 5)) {
				DB::$dbs->querySql('UPDATE user SET updatedei = updatedei + 1 WHERE id = ?',[$this->userData['id']]);
			}

			if($this->userData['updatedei'] > 10) {
				$naskb = time() + $this->userData['naskokban'];
				DB::$dbs->querySql('UPDATE user SET timeban = ?, updatedei = 0 WHERE id = ?',[$naskb,$this->userData['id']]);
			}
			//
			*/
		} else {
			$this->userUnset();
		}
		return [];
	}
	public function getData() {
		return $this->userData ?? null;
	}
	protected function userUnset(): void {
		setcookie('token', '');
	}
}
?>