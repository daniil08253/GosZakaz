<?php
// 3020.ru - скрипты скачать можно тут
////////////////////// старт генерации
$generrat = (float)microtime();
///////////////////// Показ ошибок
ini_set('error_reporting', E_ALL); //Задает, какие ошибки PHP попадут в отчет (все)
ini_set('display_errors', 1); // показ ошибок (лучше ошибки сразу исправлять)
ini_set('display_startup_errors', 1); //ошибки во время запуска php
///////////////////// Старт тайм зоны
date_default_timezone_set('Europe/Moscow'); // тайм зона
mb_internal_encoding('UTF-8'); // кодировка
////////////////////// Настраиваем быстрые переменные
define('ROOT', dirname(__DIR__)); // Главная директория . DIRECTORY_SEPARATOR
define('DOMAIN', $_SERVER['SERVER_NAME']); // Получение домена
define('DOMAIN2', 'https://'.$_SERVER['SERVER_NAME']); // Получение домена2
define('DOMAIN3', 'vkphp'); // Получение домена3
define('CDN', 'https://адресс тут'); // Получение домена4
///////////////////// Настройка сессии
session_name('SESID'); // название начальной сессии
session_start(); // стартуем сессию
ob_start(); // Включение буферизации вывода
///////////////////// Проверяем версию php (для того что бы поошибке не установить на говно версию)
if(version_compare(PHP_VERSION, '7.4', '<')):
	exit('ОШИБКА! Версия PHP должна быть 7.4 и больше.'); 
endif;
///////////////////// Заранее фильтруем переменные
$act = isset($_GET['act']) ? trim(htmlspecialchars($_GET['act'])) : null;
$id = isset($_GET['id']) ? abs(intval($_GET['id'])) : null;
///////////////////// Автозагрузка классов
function autoload($class) { // запуск функции
	$file = ROOT.'/system/corer/'.$class.'.php';
	if (file_exists($file)):
		require $file;
	else:
		$message = sprintf("Кажется где-то потерял файл: %s", $file);
		die($message); exit;
	endif;
}
if (function_exists('spl_autoload_register')): // автозагрузка
	spl_autoload_register('autoload');
endif;
///////////////////// Подключение к бд
$db = new DB([
	'connect' => [
		'host'     => 'localhost', // Хост
		'user'     => 'j23271815_wiq', // Юзер
		'password' => 'w(fvw5`Dvn\g', // Пароль от бд
		'dbname'   => '047435216_wiq', // Имя юзера
		'charset'  => 'utf8mb4', // БД какой кадировки записывать
		'namess'  => 'utf8mb4' // Записываем кодировкой
	]
]);
/////
$core = new core();
$usemi = new usemi();
$komm = new komm();
$curl = new curl();
$functions = new functions();
$title = new body();
$user = $core->getData();
//
if(isset($user['id']) and $user['timeban'] > time() and $_SERVER['REQUEST_URI'] != '/ban/') {
	header('location: /ban/'); exit;
}
//
?>