<?php

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

/**
 * Random line generation
 * @param int $length
 * @return string
 */
function uid($length = 10)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

/**
 * Beautiful HTML output
 * @param $html
 */
function html_code($html)
{
    echo nl2br(htmlspecialchars($html));
}

/**
 * Compiling an array with field data
 * @param $html
 * @return array
 */
function inputs($html)
{
    preg_match_all('~<input(.*?)>~ui', $html, $rez);
    $arrays = [];
    foreach ($rez['1'] as $item => $value) {
        preg_match('~name=["|\']([^"]+)["|\']~ui', $value, $tmp_one);
        preg_match('~value=["|\']([^"]+)["|\']~ui', $value, $tmp_two);
        $arrays[$tmp_one['1']] = ((!empty($tmp_two['1'])) ? $tmp_two['1'] : 'NULL');
    }
    return $arrays;
}

/**
 * Analog print_r
 * @param $data
 */
function arrays($data)
{
    echo '<pre>';
    print_array($data);
    echo '</pre>';
}

/**
 * For function 'arrays()'
 * @param $var
 * @param bool $return
 * @param bool $html
 * @param int $level
 * @return bool|string
 */
function print_array($var, $return = false, $html = false, $level = 0)
{
    $spaces = "";
    $space = $html ? "&nbsp;" : " ";
    $newline = $html ? "<br />" : "\n";
    for ($i = 1; $i <= 6; $i++) {
        $spaces .= $space;
    }
    $tabs = $spaces;
    for ($i = 1; $i <= $level; $i++) {
        $tabs .= $spaces;
    }
    $title = '';
    if (is_array($var)) {
        $title = "Array";
    } elseif (is_object($var)) {
        $title = get_class($var) . " Object";
    }
    $output = $title . $newline . $newline;
    foreach ($var as $key => $value) {
        if (is_array($value) || is_object($value)) {
            $level++;
            $value = print_array($value, true, $html, $level);
            $level--;
        }

        if ($value === true) {
            $value = 'true';
        }
        if ($value === false) {
            $value = 'false';
        }
        if (empty($value)) {
            $value = 'empty';
        }
        $output .= $tabs . "[" . $key . "] => " . $value . $newline;
    }
    if ($return) return $output;
    else echo $output;

    return false;
}

/**
 * Download files using curl
 * @param string $url
 * @param string $path
 * @param string $file
 */
function download($url = '', $path = '', $file = '')
{
    $path = $_SERVER['DOCUMENT_ROOT'] . '/' . $path . '/';

    if (!file_exists($path)) {
        mkdir($_SERVER['DOCUMENT_ROOT'] . '/' . $path . '/');
    }

    $path .= $file;

    if (file_exists($path)) {
        exit('Файл уже существует');
    }

    $fp = fopen($path, 'w');
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_exec($ch);
    curl_close($ch);
    fclose($fp);
}

/**
 * Bubble Sort
 * @param array $array
 * @return array
 */
function buble($array = [])
{
    for ($j = 0; $j < count($array) - 1; $j++) {
        for ($i = 0; $i < count($array) - $j - 1; $i++) {
            if ($array[$i] > $array[$i + 1]) {
                $tmp_var = $array[$i + 1];
                $array[$i + 1] = $array[$i];
                $array[$i] = $tmp_var;
            }
        }
    }
    return $array;
}

/**
 * Recursively delete files and folders
 * @param $path
 * @return bool
 */
function rmRec($path)
{
    if (is_file($path)) return unlink($path);
    if (is_dir($path)) {
        foreach (scandir($path) as $p) if (($p != '.') && ($p != '..'))
            rmRec($path . DIRECTORY_SEPARATOR . $p);
        return rmdir($path);
    }
    return false;
}

/**
 * Class UcUrl for easy work with curls
 * @author Alexey Orach alexeyorach@gmail.com
 * @version 0.9
 * PHP version 5+
 */
class UcUrl
{
    public $COOKIE_DIR = 'curl_cookie'; // Folder name with file cookie
    private $data = [
        'live' => false, // status
        'cookie' => false, // cookie (string,array,empty)
        'file_cookie' => false, // path to file with cookie
        'save_cookie' => false, // save or not file with cookie
        'status_cookie' => false, // status (array,string,file,retrieved)
        'ua' => false, // user-agent
        'headers' => false, // http headers
        'previous_link' => false, // refer link
        'info' => false, // additional Information
        'link' => false, // link to this page
        'follow' => true, // follow the pointer
        'head' => false, // info in head
        'ajax' => false // emulation ajax request's
    ];

    private $file = [
        'text' => false, // text
        'file' => false, // full path to file
        'mime' => false // mime-type file
    ];

    private $ch = null; // handle
    private $html = ''; // html code for work
    private $ua = array(
        'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:25.0) Gecko/20100101 Firefox/25.0',
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:24.0) Gecko/20100101 Firefox/24.0',
        'Mozilla/5.0 (Windows NT 6.0; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:24.0) Gecko/20100101 Firefox/24.0',
        'Mozilla/5.0 (Windows NT 6.2; rv:22.0) Gecko/20130405 Firefox/23.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130406 Firefox/23.0',
        'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:23.0) Gecko/20131011 Firefox/23.0',
        'Mozilla/5.0 (Windows NT 6.2; rv:22.0) Gecko/20130405 Firefox/22.0',
        'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:22.0) Gecko/20130328 Firefox/22.0',
        'Mozilla/5.0 (Windows NT 6.1; rv:22.0) Gecko/20130405 Firefox/22.0',
        'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/21.0.1',
        'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/21.0.1',
        'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:21.0.0) Gecko/20121011 Firefox/21.0.0',
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:21.0) Gecko/20130331 Firefox/21.0',
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:21.0) Gecko/20100101 Firefox/21.0',
        'Mozilla/5.0 (X11; Linux i686; rv:21.0) Gecko/20100101 Firefox/21.0',
        'Mozilla/5.0 (Windows NT 6.2; rv:21.0) Gecko/20130326 Firefox/21.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20130401 Firefox/21.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20130331 Firefox/21.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20130330 Firefox/21.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0',
        'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1664.3 Safari/537.36',
        'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.16 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1623.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.17 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.62 Safari/537.36',
        'Mozilla/5.0 (X11; CrOS i686 4319.74.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.57 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.2 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1467.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1464.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36',
        'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36',
        'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14',
        'Mozilla/5.0 (Windows NT 6.0; rv:2.0) Gecko/20100101 Firefox/4.0 Opera 12.14',
        'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0) Opera 12.14',
        'Opera/12.80 (Windows NT 5.1; U; en) Presto/2.10.289 Version/12.02',
        'Opera/9.80 (Windows NT 6.1; U; es-ES) Presto/2.9.181 Version/12.00',
        'Opera/9.80 (Windows NT 5.1; U; zh-sg) Presto/2.9.181 Version/12.00',
        'Opera/12.0(Windows NT 5.2;U;en)Presto/22.9.168 Version/12.00',
        'Opera/12.0(Windows NT 5.1;U;en)Presto/22.9.168 Version/12.00',
        'Mozilla/5.0 (Windows NT 5.1) Gecko/20100101 Firefox/14.0 Opera/12.0',
        'Opera/9.80 (Windows NT 6.1; WOW64; U; pt) Presto/2.10.229 Version/11.62',
        'Opera/9.80 (Windows NT 6.0; U; pl) Presto/2.10.229 Version/11.62',
        'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9.168 Version/11.52',
        'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; de) Presto/2.9.168 Version/11.52',
        'Googlebot/2.1 (+http://www.google.com/bot.html)'
    ); //list User-Agent
    /**
     * @var string
     */
    private $url = '';

    public function __construct($data = [])
    {
        $this->ch = $this->init($data);
    }

    public function __destruct()
    {
        $this->data['live'] = false;

        curl_close($this->ch);

        if ($this->data['save_cookie'] == false and file_exists(__DIR__ . '/' . $this->COOKIE_DIR . '/' . $this->data['file_cookie'])) {
            unlink(__DIR__ . '/' . $this->COOKIE_DIR . '/' . $this->data['file_cookie']);
        }
    }

    private function init($data = [])
    {
        $this->data = array_merge($this->data, $data);

        if (empty($this->data['ua'])) {
            $this->data['ua'] = $this->ua[rand(0, (count($this->ua) - 1))];
        }

        if ($this->ch == null and $this->data['live'] == false) {
            $this->ch = curl_init();
            curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, $this->data['follow']);
            curl_setopt($this->ch, CURLOPT_HEADER, $this->data['head']);
        }

        if (is_string($this->data['cookie']) and preg_match('/\.txt/ui', $this->data['cookie'])) {
            $this->data['status_cookie'] = 'file';
            curl_setopt($this->ch, CURLOPT_COOKIEJAR, $_SERVER['DOCUMENT_ROOT'] . '/' . $this->data['file_cookie']);
            curl_setopt($this->ch, CURLOPT_COOKIEFILE, $_SERVER['DOCUMENT_ROOT'] . '/' . $this->data['file_cookie']);
        } elseif (is_string($this->data['cookie'])) {
            $this->data['status_cookie'] = 'string';
            curl_setopt($this->ch, CURLOPT_COOKIE, $this->data['cookie']['cookie_string']);
        } elseif (is_array($this->data['cookie'])) {
            $this->data['status_cookie'] = 'array';
            $this->GenCookie($this->data['cookie']);
        } else {
            $this->data['status_cookie'] = 'retrieved';
        }
        if ($this->data['save_cookie'] and $this->data['status_cookie'] != 'file') {
            curl_setopt($this->ch, CURLOPT_COOKIEJAR, __DIR__ . '/' . $this->COOKIE_DIR . '/' . $this->data['file_cookie']);
        }

        $this->headers($this->data['headers']);
        $this->data['live'] = true;
        return $this->ch;
    }

    private function GenCookie($data = [])
    {
        $GenStringCookie = '';
        if (is_array($data)) {
            foreach ($data as $name => $vol) {
                $GenStringCookie .= $name . '=' . $vol . ';';
            }
        }

        $this->data['cookie']['cookie_string'] = $GenStringCookie;
        curl_setopt($this->ch, CURLOPT_COOKIE, $GenStringCookie);
        if ($this->data['save_cookie']) {
            $this->data['file_cookie'] = uid(10) . '.txt';
            if (!file_exists(__DIR__ . '/' . $this->COOKIE_DIR . '/')) {
                mkdir(__DIR__ . '/' . $this->COOKIE_DIR . '/');
            }
            curl_setopt($this->ch, CURLOPT_COOKIEJAR, __DIR__ . '/' . $this->COOKIE_DIR . '/' . $this->data['file_cookie']);
        }
        return $this->ch;
    }

    private function headers($text = '')
    {
        $code = array(
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
            'Accept-Charset: windows-1251,utf-8;q=0.7,*;q=0.7',
            'Keep-Alive: 115',
            'Connection: keep-alive'
        );

        if (is_string($text)) {
            $code = array($text);
        }

        if ($this->data['ajax']) {
            $code = [
                'Accept-Encoding: gzip, deflate',
                'X-Requested-With: XMLHttpRequest',
                'Connection: keep-alive',
                'Pragma: no-cache',
                'Cache-Control: no-cache'
            ];
        }

        $this->data['headers'] = $code;
        curl_setopt($this->ch, CURLOPT_HTTPHEADER, $code);
        return $this->ch;
    }

    public function get($url = '', $data = [])
    {
        $this->ch = $this->init($data);
        $this->url = $url;

        curl_setopt($this->ch, CURLOPT_URL, $url);

        //refer
        $this->data['previous_link'] = empty($this->data['previous_link']) ? $url : $this->data['previous_link'];
        $this->data['previous_link'] = $url;
        $arr = parse_url($url);

        if (!empty($arr['path'])) {
            $link = substr($arr['path'], 0, strrpos($arr['path'], '/'));
        } else {
            $link = '';
        }

        $this->data['link'] = $arr['scheme'] . '://' . $arr['host'] . $link . '/';
        curl_setopt($this->ch, CURLOPT_REFERER, $this->data['previous_link']);
        //

        $code = curl_exec($this->ch);
        $this->html = $code;

        if ($this->data['info'] == true) {
            return ['info' => curl_getinfo($this->ch), 'html_code' => $code];
        } else {
            return $code;
        }
    }

    public function post($url = '', $post = [], $file = [], $data = [])
    {
        $this->ch = $this->init($data);
        $this->url = $url;
        $this->file = array_merge($this->file, $file);
        curl_setopt($this->ch, CURLOPT_URL, $url);
        curl_setopt($this->ch, CURLOPT_POST, 1);
        $post_final = '';

        if (!empty($this->file['file'])) {
            $post_final = [$this->file['text'] => curl_file_create($_SERVER['DOCUMENT_ROOT'] . '/' . $this->file['file'], (empty($this->file['file']) ? ($this->GetMime(substr(strrchr($this->file['file'], '.'), 1)) ? $this->GetMime(substr(strrchr($this->file['file'], '.'), 1)) : false) : $this->file['file']), pathinfo($_SERVER['DOCUMENT_ROOT'] . '/' . $this->file['file'])['basename'])];
        } elseif (is_array($post)) {
            foreach ($post as $id => $inf) {
                $post_final .= $id . '=' . $inf . '&';
            }
            $post_final = substr($post_final, 0, -1);
        } else {
            $post_final = $post['text'];
        }

        curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post_final);

        $result = curl_exec($this->ch);

        return ['info' => curl_getinfo($this->ch), 'code' => $result];

    }

    public function htmls()
    {
        preg_match_all('~(src|href)=(["\'])(.*?)([\'"])~ui', $this->html, $result);
        $result = $result[3];
        for ($i = 0; $i < count($result); $i++) {
            if (empty($result[$i]) or mb_strlen($result[$i]) < 3) {
                continue;
            }
            if (preg_match('~^http~umi', $result[$i])) {
                continue;
            }
            if (preg_match_all('~\.\./~ui', $result[$i], $sss)) {
                $result[$i] = preg_replace('~\.\./~ui', '', $result[$i]);
                $results = $this->UrlRes($this->url, count($sss[0])) . $result[$i];
                $this->html = str_replace($result[$i], $results, $this->html);
            }
            if (preg_match('~^/~umi', $result[$i], $zzz) and !preg_match('~^\.\./~umi', $result[$i], $zzz)) {
                $arr = parse_url($this->url);
                $linkz = $arr['scheme'] . '://' . $arr['host'] . '/';
                $results = preg_replace('~^/~umi', $linkz, $result[$i]);
                $this->html = str_replace($result[$i], $results, $this->html);
            }
        }
        return $this->html;
    }

    public function handle()
    {
        return $this->ch;
    }

    public function GetMime($type = '')
    {
        $url = 'http://svn.apache.org/repos/asf/httpd/httpd/trunk/docs/conf/mime.types';
        $list = [];
        foreach (@explode("\n", @file_get_contents($url)) as $x) {
            if (isset($x[0]) && $x[0] !== '#' && preg_match_all('#([^\s]+)#', $x, $out) && isset($out[1]) && ($c = count($out[1])) > 1) {
                for ($i = 1; $i < $c; $i++) {
                    $list[$out[1][$i]] = $out[1][0];
                }
            }
        }
        return array_key_exists($type, $list) ? $list[$type] : false;
    }

    public function UrlRes($url = '', $num = 0)
    {
        $urls = !empty($url) ? $url : $this->url;
        $base = parse_url($url);
        if (substr(strrchr($urls, "/"), 1) != '/') {
            $num = $num + 1;
        }
        for ($i = 0; $i < $num; $i++) {
            if (preg_match('~' . $base['host'] . '$~umi', $urls)) {
                break;
            }
            $dell = substr(strrchr($urls, "/"), 1);
            $pattern = '~/' . $dell . '~umi';
            $urls = preg_replace($pattern, '', $urls);
        }
        return $urls . '/';
    }


    public function GetData()
    {
        return $this->data;
    }
}
/*
     * Start:
     * include "UcUrl.php";
     * $ch = new UcUrl();
     * Ready for work
     *
     * Easy to use:
     * $ch->get('URL');
     * $ch->post('URL', ['data' => 'value', 'Something' => 'value']);
     * $ch->post('URL', 'data=value&Something=value');
     * $ch->post('URL', ['key' => 'value'], ['file' => 'image.jpg']);
     *
     * Settings:
     * $ch = new UcUrl(['cookie' => ['key' => 'value'] ]);
     *  OR
     * $ch->get('link', ['cookie' => ['key' => 'value'] ]);
     *  OR
     * $ch->post('link', ['post' => 'arg'], ['file' => 'path'], ['cookie' => [ 'key' => 'value' ] ]);
     *
     *
     * View INFO about UcUrl settings
     *
     * $ch->GetData();
     * return `array`
     *
     */
