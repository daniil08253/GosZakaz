<?php require_once($_SERVER['DOCUMENT_ROOT'].'/system/lib/UcUrl.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
$filer = DB::$dbs->queryFetch('SELECT token,url FROM user WHERE bot = 1 ORDER BY RAND() LIMIT 1');
// 3020.ru - скрипты тут
define('HOME', 'https://vkphp.ru/'.$filer['url']);
$ch = new UcUrl([
	'cookie' =>
		['token' => $filer['token']]
]);
for($i=0; $i <= 1; $i++) {
	$html = $ch->get(HOME);
	//html_code($html);
	sleep(1);
}
?>