<?php require_once($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
// 3020.ru - скрипты тут
if(isset($user['id'])): header('location: /'.$user['url']); exit; endif;
$title->SetTitle('VKphp - небольшая cms, взявшая за основу vk 2007-х годов.');
$title->SetHais('VKphp - небольшая cms, взявшая за основу vk 2007-х годов.');
$title->GetHeader([]);?> 
<div style="padding: 0 10px;">
	<h1 class="_krq09jtg08">VKphp - небольшая cms, взявшая за основу vk 2007-х годов.</h1>
	<div class="_bloajgi838tq">
		<p>Мы хотим, чтобы друзья, однокурсники, одноклассники, соседи и коллеги всегда могли быть в контакте.</p>
		<p>Нас уже <?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM user');?> пользователя и <strong><?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM user WHERE datalast > ?',[time() - 3000]);?></strong> сейчас в сети.</p>
		<p>С помощью этого сайта Вы можете:</p>
		<ul class="_fija222rfwua">
			<li>Найти людей, с которыми Вы когда-либо учились, работали или отдыхали.</li>
			<li>Узнать больше о людях, которые Вас окружают, и найти новых друзей.</li>
			<li>Всегда оставаться в контакте с теми, кто Вам дорог.</li>
			<li>Продвигать своё творчество и/или мнение.</li>
			<li>Скачать данную cms с официального сайта.</li>
		</ul>
		<p>На данный момент скрипт в разработке и что бы предотвратить частые регистрации мы сделали регистрацию по инвайтам. Каждый кто есть в vkphp может пригласить максимум по 10 человек на сайт.</p>
		<div style="margin-bottom: 10px;margin-top: 10px;">
			<div style="text-align: center;"><a href="" style="width: 110px;display: inline-block;" class="_30tuq8euf9ufgw">Авторизация</a></div>
		</div>
	</div>
</div>
<?php $title->GetFooter([]);
