<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		unset($_SESSION['id_music']);
		$id_music = $functions->ints($_GET['id_music']);
		$qqq = DB::$dbs->queryFetch('SELECT file,id FROM audio WHERE id = ? LIMIT 1', [$id_music]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		$_SESSION['id_music'] = $id_music;
		if(isset($user['id'])):
			DB::$dbs->querySql('UPDATE user SET audioupd = ?, timeaudioupd = ? WHERE id = ? LIMIT 1', [$id_music,time(),$user['id']]);
		endif;
		//$_SESSION['file'] = $qqq['file'];
	break;
	case 'sl':
		if(isset($user['id'])):
			$ids = isset($_SESSION['id_music']) ? $_SESSION['id_music'] : NULL;
			$qqq = DB::$dbs->queryFetch('SELECT file,id FROM audio WHERE idus = ? ORDER BY RAND() DESC LIMIT 1', [$user['id']]);
			if(isset($user['id'])):
				DB::$dbs->querySql('UPDATE user SET audioupd = ?, timeaudioupd = ? WHERE id = ? LIMIT 1', [$ids,time(),$user['id']]);
			endif;
			$d = ['id' => $qqq['id'], 'url' => $qqq['file'], 'type' => 'success'];
		else:
			unset($_SESSION['id_music']);
			$d = ['message' => 'Авторизуйтесь, что бы слушать автоматически', 'type' => 'error'];
		endif;
		echo json_encode($d); exit;
	break;
	case 'del':
		if(isset($user['id'])):
			DB::$dbs->querySql('UPDATE user SET NULL = ?, NULL = ? WHERE id = ? LIMIT 1', [$user['id']]);
		endif;
		unset($_SESSION['id_music']);
	break;
}
?>