var tp = 0;
var ky = 0;
//Данные из тега <audio>
var player = document.getElementsByTagName('audio')[0];
function MusicPlay(play_id,url) {
	//Ловим контейнер текущего трека
	var player_id = document.getElementById('play-status'+play_id);
	// Текущий трек
	player.src = "https://cdn.wiq.su/music/"+url;
	if (tp == play_id) {
		player.pause();
		tp = 0;
		console.log('Останавливаем музыку музыку '+tp);
		$('#play-status'+play_id).html('<span class="material-icons">play_arrow</span>');
		$('._asf3qt8ghr99h').css({display:'none'});
		player.remove();
		$.ajax({url: '/sess/audio/del/', cache: false, type: 'GET', success: function(data) { } });
	} else {
		player.load();  
		player.play();
		tp = play_id;
		console.log('Запускаем музыку '+tp);
		$('._asf3qt8ghr99h').css({display:'block'});
	}
	//
	var progressBar = document.getElementById('_asf3qt8ghr99h-play');
	progressBar.addEventListener('click', function(event){
		let widthLeft = $(progressBar).offset().left;
		let x = event.pageX - widthLeft;
		let xPersent =  x / this.offsetWidth * 100;
		player.currentTime = player.duration * (xPersent / 100);
		var curtime = player.duration * (xPersent / 100);
		player.play();
	});
	
	var bar = $('._asf3qt8ghr99h-bar');    
	var barWidth = bar.parent().width();    
	var barChange = false;
	var perSecond = 0;
	var perPixel = 0;
	function changeBar() {
		bar.width(player.currentTime * perSecond);
	}
	//Начало воспроизведения
	player.addEventListener('playing', function(){ 
		ky = play_id;
		barChange = setInterval(changeBar, 500); // прогресс бар
		$('.play-status-off').html('<span id="pause3" class="material-icons">play_arrow</span>'); // меняем стутс у весх песен
		$('#play-status'+play_id).html('<span class="material-icons">pause</span>');
	});
	//
	player.addEventListener('pause', function(event){
		tp = 0;
	});
	//Конец воспроизведения
  player.addEventListener('ended', function(){ 
    clearInterval(timer);
    if (ky == play_id){
      //var action = $('.fplay').attr('action');
      var action_id = $('._goplay').attr('id');
      ky = 0;
      console.log('Музыка закончилась, играем следующую.');
      player_sess(action_id, '/sess/audio/sl/'); // если закончилась играем следующую
    }
  });
	//Получение метаданных
	player.addEventListener('loadedmetadata', function(){
		perSecond = barWidth / player.duration; 
		perPixel = player.duration / barWidth;
		//Длительность трека
		var dt = duration_format(player.duration);  
	})
}
function duration_format(time){   
  var hrs = ~~(time / 3600);
  var mins = ~~((time % 3600) / 60);
  var secs = ~~time % 60;
  var ret = "";
  if (hrs > 0) {
    ret += "" + hrs + ":" + (mins < 10 ? "0" : "");
  }
  ret += "" + mins + ":" + (secs < 10 ? "0" : "");
  ret += "" + secs;
  return ret;
}
function dellMusic() {
	$.ajax({url: '/sess/audio/del/', cache: false, type: 'GET', success: function(data) { } });
	player.pause();
	$('.play-status-off').html('<span id="pause3" class="material-icons">play_arrow</span>');
	$('._asf3qt8ghr99h').css({display:'none'});
	player.remove();
}
//Таймер для длительности трека по возрастанию
function tick(num) {
  clearInterval(timer);
  var sec = num;
  timer = setInterval(function() {
    sec++;
    document.getElementById('timer').childNodes[0].nodeValue = duration_format(sec);
  }, 1000);
}
//Передача параметров текущего трека обработчику для транслирования в плеере
$(document).on('click', 'button[class = "play-status-off play-button-style"]', function(e){
	var session = $(this).attr("action");
	$.ajax({
		url: session,
    cache: false,
    type: "GET",
    success: function(data) {
    	$('._idawidwadh73f9uh').html('');
    	$('._goplay').attr('id', '1'); // далее будем играть под id
    }
	});
	e.preventDefault();
});

function player_sess(action_id, url) {
	$.ajax({
		url: url,
		cache: false,
    type: 'GET',
    success: function(data) {
    	const obj = jQuery.parseJSON(data);
    	if (obj.type == 'success') {
				MusicPlay(obj.id, obj.url);
				console.log('Погнали следующую музыку.');
			} else {
				console.log(obj.message);
			}
    }
	});
}
