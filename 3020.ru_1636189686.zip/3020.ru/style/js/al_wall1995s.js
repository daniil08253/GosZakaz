function humanFileSize(bytes, si) {
	var thresh = si ? 1000 : 1024;
	if(Math.abs(bytes) < thresh) {
			return bytes + ' B';
	}
	var units = si
			? ['kB','MB','GB','TB','PB','EB','ZB','YB']
			: ['KiB','MiB','GiB','TiB','PiB','EiB','ZiB','YiB'];
	var u = -1;
	do {
			bytes /= thresh;
			++u;
	} while(Math.abs(bytes) >= thresh && u < units.length - 1);
	return bytes.toFixed(1)+' '+units[u];
}

function trim(string) {
		var newStr = string.substring(0, 10);
		if(newStr.length !== string.length)
				newStr += "…";
		
		return newStr;
}

function handleUpload() {
		console.warn("блять...");
		
		u('.postFileSel').not("#" + this.id).each(input => input.value = null);
		
		var indicator = u(".post-upload");
		var file      = this.files[0];
		if(typeof file === "undefined") {
				indicator.attr("style", "display: none;");
		} else {
				u("span", indicator.nodes[0]).text(trim(file.name) + " (" + humanFileSize(file.size, false) + ")");
				indicator.attr("style", "display: block;");
				$('._j0f8grhg94w9g').toggleClass('hidden'); return false;
		}
}
/*
$(document).on('click', '._graffitys', function(e){
	let canvas = null;
	let watermarkImage = new Image();
	watermarkImage.src = '/style/images/logo_watermark.gif';
	let msgbox = [function() {
        canvas.getImage({includeWatermark: false}).toBlob(blob => {
            let fName = "Graffiti-" + Math.ceil(performance.now()).toString() + ".jpeg";
            let image = new File([blob], fName, {type: "image/jpeg", lastModified: new Date().getTime()});
            let trans = new DataTransfer();
            trans.items.add(image);
            
            let fileSelect = document.querySelector("input[name='_pic_attachment']");
            fileSelect.files = trans.files;
            
            u(fileSelect).trigger("change");
            u("#write textarea").trigger("focusin");
        }, "image/jpeg", 0.92);
        
        canvas.teardown();
    }, function() {
        canvas.teardown();
    }];
   
    canvas = document.querySelector("#ovkDraw"), {
        backgroundColor: "#fff",
        imageURLPrefix: "/assets/packages/static/openvk/js/node_modules/literallycanvas/lib/img",
        watermarkImage: watermarkImage,
        imageSize: {
            width: 640,
            height: 480
        }
    };
	u('body').addClass('dimmed').append(`<div class="ovk-diag-cont"><div id="ovkDraw" class="_repost"></div></div>`);
	u('.ovk-diag-cont');
	return false;
});
*/
/*
function initGraffiti() {
    let canvas = null;
    let msgbox = MessageBox("РќР°СЂРёСЃРѕРІР°С‚СЊ РіСЂР°С„С„РёС‚Рё", "<div id='ovkDraw'></div>", ["РЎРѕС…СЂР°РЅРёС‚СЊ", "РћС‚РјРµРЅРёС‚СЊ"], [function() {
        canvas.getImage({includeWatermark: false}).toBlob(blob => {
            let fName = "Graffiti-" + Math.ceil(performance.now()).toString() + ".jpeg";
            let image = new File([blob], fName, {type: "image/jpeg", lastModified: new Date().getTime()});
            let trans = new DataTransfer();
            trans.items.add(image);
            
            let fileSelect = document.querySelector("input[name='_pic_attachment']");
            fileSelect.files = trans.files;
            
            u(fileSelect).trigger("change");
            u("#write textarea").trigger("focusin");
        }, "image/jpeg", 0.92);
        
        canvas.teardown();
    }, function() {
        canvas.teardown();
    }]);
    
    let watermarkImage = new Image();
    watermarkImage.src = "/assets/packages/static/openvk/img/logo_watermark.gif";
    
    msgbox.attr("style", "width: 750px;");
    canvas = LC.init(document.querySelector("#ovkDraw"), {
        backgroundColor: "#fff",
        imageURLPrefix: "/assets/packages/static/openvk/js/node_modules/literallycanvas/lib/img",
        watermarkImage: watermarkImage,
        imageSize: {
            width: 640,
            height: 480
        }
    });
}
*/
u('#wall-post-input').on('paste', function(e) {
	if(e.clipboardData.files.length === 1) {
		var input = u("input[name=file]").nodes[0];
		input.files = e.clipboardData.files;
		u(input).trigger("change");
	}
});

u(".post-like-button").on("click", function(e) {
		e.preventDefault();
		
		var thisBtn = u(this).first();
		var link    = u(this).attr("href");
		var heart   = u(".heart", thisBtn);
		var counter = u(".likeCnt", thisBtn);
		var likes   = counter.text();
		var isLiked = heart.attr("style") === 'opacity: 1;';
		
		ky(link);
		heart.attr("style", isLiked ? 'opacity: 0.4;' : 'opacity: 1;');
		counter.text(parseInt(likes) + (isLiked ? -1 : 1));
		
		return false;
});
u(".postFileSel").on("change", handleUpload);
