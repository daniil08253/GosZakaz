function ajaxUrl(href){
	$.post(href,
		function (data){
			var data = $(data);
			var elem = data.find('#content').html();
			$('#content').html(elem);
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}
	);
}

function ajwdjwod83r(href) {
	ajaxUrl(href);
	var titl = $('.title').text();
	document.title = titl;
	history.pushState(href, titl, href);
	return false; 
}
	
if (history.pushState){
	$(window).on('popstate', function(event){
		var loc = event.location || ( event.originalEvent && event.originalEvent.location ) || document.location;
		ajaxUrl(loc.href);
	});
	 
	$(document).on('click', 'a[href],[data-href]', function(e){
		var href = $(this).attr('href') || $(this).attr('data-href');
		var target = $(this).attr('target') || false;
		var is_bad_link = false;
		var domain = window.location.host;
		if (target == '_blank') { return true; }
		if (href && href !== '#' && href.search(/\#/i) === 0) {
			var tagScroll = $(href).offset() || false; 
			if (tagScroll) {
				$("html, body").animate({
						scrollTop: tagScroll.top - 5
					}, 700);  				
			}
			return false; 
		}
		if (href == '/' || href == '') { href = window.origin; }
		if (href && href.indexOf('://') !== -1 && href.indexOf(domain) === -1) { window.open(href); return false; }
		if (href == 'undefined' || !href || href.indexOf('javascript:') !== -1 || href == '#') { is_bad_link = true; }
		if (is_bad_link === false) { 
			ajaxUrl(href);
			var titl = $('.title').text();
			document.title = titl;
			history.pushState(href, titl, href);
			e.preventDefault();
			return false; 
		} else {
			return false; 
		}
	});
}

$(document).on('click', '._dawd021hhwggh', function(e){
	$.ajax({
		url: $(this).attr('href'),
		type: 'post',
		success: function(data) {
			const obj = jQuery.parseJSON(data);
			if (obj.type == 'success') {
				u('body').addClass('dimmed').append(obj.dialog);
				u('.ovk-diag-cont');
				return false;
			} else {
				return rgef3wfrs(obj.message,'error');
			}
			return false;
		}
	});
});

$(document).ready(function (){

	$(document).click(function (e) {

		if($('.ovk-diag-cont').length > 0) {
			const menuMore = $('body'),
						menuDc    = $('.ovk-diag-cont');
			if (!menuDc.is(e.target) && menuDc.has(e.target).length === 0) {
				u('.ovk-diag-cont').remove();
				menuMore.removeClass('dimmed');
			};
		}

	});
	
});

function saveform (formass,ids) {
	event.preventDefault();
	var formNm = $(ids)[0];
	var formData = new FormData(formNm);
	$.ajax({
		url: formass,
		type: 'post',
		cache: false,
		data: formData,
		contentType: false,
		processData: false,
		success: function(data) {
			const obj = jQuery.parseJSON(data);
			if (obj.type == 'success') {
				if(obj.bizes === undefined) {
					window.location.href = obj.url;
				} else if(obj.bizes === 1) {
					return rgef3wfrs(obj.message,'good');
				} else if(obj.bizes === 2) {
					$((obj.html)).insertAfter($('#moreNews33'));
					return rgef3wfrs(obj.message,'good');
				} else if(obj.bizes === 3) {
					$('#postFilePic').val('');
					$('#wall-post-input').val('');
					$('.post-upload').css({display:'none'});
					$((obj.html)).insertAfter($('#moreNews33'));
					return rgef3wfrs(obj.message,'good');
				} else if(obj.bizes === 4) {
					u('.ovk-diag-cont').remove();
					$('body').removeClass('dimmed');
					return rgef3wfrs(obj.message,'good');
				} else if(obj.bizes === 5) {
					rgef3wfrs(obj.message,'good');
					return ajwdjwod83r(obj.href);
				} else if(obj.bizes === 6) {
					$('.target').toggle();
					$('._ijaowidj4378t9').val('');
					$((obj.html)).insertAfter($('#moreNews33'));
					return rgef3wfrs(obj.message,'good');
				} else if(obj.bizes === 7) {
					$('#postFilePic').val('');
					return rgef3wfrs(obj.message,'good');
				}
			} else if (obj.type == 'error') {
				return rgef3wfrs(obj.message,'error');
			}
		}
	});
}

function rgef3wfrs (qefvarwf42d,e4rwhten4w5h) {
	$('#oshhb').empty();
	$('#oshhb').css({display:'block'});
	$('#oshhb').append('<div class="'+e4rwhten4w5h+'">'+qefvarwf42d+'</div>');
	const oss11 = document.getElementById('oshhb');
	$('body,html').animate({ scrollTop: 0 }, 300);
	setTimeout(function() { $('#oshhb').css({display:'none'}); $('#oshhb').empty(); }, 4000);
}

function hidePanel(panel, count = 0) {
	$(panel).toggleClass("_fe_open _fe_close");
	$(panel).next('div').slideToggle(300);
	if(count != 0){
		if($(panel).hasClass("_fe_open"))
			$(panel).html($(panel).html().replaceAll(" ("+count+")", ""));
		else
			$(panel).html($(panel).html() + " ("+count+")");
	}
}

function k09f48wgrgirj49 (div,url) {
	$.ajax({
		url: url,
		type: 'post',
		success: function(data) {
			const obj = jQuery.parseJSON(data);
			if (obj.type == 'success') {
				if(obj.bizes === undefined) {
					$(div).html(obj.chtos);
				} else if(obj.bizes === 1) {
					$('._iajif38h9hg9r').remove();
					$('._fioawif38h9gh').remove();
					$('._fe84tg8righ').css({opacity:'.1'});
				} else if(obj.bizes === 2) {
					$('._fowhadfh397yfh9').remove();
					$(div).css({opacity:'.1'});
				} else if(obj.bizes === 3) {
					if(obj.chto === 1) {
						$(div+'gl').remove();
					} else {
						$(div).html(obj.chtos);
					}
				}
				return rgef3wfrs(obj.message,'good');
			} else {
				return rgef3wfrs(obj.message,'error');
			}
		}
	});
}

function expand_wall_textarea() {
	var el = document.getElementById('post-buttons');
	var wi = document.getElementById('wall-post-input');
	el.style.display = 'block';
	wi.className = 'expanded-textarea';
}

function fawd3thwe9g (url) {
	$.ajax({
		url: url,
		type: 'post',
		success: function(data) {
			const obj = jQuery.parseJSON(data);
			if (obj.type == 'success') {
				$(obj.ids).remove();
				return rgef3wfrs(obj.message,'good');
			} else {
				return rgef3wfrs(obj.message,'error');
			}
		}
	});
}

function autoPlayVideoYo(id, vcode, width, height){
	$('#video_id'+id).html('<iframe style="width: '+width+';height: '+height+';" src="https://www.youtube.com/embed/'+vcode+'?autoplay=1" frameborder="0" allowfullscreen></iframe>');
}