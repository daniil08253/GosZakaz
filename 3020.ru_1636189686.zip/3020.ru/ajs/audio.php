<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'add':
		$chto = $functions->htmlred($_GET['chto']);
		$audio = DB::$dbs->queryFetch('SELECT id,name,opis,idus,file FROM audio WHERE id = ? LIMIT 1', [$id]);
		if(empty($audio['id'])):
			if(DB::$dbs->querySingle('SELECT COUNT(id) FROM audio_us WHERE id_audio = ? and idus = ? and chto = ?', [$id,$user['id'],$chto]) > 0):
				DB::$dbs->querySql('DELETE FROM audio_us WHERE id_audio = ? LIMIT 1',[$id]);
					$d = ['bizes' => 3, 'chto' => 1, 'message' => 'Аудиозапись успешно удалена.', 'type' => 'success'];
					echo json_encode($d); exit;
			else:
				$d = ['message' => 'Такой аудиозаписи нет.', 'type' => 'error']; echo json_encode($d); exit;
			endif;
			//
		endif;
		if(DB::$dbs->querySingle('SELECT COUNT(id) FROM audio_us WHERE id_audio = ? and idus = ? and chto = ?', [$audio['id'],$user['id'],$chto]) > 0):
			if($chto == 'useraudio'):
				// сначала посмотрим добавил ли сам оригинальнове видео пользователь 
				if($audio['idus'] == $user['id']):
					// если да, то удалим сначала аудиофайл
					$json1 = $curl->delete('/music/'.$audio['file']);
					if($json1->type == 'error'):
						$d = ['message' => 'Несмогли удалить аудио.', 'type' => 'error'];
						echo json_encode($d); exit;
					else:
						// теперь удалим само аудио оригинальное
						DB::$dbs->querySql('DELETE FROM audio WHERE id = ? LIMIT 1',[$audio['id']]);
					endif;
				endif;
				DB::$dbs->querySql('DELETE FROM audio_us WHERE id_audio = ? and idus = ? and chto = ? LIMIT 1',[$audio['id'],$user['id'],$chto]);
				$d = ['bizes' => 3, 'chto' => 1, 'message' => 'Аудиозапись успешно удалена.', 'type' => 'success'];
			else:
				$d = ['message' => 'От сюда пока аудиозаписи удалять нельзя.', 'type' => 'error'];
			endif;
		else:
			DB::$dbs->querySql('INSERT INTO audio_us SET idus = ?, id_audio = ?, time = ?, name = ?, opis = ?, chto = ?',[$user['id'],$audio['id'],time(),$audio['name'],$audio['opis'],$chto]);
			$d = ['bizes' => 3, 'chtos' => '<span class="material-icons"> delete </span>', 'chto' => 2, 'message' => 'Аудиозапись успешно добавлена.', 'type' => 'success'];
		endif;
		/*
		$d = ['bizes' => 1, 'message' => 'Фотография успешно удалена.', 'type' => 'success'];
		
		*/
		echo json_encode($d); exit;
	break;
}