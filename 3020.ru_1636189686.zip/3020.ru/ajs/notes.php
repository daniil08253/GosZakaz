<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'add':
		$chto = $functions->htmlred($_GET['chto']);
		if($chto == 'user') {
			$qqq = DB::$dbs->queryFetch('SELECT id FROM user WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id']) or $qqq['id'] != $user['id']) {
				$d = ['message' => 'Вы не можете тут создать заметку.', 'type' => 'error'];
				echo json_encode($d); exit;
			}
		}
		$name = $functions->htmlred($_POST['name']);
		$text = $functions->htmlred($_POST['text']);
		if (empty($name) || mb_strlen($name, 'UTF-8') < 3 || mb_strlen($name, 'UTF-8') > 100) {
			$err = 'Не правильная длина названия заметки.';
		}
		if (empty($text) || mb_strlen($text, 'UTF-8') < 3){
			$err = 'Не правильная длина текста заметки.';
		}
		if(isset($err)) {
			$d = ['message' => $err, 'type' => 'error'];
		} else {
			$obr = $functions->wph_cut_by_words(500,$text);
			DB::$dbs->querySql('INSERT INTO notes SET idus = ?, time = ?, name = ?, text = ?, chto = ?, textobr = ?',[$user['id'],time(),$name,$text,$chto,$obr]);
			$idl = DB::$dbs->lastInsertId();
			$d = ['bizes' => 5, 'href' => '/notes'.$id, 'message' => 'Заметка успешно создана.', 'type' => 'success'];
		}
		echo json_encode($d); exit;
	break;
	case 'dell':
		$chto = $functions->htmlred($_GET['chto']);
		if($chto == 'usernotes') {
			$qqq = DB::$dbs->queryFetch('SELECT id,idus FROM notes WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id']) or $qqq['idus'] != $user['id']) {
				$err = 'Вы не можете удалить эту заметку.';
			}
		} else {
			$err = 'Тут нельзя удалять заметки.';
		}
		
		if(isset($err)) {
			$d = ['message' => $err, 'type' => 'error'];
		} else {
			DB::$dbs->querySql('DELETE FROM notes WHERE id = ?',[$qqq['id']]);
			$d = ['bizes' => 1, 'message' => 'Заметка успешно удалена.', 'type' => 'success'];
		}
		echo json_encode($d); exit;
	break;
}