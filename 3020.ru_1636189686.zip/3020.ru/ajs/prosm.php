<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'repost':
		$chto = $functions->htmlred($_GET['chto']);
		if($chto == 'komm'):
			$komm = DB::$dbs->queryFetch('SELECT id FROM komm WHERE id = ? LIMIT 1', [$id]);
		elseif($chto == 'photo'):
			$komm = DB::$dbs->queryFetch('SELECT id FROM photo WHERE id = ? LIMIT 1', [$id]);
		elseif($chto == 'video'):
			$komm = DB::$dbs->queryFetch('SELECT id FROM video WHERE id = ? LIMIT 1', [$id]);
		else:
			$d = ['message' => 'Нельзя от сюда репостить.', 'type' => 'error'];
		endif;
		if(empty($komm['id'])):
			$d = ['message' => 'Ошибка, кажется такого поста нет.', 'type' => 'error'];
		else:
			$dialog = '
			<div class="ovk-diag-cont">
				<div class="_repost">
					<h1>Поделиться</h1>
					<div class="_text">
						<div>Ваш комментарий</div>
						<form action="" id="ajax_formr" method="post" enctype="multipart/form-data" style="margin:0;" onsubmit="return false;">
						<textarea class="expanded-textarea" id="wall-post-input" placeholder="Написать" name="text" style="width: 100%;resize: none;"></textarea>
						<input onclick="saveform (\'/ajs/repost/'.$chto.'/'.$id.'/\',\'#ajax_formr\');return false;" type="submit" value="Написать" class="button">
						</form>
					</div>
				</div>
			</div>';
			$d = ['dialog' => $dialog, 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
}
