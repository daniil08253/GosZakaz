<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'urlstr':
		$url = $functions->htmlred($_POST['url']);
		if (empty($url) || mb_strlen($url, 'UTF-8') < 2 || mb_strlen($url, 'UTF-8') > 50):
			$err = 'Не правильная длина адреса страницы.';
		endif;
		if(DB::$dbs->querySingle('SELECT COUNT(id) FROM url WHERE url = ?', [$url]) > 0):
			$err = 'Такой адресс страницы уже занят.';
		endif;
		if($user['url'] == $url):
			$err = 'У вас сейчас такой же адрес страницы.';
		endif;
		if (!preg_match('|^[a-zA-Z0-9_]+$|i', $url)):
			$err = 'Запрещенные символы в адресе страницы.';
		endif;
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			DB::$dbs->querySql('UPDATE user SET url = ? WHERE id = ? LIMIT 1', [$url,$user['id']]);
			DB::$dbs->querySql('UPDATE url SET url = ? WHERE ads = ? and chto = ? LIMIT 1', [$url,$user['id'],'user']);
			$d = ['bizes' => 1, 'message' => 'Сохранено', 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
	case 'privacy':
	 	$eyevideo = $functions->ints($_POST['eyevideo']);
	 	$eyenotes = $functions->ints($_POST['eyenotes']);
	 	if ($eyevideo < 1 || $eyevideo > 4):
			$eyevideo = 1;
		endif;
	 	if ($eyenotes < 1 || $eyenotes > 4):
			$eyenotes = 1;
		endif;
	 	if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			DB::$dbs->querySql('UPDATE user SET eyevideo = ?, eyenotes = ? WHERE id = ? LIMIT 1', [$eyevideo,$eyenotes,$user['id']]);
			$d = ['bizes' => 1, 'message' => 'Сохранено', 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
}