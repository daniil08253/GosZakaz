<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'addkomm':
		////////////////////////////////////////////////////////////
		if($user['datalast'] > (time() - 3)) {
			DB::$dbs->querySql('UPDATE user SET updatedei = updatedei + 1 WHERE id = ?',[$user['id']]);
			if($user['updatedei'] > 15) {
				$naskb = $user['naskokban'] * 2;
				DB::$dbs->querySql('UPDATE user SET updatedei = 0, naskokban = ?, timeban = ? WHERE id = ?',[$naskb,time() + $naskb,$user['id']]); //updatedei = 0, 
				$d = ['message' => 'Вы забанены.', 'type' => 'error'];
				echo json_encode($d); exit;
			} else {
				$d = ['message' => 'Давай не так быстро.', 'type' => 'error'];
				echo json_encode($d); exit;
			}
		}
		////////////////////////////////////////////////////////////
		$text = $functions->htmlred($_POST['text']);
		$obr = (isset($text) and mb_strlen($text, 'UTF-8') > 280) ? $functions->wph_cut_by_words(280, $text) : NULL;
		$chto = $functions->htmlred($_GET['chto']);
		$url = NULL;
		if($chto == 'user'):
			$qqq = DB::$dbs->queryFetch('SELECT id,closewall FROM user WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id'])): $err = 'Ошибка, кажется такой страницы нет.'; endif;
			if($qqq['closewall'] == 1 and $user['id'] != $qqq['id']): $err = 'Тут отключена возможность писать.'; endif;
			$url = 'id'.$qqq['id'];
		elseif($chto == 'photo'):
			$qqq = DB::$dbs->queryFetch('SELECT id,closewall,idus,id_album FROM photo WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id'])): $err = 'Ошибка, кажется такой страницы нет.'; endif;
			if($qqq['closewall'] == 1 and $user['id'] != $qqq['idus']): $err = 'Тут отключены комментарии.'; endif;
			$url = 'photo'.$qqq['id_album'].'_'.$qqq['id'];
		elseif($chto == 'uservideo'):
			$qqq = DB::$dbs->queryFetch('SELECT id,closewall,idus FROM video_us WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id'])): $err = 'Ошибка, кажется такой страницы нет.'; endif;
			if($qqq['closewall'] == 1 and $user['id'] != $qqq['idus']): $err = 'Тут отключены комментарии.'; endif;
			$url = 'video'.$qqq['idus'].'_'.$qqq['id'];
		elseif($chto == 'usernotes'):
			$qqq = DB::$dbs->queryFetch('SELECT id,closewall,idus FROM notes WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id'])): $err = 'Ошибка, кажется такой страницы нет.'; endif;
			if($qqq['closewall'] == 1 and $user['id'] != $qqq['idus']): $err = 'Тут отключены комментарии.'; endif;
			$url = 'notes'.$qqq['idus'].'_'.$qqq['id'];
		elseif($chto == 'userwallkomm'):
			$qqq = DB::$dbs->queryFetch('SELECT id,idus FROM komm WHERE id = ? and chto = ? LIMIT 1', [$id,'user']);
			if(empty($qqq['id'])):
				$d = ['message' => 'Такого комментария нет.', 'type' => 'error'];
				echo json_encode($d); exit;
			endif;
			$userse = DB::$dbs->queryFetch('SELECT id,closewall FROM user WHERE id = ? LIMIT 1', [$qqq['idus']]);
			if(empty($userse['id'])):
				$d = ['message' => 'Такого пользователя нет.', 'type' => 'error'];
				echo json_encode($d); exit;
			endif;
			if($userse['closewall'] == 1 and $user['id'] != $userse['id']):
				$d = ['message' => 'Тут отключены комментарии.', 'type' => 'error'];
				echo json_encode($d); exit;
			endif;
			$url = 'wall'.$userse['id'].'_'.$qqq['id'];
			/*
			$qqq = DB::$dbs->queryFetch('SELECT id,idus FROM komm WHERE id = ? and chto = ? LIMIT 1', [$id,'user']);
			if(empty($qqq['id'])): $err = 'Ошибка, кажется такой страницы нет.'; endif;
			$userse = DB::$dbs->queryFetch('SELECT id,closewall FROM user WHERE id = ? LIMIT 1', [$qqq['idus']]);
			
			if($userse['closewall'] == 1 and $user['id'] != $userse['id']): $err = 'Тут отключены комментарии.'; endif;
			$url = 'wall'.$userse['id'].'_'.$qqq['id'];
			*/
		else:
			$err = 'Здесь нельзя оставлять комментарии.';
		endif;
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			////////////////////////////////////////////////////////
			if(!empty($_FILES['file']['name'])):
				DB::$dbs->querySql('INSERT INTO komm SET idus = ?, time = ?, message = ?, chto = ?, ids = ?, url = ?, messageobr = ?',[$user['id'],time(),$text,$chto,$qqq['id'],$url,$obr]);
				$idkommes = DB::$dbs->lastInsertId(); // ид коммента
				define('R', $_SERVER['DOCUMENT_ROOT']);
				$name = $functions->htmlred(basename($_FILES['file']['name'])); // фильтруем
				$maxsize = 10; // максимальный размер в мегабайтах
				$whitelist = ['jpg', 'jpeg', 'png', 'svg', 'gif']; // разрешения
				$dir = R.'/files/photo'; // куда загружаем
				$dirm = R.'/files/photo/m'; // куда загружаем меньше версию
				$indos = new SplFileInfo($name);
				$ext = $indos->getExtension();
				$size = $_FILES['file']['size']; // вес файла
				if ($size > (1048576 * $maxsize)): // если большой размер
					$err = "Максимальный вес файла $maxsize МБ.";
				elseif(!in_array($ext, $whitelist)): // если расширение файла не допустимо
					$err = 'Такое разрешение не допустимо.';
				endif;
				///
				if(isset($err)):
					header('location: /'); exit;
				else:
					$tmp_name = $functions->htmlred($_FILES["file"]["tmp_name"]);
					$avas = DOMAIN.'_'.mt_rand(1999,90099).time().'.'.$ext;
					move_uploaded_file($tmp_name, "$dir/$avas");
					////////////////////////////////////////
					if($chto == 'user'): // для стены на странице пользователя
						if ($functions->img_resize($dir.'/'.$avas, $dirm.'/'.$avas, 60, 60)):
							/*
							// сначала смотрим есть ли системный альбом
							if(DB::$dbs->querySingle('SELECT COUNT(id) FROM album WHERE idus = ? and intr = 1 and chto = ?',[$user['id'],$chto]) == 0):
								// создаем альбом потому что его нет
								DB::$dbs->querySql('INSERT INTO album SET idus = ?, name = ?, opis = ?, dell = 0, intr = 1, time = ?, updatealb = ?, chto = ?',[$user['id'],'Фотографии со стены','Фотографии со стены',time(),time(),$chto]);
								$idalb = DB::$dbs->lastInsertId(); // сюда заливаем фото
							else: // Если альбом есть смотрим его id
								$qqq = DB::$dbs->queryFetch('SELECT id FROM album WHERE idus = ? and intr = 1 and dell = 0 and chto = ? LIMIT 1', [$user['id'],$chto]);
								$idalb = $qqq['id']; // сюда заливаем фото
							endif;
							*/
							$qqq = DB::$dbs->queryFetch('SELECT id FROM album WHERE idus = ? and intr = 1 and dell = 0 and chto = ? LIMIT 1', [$user['id'],$chto]);
							// добавляем саму фотографию
							DB::$dbs->querySql('INSERT INTO photo SET idus = ?, id_album = ?, name = ?, time = ?, opis = ?, photo = ?, chto = ?, ids = ?, razr = ?',[$user['id'],$qqq['id'],'Фотография со стены',time(),'Фотография со стены',$avas,$chto,$idkommes,$ext]);
							$idphoto = DB::$dbs->lastInsertId();
							if($chto == 'user'):
								// обновляем пост
								DB::$dbs->querySql('UPDATE komm SET images = ? WHERE id = ?',[$idphoto,$idkommes]);
							endif;
							///
							$curl_files1 = ['file[0]' => curl_file_create($dir.'/'.$avas, 'mimetype')];
							$curl_files2 = ['file[0]' => curl_file_create($dirm.'/'.$avas, 'mimetype')];
							$json1 = $curl->curlload($curl_files1,'photo/');
							$json2 = $curl->curlload($curl_files2,'photo/m/');
							if($json1->type == 'error' or $json2->type == 'error'):
								echo $json1->message; exit();
							else:
								unlink($dir.'/'.$avas);
								unlink($dirm.'/'.$avas);
								DB::$dbs->querySql('UPDATE album SET photosid = ?, updatealb = ? WHERE id = ? and chto = ?',[$avas,time(),$qqq['id'],$chto]);
							endif; 
						else:
							$d = ['message' => 'Вложенное фото нельзя обработать.', 'type' => 'error'];
							echo json_encode($d); exit;
						endif;
					else: // для остальных
						$curl_files1 = ['file[0]' => curl_file_create($dir.'/'.$avas, 'mimetype')];
						$json1 = $curl->curlload($curl_files1,'photo/');
						if($json1->type == 'error'):
							echo $json1->message; exit();
						else:
							DB::$dbs->querySql('INSERT INTO photo SET idus = ?, id_album = ?, name = ?, time = ?, opis = ?, photo = ?, chto = ?, ids = ?',[$user['id'],0,'Фотография со стены',time(),'Фотография со стены',$avas,$chto,$idkommes]);
							$idphoto = DB::$dbs->lastInsertId();
							DB::$dbs->querySql('UPDATE komm SET images = ? WHERE id = ?',[$idphoto,$idkommes]);
							unlink($dir.'/'.$avas);
						endif;
					endif;
					////////////////////////////////////////
				endif;
			else:
				if (empty($text) || mb_strlen($text, 'UTF-8') < 3 || mb_strlen($text, 'UTF-8') > 10000):
					$d = ['message' => 'Короткая длина поста.', 'type' => 'error'];
					echo json_encode($d); exit;
				else:
					DB::$dbs->querySql('INSERT INTO komm SET idus = ?, time = ?, message = ?, chto = ?, ids = ?, url = ?, messageobr = ?',[$user['id'],time(),$text,$chto,$qqq['id'],$url,$obr]);
					$idkommes = DB::$dbs->lastInsertId();
				endif;
			endif;
			$html = '<div>'.$text.'</div>';
			$d = ['bizes' => 3, 'html' => $html, 'message' => 'Успешно опубликовано.', 'type' => 'success'];
			////////////////////////////////////////////////////////
		endif;
		echo json_encode($d); exit;
	break;
	case 'dellkomm':
		$komm = DB::$dbs->queryFetch('SELECT id,idus,images,repost,chto,ids FROM komm WHERE id = ? LIMIT 1', [$id]);
		if($komm['chto'] == 'user'):
			$qqq = DB::$dbs->queryFetch('SELECT id FROM user WHERE id = ? LIMIT 1', [$komm['ids']]);
			if(empty($qqq['id'])): 
				$err = 'Такой страницы нет.';
			endif;
			if(empty($err) and ($user['id'] != $komm['idus'] and $qqq['id'] != $user['id'])):
				$err = 'Это не ваш комментарий.';
			endif;
		elseif($komm['chto'] == 'photo'):
			$qqq = DB::$dbs->queryFetch('SELECT id,idus FROM photo WHERE id = ? LIMIT 1', [$komm['ids']]);
			if(empty($qqq['id'])): 
				$err = 'Такой страницы нет.';
			endif;
			if(empty($err) and ($user['id'] != $komm['idus'] and $qqq['idus'] != $user['id'])):
				$err = 'Это не ваш комментарий.';
			endif;
		elseif($komm['chto'] == 'uservideo'):
			$qqq = DB::$dbs->queryFetch('SELECT id,idus FROM video_us WHERE id = ? LIMIT 1', [$komm['ids']]);
			if(empty($qqq['id'])): 
				$err = 'Такой страницы нет.';
			endif;
			if(empty($err) and ($user['id'] != $komm['idus'] and $qqq['idus'] != $user['id'])):
				$err = 'Это не ваш комментарий.';
			endif;
		elseif($komm['chto'] == 'userwallkomm'):
			$wall = DB::$dbs->queryFetch('SELECT id,idus,ids FROM komm WHERE id = ? LIMIT 1', [$komm['ids']]);
			$qqq = DB::$dbs->queryFetch('SELECT id FROM user WHERE id = ? LIMIT 1', [$wall['ids']]);
			if(empty($qqq['id'])): $err = 'Такой страницы нет.'; endif;
			if(empty($err) and ($user['id'] != $komm['idus'] and $qqq['id'] != $user['id'])):
				$err = 'Это не ваш комментарий.';
			endif;
		elseif($komm['chto'] == 'usernotes'):
			$qqq = DB::$dbs->queryFetch('SELECT id,idus FROM notes WHERE id = ? LIMIT 1', [$komm['ids']]);
			if(empty($qqq['id'])): 
				$err = 'Такой страницы нет.';
			endif;
			if(empty($err) and ($user['id'] != $komm['idus'] and $qqq['idus'] != $user['id'])):
				$err = 'Это не ваш комментарий.';
			endif;
		else:
			$err = 'Такого раздела нет.';
		endif;
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			DB::$dbs->querySql('DELETE FROM komm WHERE id = ?',[$komm['id']]);
			$d = ['message' => 'Успешно удалено', 'ids' => '#posts_'.$id, 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
	case 'repost':
		$chto = $functions->htmlred($_GET['chto']);
		$text = $functions->htmlred($_POST['text']);
		$images = NULL;
		$url = NULL;
		if($chto == 'komm'):
			$komm = DB::$dbs->queryFetch('SELECT id FROM komm WHERE id = ? LIMIT 1', [$id]);
		elseif($chto == 'photo'):
			$komm = DB::$dbs->queryFetch('SELECT id,id_album,idus FROM photo WHERE id = ? LIMIT 1', [$id]);
			$images = $komm['id'];
			$url = 'photo'.$komm['idus'].'_'.$komm['id'];
		elseif($chto == 'video'):
			$komm = DB::$dbs->queryFetch('SELECT id,idus FROM video WHERE id = ? LIMIT 1', [$id]);
			$images = NULL;
			$url = 'video'.$komm['idus'].'_'.$komm['id'];
		else:
			$d = ['message' => 'Нельзя от сюда репостить.', 'type' => 'error'];
		endif;
		if(empty($komm['id'])):
			$d = ['message' => 'Ошибка, кажется такого поста нет.', 'type' => 'error'];
		else:
			DB::$dbs->querySql('INSERT INTO komm SET idus = ?, time = ?, message = ?, chto = ?, ids = ?, repost = ?, images = ?, url = ?,	repostchto = ?',[$user['id'],time(),$text,'user',$user['id'],$komm['id'],$images,$url,$chto]);
			$d = ['message' => 'Успешно', 'bizes' => 4, 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
}