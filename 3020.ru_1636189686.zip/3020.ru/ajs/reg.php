<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
// 3020.ru - скрипты тут
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		if(isset($user['id'])): header('location: /'); exit; endif;
		$name = $functions->htmlred($_POST['name']);
		$fame = $functions->htmlred($_POST['fame']);
		$sex = $functions->htmlred($_POST['sex']);
		$dayr = $functions->htmlred($_POST['dayr']);
		$email = $functions->htmlred($_POST['email']);
		$password = $functions->htmlred($_POST['password']);
		if (empty($name) || mb_strlen($name, 'UTF-8') < 3 || mb_strlen($name, 'UTF-8') > 100):
			$err = 'Не правильная длина имени.';
		endif;
		if (empty($fame) || mb_strlen($fame, 'UTF-8') < 3 || mb_strlen($fame, 'UTF-8') > 100):
			$err = 'Не правильная длина фамилии.';
		endif;
		if(empty($sex) || $sex < 1 || $sex > 2):
			$err = 'Пол указан не верно.';
		endif;
		if(empty($dayr) || $functions->validateDate($dayr,'Y-m-d') === false):
			$err = 'Дата рождения указана не верно.';
		endif;
		if (empty($email) || mb_strlen($email, 'UTF-8') < 5 || mb_strlen($email, 'UTF-8') > 100):
			$err = 'Не правильная длина Email.'.$dayr;
		elseif (filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE):
			$err = 'Email указан не верно.';
		elseif(DB::$dbs->querySingle('SELECT COUNT(`id`) FROM user WHERE email = ?', [$email]) > 0):
			$err = 'Пользователь с данным email зарегистрирован.';
		endif;
		if (empty($password) || mb_strlen($password, 'UTF-8') < 6 || mb_strlen($password, 'UTF-8') > 20):
			$err = 'Не правильная длина пароля.';
		endif;

		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			$token = password_hash(time().$password, PASSWORD_DEFAULT);
			$pass = password_hash($password, PASSWORD_DEFAULT);
			$invite = $functions->randdj8iad(15);
			DB::$dbs->querySql('INSERT INTO user SET token = ?, name = ?, fame = ?, sex = ?, dayr = ?, email = ?, password = ?, datareg = ?, invite = ?',[$token,$name,$fame,$sex,$dayr,$email,$pass,time(),$invite]);
			$idl = DB::$dbs->lastInsertId();
			/////////////////////создаем альбымы
			// Фотографии со страницы
			DB::$dbs->querySql('INSERT INTO album SET idus = ?, name = ?, opis = ?, dell = 0, intr = 0, time = ?, updatealb = ?, chto = ?, photosid = ?',[$idl,'Фотографии со страницы','Фотографии со страницы',time(),time(),'user','camera_200.png']);
			DB::$dbs->querySql('INSERT INTO album SET idus = ?, name = ?, opis = ?, dell = 0, intr = 1, time = ?, updatealb = ?, chto = ?, photosid = ?',[$idl,'Фотографии со стены','Фотографии со стены',time(),time(),'user','camera_200.png']);
			// Создаем и обновляем url для страницы
			DB::$dbs->querySql('INSERT INTO url SET chto = ?, url = ?, ads = ?',['user','id'.$idl,$idl]);
			DB::$dbs->querySql('UPDATE user SET url = ? WHERE id = ?',['id'.$idl,$idl]);
			//
			setcookie('token', $token, time()+60*60*24*7, '/');
			$d = ['url' => '/id'.$idl, 'type' => 'success'];
		endif;
		echo json_encode($d); exit;

		//$d = ['message' => 'Вы успешно зарегистрировались.', 'type' => 'error'];
		
	break;
	case 'aut':
		$email = $functions->htmlred($_POST['email']);
		$password = $functions->htmlred($_POST['password']);
		if (empty($email) || mb_strlen($email, 'UTF-8') < 5 || mb_strlen($email, 'UTF-8') > 100):
			$err = 'Email указан не верно.';
		elseif(DB::$dbs->querySingle('SELECT COUNT(id) FROM user WHERE email = ?', [$email]) == 0):
			$err = 'Такого пользователя нет.';
		endif;
		if(empty($password) || mb_strlen($password) < 6 || mb_strlen($password) > 20):
			$err = 'Пароль должен быть от 6-ти до 40-ка символов.';
			$pass = 1; // Если нет такой ошибки
		endif;
		$row = DB::$dbs->queryFetch('SELECT password,id FROM user WHERE email = ? LIMIT 1', [$email]);
		if (empty($pass) and (password_verify($password, $row['password']) === false)):
			$err = 'Email или пароль не правильный.';
		endif;
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			$token = password_hash(time().$password, PASSWORD_DEFAULT);
			DB::$dbs->querySql('UPDATE user SET token = ? WHERE id = ? LIMIT 1', [$token,$row['id']]);
			setcookie('token', $token, time()+60*60*24*7, '/');
			$d = ['url' => '/id'.$row['id'], 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
}