<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'dellphoto':
		$chto = $functions->htmlred($_GET['chto']);
		$qqq222 = DB::$dbs->queryFetch('SELECT id,idus,photo,id_album FROM photo WHERE id = ? and idus = ? and chto = ? LIMIT 1', [$id,$user['id'],$chto]);
		if(empty($qqq222['id'])):
			$d = ['message' => 'Такой фотографии нет', 'type' => 'error'];
			echo json_encode($d); exit;
		endif;
		if($chto == 'user'):
			$json = $curl->delete('/photo/'.$qqq222['photo']);
			$json2 = $curl->delete('/photo/m/'.$qqq222['photo']);
			if($json->type == 'error'):
				$d = ['message' => $json->message, 'type' => 'error'];
				echo json_encode($d); exit;
			else:
				DB::$dbs->querySql('DELETE FROM photo WHERE id = ? LIMIT 1',[$qqq222['id']]);
				// Если в альбоме нет фото
				if(DB::$dbs->querySingle('SELECT COUNT(id) FROM photo WHERE id_album = ?',[$qqq222['id_album']]) == 0):
					DB::$dbs->querySql('UPDATE album SET photosid = ? WHERE id = ? LIMIT 1', ['camera_200.png',$qqq222['id_album']]);
				else: // если есть то обновляем
					$qqq3daw = DB::$dbs->queryFetch('SELECT photo FROM photo WHERE id_album = ? ORDER BY time DESC LIMIT 1', [$qqq222['id_album']]);
					DB::$dbs->querySql('UPDATE album SET photosid = ? WHERE id = ? LIMIT 1', [$qqq3daw['photo'],$qqq222['id_album']]);
				endif;
				// Если фото является аватаром
				if($user['avatar'] == $qqq222['id']):
					DB::$dbs->querySql('UPDATE user SET avatar = NULL WHERE id = ? LIMIT 1', [$user['id']]);
				endif;
				// Если были комментарии к этой фото, тоже удаляем
				if(DB::$dbs->querySingle('SELECT COUNT(id) FROM komm WHERE chto = ? and ids = ?',['photo',$qqq222['id']]) > 0):
					$sql12 = DB::$dbs->querySql('SELECT id,images FROM komm WHERE chto = ? and ids = ? ORDER BY time DESC LIMIT 2',['photo',$qqq222['id']])->fetchAll(PDO::FETCH_ASSOC);
					foreach ($sql12 as $sqlls12 => $files12):
						if(isset($files12['images'])):
							$qqq555 = DB::$dbs->queryFetch('SELECT photo,id FROM photo WHERE id = ? LIMIT 1', [$files12['images']]);
							$curl->delete('/photo/'.$qqq555['photo']);
							DB::$dbs->querySql('DELETE FROM photo WHERE id = ? LIMIT 1',[$qqq555['id']]);
						endif;
						DB::$dbs->querySql('DELETE FROM komm WHERE chto = ? and ids = ? LIMIT 1',['photo',$qqq222['id']]);
					endforeach;
				endif;
				//
				$d = ['bizes' => 1, 'message' => 'Фотография успешно удалена.', 'type' => 'success'];
				echo json_encode($d); exit;
			endif;
		else:
			$d = ['message' => 'Упссс...', 'type' => 'error'];
			echo json_encode($d); exit;
		endif;
	break;
	case 'closekommphoto':
		$chto = $functions->htmlred($_GET['chto']);
		$qqq222 = DB::$dbs->queryFetch('SELECT id,closewall FROM photo WHERE id = ? and idus = ? and chto = ? LIMIT 1', [$id,$user['id'],$chto]);
		if(empty($qqq222['id'])):
			$d = ['message' => 'Такой фотографии нет', 'type' => 'error'];
			echo json_encode($d); exit;
		endif;
		if($chto == 'user'):
			$bas = $qqq222['closewall'] == 0 ? 1 : 0;
			$bass3 = $qqq222['closewall'] == 0 ? '<span class="material-icons">open_in_new</span>Открыть комментарии' : '<span class="material-icons">close</span>Закрыть комментарии';
			DB::$dbs->querySql('UPDATE photo SET closewall = ? WHERE id = ? LIMIT 1', [$bas,$qqq222['id']]);
			$d = ['chtos' => $bass3, 'message' => 'Успешно изменено.', 'type' => 'success'];
			echo json_encode($d); exit;
		else:
			$d = ['message' => 'Упссс...', 'type' => 'error'];
			echo json_encode($d); exit;
		endif;
	break;
	case 'closekommvideo':
		$chto = $functions->htmlred($_GET['chto']);
		$qqq222 = DB::$dbs->queryFetch('SELECT id,closewall FROM video_us WHERE id = ? and idus = ? and chto = ? LIMIT 1', [$id,$user['id'],$chto]);
		if(empty($qqq222['id'])):
			$d = ['message' => 'Такой видеозаписи нет.', 'type' => 'error'];
			echo json_encode($d); exit;
		endif;
		if($chto == 'uservideo'):
			$bas = $qqq222['closewall'] == 0 ? 1 : 0;
			$bass3 = $qqq222['closewall'] == 0 ? 'Открыть комментарии' : 'Закрыть комментарии';
			DB::$dbs->querySql('UPDATE video_us SET closewall = ? WHERE id = ? LIMIT 1', [$bas,$qqq222['id']]);
			$d = ['chtos' => $bass3, 'message' => 'Успешно изменено.', 'type' => 'success'];
			echo json_encode($d); exit;
		else:
			$d = ['message' => 'Упссс...', 'type' => 'error'];
			echo json_encode($d); exit;
		endif;
	break;
}