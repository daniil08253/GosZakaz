<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
// 3020.ru - скрипты тут
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'addvideo':
		$chto = $functions->htmlred($_GET['chto']);
		if(empty($id)): exit('Ошибка с id'); endif;
		if($chto == 'uservideo'):
			if($user['id'] != $id): $err = 'Вам нельзя сюда добавлять видео.'; endif;
		else:
			$err = 'Вам нельзя сюда добавлять видео.';
		endif;
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			$vowels = ['https://www.youtube.com', 'https://youtube.com', 'youtube.com', 'https://youtu.be', 'youtu.be'];
			$url = $functions->htmlred($_POST['url']);
			$prurls = str_replace($vowels, '', $url, $dwad3wd);
			$err = (empty($url) or $dwad3wd == 0) ? 'Эта ссылка не с youtube.com.' : NULL;
			if(isset($err)):
				$d = ['message' => $err, 'type' => 'error'];
			else:
				$fas = $functions->getYouTubeVideoID($url);
				$err = empty($fas) ? 'Несмогли получить ид видео.' : NULL;
				if(isset($err)):
					$d = ['message' => $err, 'type' => 'error'];
				else:
					$api_key = 'AIzaSyBRZjDiMncmvybR1BcdALAuxZNNJiZxvjg';
					$api_url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&id='.$fas.'&key='.$api_key;
					$data = json_decode(file_get_contents($api_url));
					$img = $data->items[0]->snippet->thumbnails->medium->url;
					// получаем расширение файла
					$indos = new SplFileInfo($img);
					$ext = $indos->getExtension();
					// генерируем новое название
					$avas = DOMAIN.'_'.mt_rand(9999,999999).time().'.'.$ext;
					//
					$curl_files1 = ['file[0]' => curl_file_create($img, 'mimetype', $avas)];
					$json1 = $curl->curlload($curl_files1,'video/');
					if($json1->type == 'error'):
						$d = ['message' => 'Не удалось добавить видео.', 'type' => 'error'];
					else:
						$name = isset($data->items[0]->snippet->title) ? $data->items[0]->snippet->title : NULL;
						$opis = isset($data->items[0]->snippet->description) ? $data->items[0]->snippet->description : NULL;
						DB::$dbs->querySql('INSERT INTO video SET idus = ?, chto = ?, time = ?, url = ?, imag = ?, name = ?, opis = ?',[$user['id'],$chto,time(),$fas,$avas,$name,$opis]);
						$idvideo = DB::$dbs->lastInsertId();
						DB::$dbs->querySql('INSERT INTO video_us SET chto = ?, id_video = ?, time = ?, idus = ?, imag = ?, name = ?, opis = ?',[$chto,$idvideo,time(),$user['id'],$avas,$name,$opis]);
						$idvideous = DB::$dbs->lastInsertId();
						$html = "<div class='row _08f8ghrg83qgh'>
							<div class='cs5 _oiwofh487tg9g'><img src='".CDN."/video/{$avas}'></div>
							<div class='col'>
								<div><a href='".DOMAIN2."/video{$user['id']}_{$idvideous}'><h4>{$name}</h4></a></div>
								<div class='_fw8hf843yhtgf9r'>".((empty($opis) and mb_strlen($opis, 'UTF-8') == 0) ? 'Нет описания.' : $opis)."</div>
							</div>
						</div>";
						$d = ['bizes' => 6, 'message' => 'Успешно добавлено.', 'html' => $html, 'type' => 'success'];
					endif;
				endif;
			endif;
		endif;
		echo json_encode($d); exit;
	break;
	case 'dellvideo':
		$chto = $functions->htmlred($_GET['chto']);
		$video = DB::$dbs->queryFetch('SELECT id,idus,imag,name,opis FROM video WHERE id = ? LIMIT 1', [$id]);
		if(empty($video['id'])):
			$d = ['message' => 'Такого видео нет.', 'type' => 'error'];
			echo json_encode($d); exit;
		endif;
		if(DB::$dbs->querySingle('SELECT COUNT(id) FROM video_us WHERE id_video = ? and idus = ? and chto = ?', [$video['id'],$user['id'],$chto]) > 0):
			if($chto == 'uservideo'):
				// сначала посмотрим добавил ли сам оригинальнове видео пользователь 
				if($video['idus'] == $user['id']):
					// если да, то удалим сначала изображение от видео
					$json1 = $curl->delete('/video/'.$video['imag']);
					if($json1->type == 'error'):
						$d = ['message' => 'Несмогли удалить превью от видео.', 'type' => 'error'];
						echo json_encode($d); exit;
					else:
						// теперь удалим само видео оригинальное
						DB::$dbs->querySql('DELETE FROM video WHERE id = ? LIMIT 1',[$video['id']]);
					endif;
				endif;
				DB::$dbs->querySql('DELETE FROM video_us WHERE id_video = ? and idus = ? and chto = ? LIMIT 1',[$video['id'],$user['id'],$chto]);
				$d = ['bizes' => 1, 'message' => 'Видео успешно удалено.', 'type' => 'success'];
			else:
				$d = ['message' => 'От сюда пока видеозаписи удалять нельзя.', 'type' => 'error'];
			endif;
		else:
			DB::$dbs->querySql('INSERT INTO video_us SET chto = ?, id_video = ?, time = ?, imag = ?, name = ?, opis = ?, idus = ?',[$chto,$video['id'],time(),$video['imag'],$video['name'],$video['opis'],$user['id']]);
			$d = ['message' => 'Видео добавлено', 'type' => 'error'];
		endif;
		echo json_encode($d); exit;
	break;
}