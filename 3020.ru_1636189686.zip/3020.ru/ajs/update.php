<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
// 3020.ru - скрипты тут
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'friends':
		// проверяем есть ли в друзьях
		if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends WHERE (idus = ? AND cogo = ?) OR (idus = ? AND cogo = ?) LIMIT 1',[$user['id'],$id,$id,$user['id']]) == 0): // если нет в друзьях
			if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE (idus = ? AND cogo = ?) OR (idus = ? AND cogo = ?) LIMIT 1',[$user['id'],$id,$id,$user['id']]) == 0): // смотрим есть ли в подписчиках
				$message = 'Заяка успешно отправлена.';
				$chtos = 'Отменить заявку';
				DB::$dbs->querySql('INSERT INTO friends_new SET idus = ?, cogo = ?, time = ?',[$user['id'],$id,time()]);
			else:
				if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE idus = ? AND cogo = ? LIMIT 1',[$id,$user['id']]) == 0):
					$message = 'Заяка успешно отменена.';
					$chtos = 'Добавить в друзья';
					DB::$dbs->querySql('DELETE FROM friends_new WHERE idus = ? and cogo = ?',[$user['id'],$id]);
				else:
					$message = 'Подтвердили дружбу.';
					$chtos = 'Удалить из друзей';
					//Удаляем сначала из подписчиков
					DB::$dbs->querySql('DELETE FROM friends_new WHERE idus = ? and cogo = ?',[$user['id'],$id]);
					DB::$dbs->querySql('DELETE FROM friends_new WHERE idus = ? and cogo = ?',[$id,$user['id']]);
					// Добавляем друг друга в друзья
					DB::$dbs->querySql('INSERT INTO friends SET idus = ?, cogo = ?, time = ?',[$user['id'],$id,time()]);
					DB::$dbs->querySql('INSERT INTO friends SET idus = ?, cogo = ?, time = ?',[$id,$user['id'],time()]);
				endif;
			endif;
		else: // если есть в друзьях
			$message = 'Удалили из друзей.';
			$chtos = 'Подтвердить заявку';
			//Удаляем сначала из друзей
			DB::$dbs->querySql('DELETE FROM friends WHERE idus = ? and cogo = ?',[$user['id'],$id]);
			DB::$dbs->querySql('DELETE FROM friends WHERE idus = ? and cogo = ?',[$id,$user['id']]);
			// Добавляем в подписчики кого удалили
			DB::$dbs->querySql('INSERT INTO friends_new SET idus = ?, cogo = ?, time = ?',[$id,$user['id'],time()]);
		endif;





		/*






		if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE idus = ? and cogo = ?',[$user['id'],$id]) == 0):
			if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE idus = ? and cogo = ?',[$id,$user['id']]) == 0):
				$message = 'Заяка успешно отправлена.';
				$chtos = 'Отменить заявку';
				DB::$dbs->querySql('INSERT INTO friends_new SET idus = ?, cogo = ?, time = ?',[$user['id'],$id,time()]);
			else:
				$message = 'Заяка подтверждена.';
				$chtos = 'Удалить из друзей';
				//Удаляем сначала из подписчиков
				DB::$dbs->querySql('DELETE FROM friends_new WHERE idus = ? and cogo = ?',[$user['id'],$id]);
				DB::$dbs->querySql('DELETE FROM friends_new WHERE idus = ? and cogo = ?',[$id,$user['id']]);
				// Добавляем друг друга в друзья
				DB::$dbs->querySql('INSERT INTO friends SET idus = ?, cogo = ?, time = ?',[$user['id'],$id,time()]);
				DB::$dbs->querySql('INSERT INTO friends SET idus = ?, cogo = ?, time = ?',[$id,$user['id'],time()]);
			endif;
		else:
			if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends WHERE idus = ? AND cogo = ? LIMIT 1',[$user['id'],$id]) == 0):
				$message = 'Заяка успешно отменена.';
				$chtos = 'Добавить в друзья';
				DB::$dbs->querySql('DELETE FROM friends_new WHERE idus = ? and cogo = ?',[$user['id'],$id]);
			else:
				$message = 'Удален из друзей.';
				$chtos = 'Подтвердить заявку';
			endif;
			//
		endif;
		*/
		$d = ['message' => $message, 'chtos' => $chtos, 'type' => 'success'];
		echo json_encode($d); exit;
	break;
}