<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
// 3020.ru - скрипты тут
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'osn':
		$name = $functions->htmlred($_POST['name']);
		$fame = $functions->htmlred($_POST['fame']);
		$nickname = $functions->htmlred($_POST['nickname']);
		$status = $functions->htmlred($_POST['status']);
		$marialstatus = $functions->ints($_POST['marialstatus']);
		$politviews = $functions->ints($_POST['politviews']);
		$sex = $functions->ints($_POST['sex']);
		$dayr = $functions->htmlred($_POST['dayr']);
		//
		if (empty($name) || mb_strlen($name, 'UTF-8') < 3 || mb_strlen($name, 'UTF-8') > 100):
			$err = 'Не правильная длина имени.';
		endif;
		if (empty($fame) || mb_strlen($fame, 'UTF-8') < 3 || mb_strlen($fame, 'UTF-8') > 100):
			$err = 'Не правильная длина фамилии.';
		endif;
		//
		if(mb_strlen($nickname, 'UTF-8') > 0):
			if (mb_strlen($nickname, 'UTF-8') < 2 || mb_strlen($nickname, 'UTF-8') > 100):
				$err = 'Не правильная длина никнейма.';
			endif;
		else:
			$nickname = NULL;
		endif;
		//
		if(mb_strlen($status, 'UTF-8') > 0):
			if (mb_strlen($status, 'UTF-8') < 2 || mb_strlen($status, 'UTF-8') > 100):
				$err = 'Не правильная длина статуса.';
			endif;
		else:
			$status = NULL;
		endif;
		//
		if($marialstatus < 0 || $marialstatus > 8):
			$err = 'Семейное положение указано не верно.';
		endif;
		//
		if($politviews < 0 || $politviews > 9):
			$err = 'Политический взгляд указан не верно.';
		endif;
		//
		if(empty($sex) || $sex < 1 || $sex > 2):
			$err = 'Пол указан не верно.';
		endif;
		//
		if(empty($dayr) || $functions->validateDate($dayr,'Y-m-d') === false):
			$err = 'Дата рождения указана не верно.';
		endif;
		//
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			DB::$dbs->querySql('UPDATE user SET name = ?, fame = ?, nickname = ?, status = ?, marialstatus = ?, sex = ?, dayr = ?, politviews = ? WHERE id = ? LIMIT 1', [$name,$fame,$nickname,$status,$marialstatus,$sex,$dayr,$politviews,$user['id']]);
			$d = ['bizes' => 1, 'message' => 'Сохранено', 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
	case 'kont':
		$email2 = $functions->htmlred($_POST['email']);
		$telegram = $functions->htmlred($_POST['telegram']);
		$city = $functions->htmlred($_POST['city']);
		$adress = $functions->htmlred($_POST['adress']);
		//
		if(mb_strlen($email2, 'UTF-8') > 0):
			if (mb_strlen($email2, 'UTF-8') < 2 || mb_strlen($email2, 'UTF-8') > 100):
				$err = 'Не правильная длина электронной	почты.';
			elseif (filter_var($email2, FILTER_VALIDATE_EMAIL) === FALSE):
				$err = 'Email указан не верно.';
			endif;
		else:
			$email2 = NULL;
		endif;
		//
		if(mb_strlen($telegram, 'UTF-8') > 0):
			if (mb_strlen($telegram, 'UTF-8') < 2 || mb_strlen($telegram, 'UTF-8') > 100):
				$err = 'Не правильная длина telegram.';
			endif;
		else:
			$telegram = NULL;
		endif;
		//
		if(mb_strlen($city, 'UTF-8') > 0):
			if (mb_strlen($city, 'UTF-8') < 2 || mb_strlen($city, 'UTF-8') > 100):
				$err = 'Не правильная длина города.';
			endif;
		else:
			$city = NULL;
		endif;
		//
		if(mb_strlen($adress, 'UTF-8') > 0):
			if (mb_strlen($adress, 'UTF-8') < 2 || mb_strlen($adress, 'UTF-8') > 100):
				$err = 'Не правильная длина адреса.';
			endif;
		else:
			$adress = NULL;
		endif;
		//
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			DB::$dbs->querySql('UPDATE user SET email2 = ?, telegram = ?, city = ?, adress = ? WHERE id = ? LIMIT 1', [$email2,$telegram,$city,$adress,$user['id']]);
			$d = ['bizes' => 1, 'message' => 'Сохранено', 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
	case 'inter':
		$interests = $functions->htmlred($_POST['interests']);
		$lovemusic = $functions->htmlred($_POST['lovemusic']);
		$lovemovie = $functions->htmlred($_POST['lovemovie']);
		$lovetvshow = $functions->htmlred($_POST['lovetvshow']);
		$lovebook = $functions->htmlred($_POST['lovebook']);
		$lovecit = $functions->htmlred($_POST['lovecit']);
		$osebe = $functions->htmlred($_POST['osebe']);
		//
		if(mb_strlen($interests, 'UTF-8') > 0):
			if (mb_strlen($interests, 'UTF-8') < 2 || mb_strlen($interests, 'UTF-8') > 200):
				$err = 'Не правильная длина о интересах.';
			endif;
		else:
			$interests = NULL;
		endif;
		//
		if(mb_strlen($lovemusic, 'UTF-8') > 0):
			if (mb_strlen($lovemusic, 'UTF-8') < 2 || mb_strlen($lovemusic, 'UTF-8') > 200):
				$err = 'Не правильная длина о любимой музыке.';
			endif;
		else:
			$lovemusic = NULL;
		endif;
		//
		if(mb_strlen($lovemovie, 'UTF-8') > 0):
			if (mb_strlen($lovemovie, 'UTF-8') < 2 || mb_strlen($lovemovie, 'UTF-8') > 200):
				$err = 'Не правильная длина о любимых фильмах.';
			endif;
		else:
			$lovemovie = NULL;
		endif;
		//
		if(mb_strlen($lovetvshow, 'UTF-8') > 0):
			if (mb_strlen($lovetvshow, 'UTF-8') < 2 || mb_strlen($lovetvshow, 'UTF-8') > 200):
				$err = 'Не правильная длина о любимых шоу.';
			endif;
		else:
			$lovetvshow = NULL;
		endif;
		//
		if(mb_strlen($lovebook, 'UTF-8') > 0):
			if (mb_strlen($lovebook, 'UTF-8') < 2 || mb_strlen($lovebook, 'UTF-8') > 200):
				$err = 'Не правильная длина о любимых книгах.';
			endif;
		else:
			$lovebook = NULL;
		endif;
		//
		if(mb_strlen($lovecit, 'UTF-8') > 0):
			if (mb_strlen($lovecit, 'UTF-8') < 2 || mb_strlen($lovecit, 'UTF-8') > 200):
				$err = 'Не правильная длина о любимых цитатах.';
			endif;
		else:
			$lovecit = NULL;
		endif;
		//
		if(mb_strlen($osebe, 'UTF-8') > 0):
			if (mb_strlen($osebe, 'UTF-8') < 2 || mb_strlen($osebe, 'UTF-8') > 200):
				$err = 'Не правильная длина о себе.';
			endif;
		else:
			$osebe = NULL;
		endif;
		//
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			DB::$dbs->querySql('UPDATE user SET interests = ?, lovemusic = ?, lovemovie = ?, lovetvshow = ?, lovebook = ?, lovecit = ?, osebe = ? WHERE id = ? LIMIT 1', [$interests,$lovemusic,$lovemovie,$lovetvshow,$lovebook,$lovecit,$osebe,$user['id']]);
			$d = ['bizes' => 1, 'message' => 'Сохранено', 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
}