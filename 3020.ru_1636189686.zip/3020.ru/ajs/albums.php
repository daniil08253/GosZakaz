<?php $fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
if($fasa == 0): exit('Ошибка'); endif;
require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'addalbums':
		$name = $functions->htmlred($_POST['name']);
		$opis = $functions->htmlred($_POST['opis']);
		$chto = $functions->htmlred($_GET['chto']);

		if($chto == 'user'):
			$qqq = DB::$dbs->queryFetch('SELECT id FROM user WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id'])):
				$d = ['message' => 'Вам нельзя создавать тут альбомы.', 'type' => 'error'];
				echo json_encode($d); exit;
			endif;
		else:
			$d = ['message' => 'Вам нельзя создавать тут альбомы.', 'type' => 'error'];
			echo json_encode($d); exit;
		endif;

		if (empty($name) || mb_strlen($name, 'UTF-8') < 3 || mb_strlen($name, 'UTF-8') > 150):
			$err = 'Название альбома должно быть от 3-х до 150 символов.';
		endif;
		$opis = (mb_strlen($opis, 'UTF-8') <= 0) ? NULL : $opis;
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			DB::$dbs->querySql('INSERT INTO album SET idus = ?, name = ?, opis = ?, dell = 1, intr = 3, time = ?, updatealb = ?, chto = ?, photosid = ?',[$user['id'],$name,$opis,time(),time(),$chto,'camera_200.png']);
			$idalb = DB::$dbs->lastInsertId();
			$d = ['url' => '/albums'.$id.'_'.$idalb, 'message' => 'Альбом успешно создан.', 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
	case 'dellalbums':
		$chto = $functions->htmlred($_GET['chto']);
		$qqq222 = DB::$dbs->queryFetch('SELECT id,idus FROM album WHERE id = ? and dell = 1 LIMIT 1', [$id]);
		if(empty($qqq222['id'])): $d = ['message' => 'Такого альбома нет.', 'type' => 'error']; echo json_encode($d); exit; endif;
		if($chto == 'user'):
			if($qqq222['idus'] != $user['id']):
				$err = 'Вы не можете удалять этот альбом.';
			endif;
		else:
			$err = 'Ошибка удаления альбома.';
		endif;
		if(isset($err)):
			$d = ['message' => $err, 'type' => 'error'];
		else:
			// Смотрим все фотографии перед удаление самого альбома
			$sql1 = DB::$dbs->querySql('SELECT photo,id FROM photo WHERE id_album = ? ORDER BY time DESC LIMIT 100',[$qqq222['id']])->fetchAll(PDO::FETCH_ASSOC);
			foreach ($sql1 as $sqlls => $files):
				//////////// Если были комментарии к этой фото, тоже удаляем
				if(DB::$dbs->querySingle('SELECT COUNT(id) FROM komm WHERE ids = ?',[$files['id']]) > 0):
					$kommsql = DB::$dbs->querySql('SELECT id,images FROM komm WHERE ids = ? ORDER BY time DESC LIMIT 100',[$files['id']])->fetchAll(PDO::FETCH_ASSOC);
					foreach ($kommsql as $sqlls => $komm):
						if(isset($komm['images'])):
							$qqq555 = DB::$dbs->queryFetch('SELECT photo,id FROM photo WHERE id = ? LIMIT 1', [$komm['images']]);
							$curl->delete('/photo/'.$qqq555['photo']);
							DB::$dbs->querySql('DELETE FROM photo WHERE id = ? LIMIT 1',[$qqq555['id']]);
						endif;
						DB::$dbs->querySql('DELETE FROM komm WHERE id = ? LIMIT 1',[$komm['id']]);
					endforeach;
				endif;
				////////////
				$json = $curl->delete('/photo/'.$files['photo']);
				DB::$dbs->querySql('DELETE FROM photo WHERE id = ? LIMIT 1',[$files['id']]);
			endforeach;
			DB::$dbs->querySql('DELETE FROM album WHERE id = ? LIMIT 1',[$qqq222['id']]);
			$d = ['bizes' => 2, 'message' => 'Успешно удалено.', 'type' => 'success'];
		endif;
		echo json_encode($d); exit;
	break;
}