<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		//if(empty($user['id'])): header('location: /'); exit; endif;
		$chto = $functions->htmlred($_GET['chto']);
		// проверка пользователя
		$qqq = DB::$dbs->queryFetch('SELECT id FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		// проверка видео
		$idal = $functions->ints($_GET['idal']);
		$qqq222 = DB::$dbs->queryFetch('SELECT name,id,id_video,closewall,name,time,idus FROM video_us WHERE id = ? and idus = ? and chto = ? LIMIT 1', [$idal,$qqq['id'],$chto]);
		if(empty($qqq222['id'])): header('location: /'); exit; endif;
		//
		$videogl = DB::$dbs->queryFetch('SELECT url,id,idus FROM video WHERE id = ? LIMIT 1', [$qqq222['id_video']]);
		//
		$chto = $functions->htmlred($_GET['chto']);
		$title->SetTitle($qqq222['name']);
		$url2 = '<a href="/video'.$id.'">Видеозаписи</a>';
		$url = '<a href="/id'.$id.'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$title->SetHais($url.' » '.$url2.' » Видеозапись');
		$title->GetHeader([]); ?>
		<div>
			<div class="_ifjaf3ht78gh9ugh _iawjofafh38wg3g _fe84tg8righ" style="border-top: 0;padding-bottom: 0;">
				<iframe style="width: 100%;" width="560" height="315" src="https://www.youtube.com/embed/<?php echo $videogl['url'];?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
			<div class="_0q9tgur89ug04 _grid7">
				<div>
					<div class="_fioawif38h9gh" style="display: block;">
						<?php if(isset($user['id']) and isset($videogl['id']) and ($qqq222['closewall'] == 0 or $qqq['id'] == $user['id'])):
							echo $komm->aktivkomm(['id' => $qqq222['id'], 'chto' => $chto]); ?>
							<div id="moreNews33"></div>
						<?php else: ?>
							<div style="text-align: center;">Тут комментарии отключены</div>
						<?php endif;
						echo $komm->kommes(['id' => $qqq222['id'], 'chto' => $chto]); ?>
					</div>
				</div>
				<div class="_q3088g4w98gh">
					<h4>Информация</h4>
					<div><span class="_jf3f00fwwd2">Название:</span> <?php echo $qqq222['name'];?></div>
					<div style="margin-bottom: 10px;"><span class="_jf3f00fwwd2">Дата загрузки:</span> <?php echo $functions->times($qqq222['time']);?></div>
					<?php if(isset($user['id'])): ?>
						<div class="_iajif38h9hg9r">
							<h4>Действия</h4>
							<ul class="_menu09dwadk39">
								<?php if(isset($videogl['id']) and DB::$dbs->querySingle('SELECT COUNT(id) FROM video_us WHERE id_video = ? and idus = ? and chto = ?', [$videogl['id'],$user['id'],$chto]) == 0): ?>
									<li><div class="_dwdjaifj38g90r8"><span onclick="k09f48wgrgirj49('._dwdjaifj38g90r8','/ajs/video/dellvideo/<?php echo $videogl['id'];?>/<?php echo $chto;?>/');" class="">Добавить к себе</span></div></li>
								<?php else: ?>
									<li><span class="_q3j08fh4wh9tg _dwdjaifj38g90r8" onclick="k09f48wgrgirj49('._q3j08fh4wh9tg','/ajs/video/dellvideo/<?php echo $videogl['id'];?>/<?php echo $chto;?>/');">Удалить видео</span></li>
								<?php endif;
								if(isset($videogl['id'])): ?>
								<li><span onclick="return false;" href="/ajs/pr/repost/video/<?php echo $videogl['id'];?>/" class="_dawd021hhwggh">Поделиться</a></span>
								<?php endif;
								if(isset($videogl['id']) and isset($user['id']) and $qqq222['idus'] == $user['id']):?>
									<li class="_wdadh82hr9dwaawd" onclick="k09f48wgrgirj49('._wdadh82hr9dwaawd','/ajs/all/closekommvideo/<?php echo $qqq222['id'];?>/<?php echo $chto;?>/');"><?php echo $qqq222['closewall'] == 0 ? 'Закрыть комментарии' : 'Открыть комментарии';?></li>
								<?php endif; ?>
							</ul>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}