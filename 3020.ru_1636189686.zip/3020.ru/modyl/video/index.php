<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		if(empty($user['id'])): header('location: /'); exit; endif;
		$chto = $functions->htmlred($_GET['chto']);
		$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		$url = '<a href="/'.$qqq['url'].'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$title->SetTitle('Видеозаписи '.$usemi->logins(['id' => $qqq['id'], 'name' => 1]));
		$title->SetHais($url.' » Видеозаписи '.$usemi->logins(['id' => $qqq['id'], 'name' => 1]));
		$title->GetHeader([]); ?> 
		<div class="_fowhadfh397yfh9">
			<span class="_ifawouifh397yhf9e" style="margin-right: 5px;"><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM video_us WHERE idus = ? and chto = ?',[$qqq['id'],$chto]),['видеозапись','видеозаписи','видеозаписей']);?></span>
			<?php if(isset($user['id']) and $user['id'] == $qqq['id']): ?>
				| <span style="margin-left: 5px;" onclick="$('.target').toggle();">Добавить видеозапись</span>
				</form>
			<?php endif; ?>
		</div>
			<?php if(isset($user['id']) and $user['id'] == $qqq['id']): ?>
				<div class="target" style="display: none;">
					<div class="container container2">
						<form class="_formautsda" id="ajax_form" action="" method="post" onsubmit="return false;">
							<div class="_grid2">
								<div class="_name">Ссылка на youtube:</div>
								<div><input class="_ijaowidj4378t9" type="url" maxlength="100" name="url" value="" autofocus="true" placeholder="Ссылка c сервиса youtube"></div>
							</div>
							<div style="margin-top: 20px;text-align: center;">
								<div><input onclick="saveform ('/ajs/video/add/<?php echo $chto;?>/<?php echo $qqq['id'];?>/','#ajax_form');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Добавить"></div>
							</div>
						</form>
					</div>
				</div>
			<?php endif; ?>
			<div style="padding: 10px 0;">
				<div id="moreNews33"></div>
				<?php if(DB::$dbs->querySingle('SELECT COUNT(id) FROM video_us WHERE idus = ? and chto = ?',[$qqq['id'],$chto]) == 0): ?>
					<div>
						<div style="margin-top: 15px;margin-bottom: 10px;" class="_08f8ghrg83qgh">Пока нет видеозаписей</div>
					</div>
				<?php else: ?>
					<div>
						<?php $sql1 = DB::$dbs->querySql('SELECT id_video,imag,name,opis,id FROM video_us WHERE idus = ? and chto = ? ORDER BY time DESC LIMIT 10',[$qqq['id'],$chto])->fetchAll(PDO::FETCH_ASSOC);
						foreach ($sql1 as $sqlls => $files): 
							$qqqs = DB::$dbs->queryFetch('SELECT id FROM video WHERE id = ? LIMIT 1', [$files['id_video']]);?>
							<div class="row _08f8ghrg83qgh">
								<div class="cs5 _oiwofh487tg9g"><img src="<?php echo CDN;?>/video/<?php echo $files['imag'];?>"></div>
								<div class="col">
									<div><a href="<?php echo DOMAIN2;?>/video<?php echo $qqq['id'];?>_<?php echo $files['id'];?>"><h4><?php echo $files['name'];?></h4></a></div>
									<div class="_fw8hf843yhtgf9r"><?php echo (empty($files['opis']) and mb_strlen($files['opis'], 'UTF-8') == 0) ? 'Нет описания.' : $files['opis'];?></div>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
			<?php $title->GetFooter([]);
	break;
}