<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
		$title->SetTitle('Новое сообщение');
		$title->SetHais('Новое сообщение');
		$title->GetHeader([]);?>
		<?php $title->GetFooter([]);
	break;
}