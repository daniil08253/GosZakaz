<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		if(empty($user['id'])): header('location: /'); exit; endif;
		$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		$title->SetTitle($usemi->logins(['id' => $qqq['id'], 'name' => 3]));
		$url = '<a href="/'.$qqq['url'].'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$title->SetHais($url.' » Друзья');
		$title->GetHeader([]); ?>
		<div>
			<div class="_grid4 _wjidj3h9euhg9">
				<a class="_39te0gr8ijgw" href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>">Друзья</a>
				<a href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>?act=outcoming">Заявки</a>
				<a href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>?act=incoming">Подписчики</a>
			</div>
			<div class="_ifjaf3ht78gh9ugh">
				<?php 
				if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends WHERE cogo = ?',[$qqq['id']])):
					$sql1 = DB::$dbs->querySql('SELECT idus FROM friends WHERE cogo = ? ORDER BY time DESC LIMIT 10',[$qqq['id']])->fetchAll(PDO::FETCH_ASSOC);
					foreach ($sql1 as $sqlls => $files): 
						$qqq = DB::$dbs->queryFetch('SELECT sex,datareg FROM user WHERE id = ? LIMIT 1', [$files['idus']]);?>
						<div class="row _08f8ghrg83qgh">
							<div class="cs5"><?php echo $usemi->avas(['id' => $files['idus'], 'url' => 1]);?></div>
							<div class="col">
								<div><h4><?php echo $usemi->logins(['id' => $files['idus'], 'name' => 3, 'url' => 1]);?></h4></div>
								<div>Пол: <?php echo $qqq['sex'] == 1 ? 'Мужской' : 'Женский';?></div>
								<div>Дата регистрации: <?php echo $functions->times($qqq['datareg']);?></div>
							</div>
						</div>
					<?php endforeach; 
				else: ?>
					<div class="_08f8ghrg83qgh">Пока нет друзей</div>
				<?php endif; ?>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
	case 'incoming':
		$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		$title->SetTitle($usemi->logins(['id' => $qqq['id'], 'name' => 3]));
		$url = '<a href="/'.$qqq['url'].'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$title->SetHais($url.' » Подписчики');
		$title->GetHeader([]); ?>
		<div>
			<div class="_grid4 _wjidj3h9euhg9">
				<a href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>">Друзья</a>
				<a href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>?act=outcoming">Заявки</a>
				<a class="_39te0gr8ijgw" href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>?act=incoming">Подписчики</a>
			</div>
			<div class="_ifjaf3ht78gh9ugh">
				<?php 
				if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE cogo = ?',[$qqq['id']])):
					$sql1 = DB::$dbs->querySql('SELECT idus FROM friends_new WHERE cogo = ? ORDER BY time DESC LIMIT 10',[$qqq['id']])->fetchAll(PDO::FETCH_ASSOC);
					foreach ($sql1 as $sqlls => $files): 
						$qqq = DB::$dbs->queryFetch('SELECT sex,datareg FROM user WHERE id = ? LIMIT 1', [$files['idus']]);?>
						<div class="row _08f8ghrg83qgh">
							<div class="cs5"><?php echo $usemi->avas(['id' => $files['idus'], 'url' => 1]);?></div>
							<div class="col">
								<div><h4><?php echo $usemi->logins(['id' => $files['idus'], 'name' => 3, 'url' => 1]);?></h4></div>
								<div>Пол: <?php echo $qqq['sex'] == 1 ? 'Мужской' : 'Женский';?></div>
								<div>Дата регистрации: <?php echo $functions->times($qqq['datareg']);?></div>
							</div>
						</div>
					<?php endforeach; 
				else: ?>
					<div class="_08f8ghrg83qgh">Пока нет подписчиков</div>
				<?php endif; ?>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
	case 'outcoming':
		$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		$title->SetTitle($usemi->logins(['id' => $qqq['id'], 'name' => 3]));
		$url = '<a href="/'.$qqq['url'].'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$title->SetHais($url.' » Заявки');
		$title->GetHeader([]); ?>
		<div>
			<div class="_grid4 _wjidj3h9euhg9">
				<a href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>">Друзья</a>
				<a class="_39te0gr8ijgw" href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>?act=outcoming">Заявки</a>
				<a href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>?act=incoming">Подписчики</a>
			</div>
			<div class="_ifjaf3ht78gh9ugh">
				<?php 
				if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE idus = ?',[$qqq['id']])):
					$sql1 = DB::$dbs->querySql('SELECT cogo FROM friends_new WHERE idus = ? ORDER BY time DESC LIMIT 10',[$qqq['id']])->fetchAll(PDO::FETCH_ASSOC);
					foreach ($sql1 as $sqlls => $files): 
						$qqq = DB::$dbs->queryFetch('SELECT sex,datareg FROM user WHERE id = ? LIMIT 1', [$files['cogo']]);?>
						<div class="row _08f8ghrg83qgh">
							<div class="cs5"><?php echo $usemi->avas(['id' => $files['cogo'], 'url' => 1]);?></div>
							<div class="col">
								<div><h4><?php echo $usemi->logins(['id' => $files['cogo'], 'name' => 3, 'url' => 1]);?></h4></div>
								<div>Пол: <?php echo $qqq['sex'] == 1 ? 'Мужской' : 'Женский';?></div>
								<div>Дата регистрации: <?php echo $functions->times($qqq['datareg']);?></div>
							</div>
						</div>
					<?php endforeach; 
				else: ?>
					<div class="_08f8ghrg83qgh">Пока нет заявок</div>
				<?php endif; ?>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}