<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		if(empty($user['id'])): header('location: /'); exit; endif;
		$chto = $functions->htmlred($_GET['chto']);
		$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		$url = '<a href="/'.$qqq['url'].'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$title->SetTitle('Заметки '.$usemi->logins(['id' => $qqq['id'], 'name' => 1]));
		$title->SetHais($url.' » Заметки '.$usemi->logins(['id' => $qqq['id'], 'name' => 1, 'url' => 1]));
		$title->GetHeader([]); ?>
		<div class="_fowhadfh397yfh9">
			<span class="_ifawouifh397yhf9e" style="margin-right: 5px;"><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM notes WHERE idus = ? and chto = ?',[$qqq['id'],$chto]),['заметка','заметки','заметок']);?></span> <?php echo (isset($user['id']) and $user['id'] == $qqq['id']) ? ' | <a style="margin-left: 5px;" href="'.DOMAIN2.'/notes/add/'.$chto.'/'.$qqq['id'].'/">Создать заметку</a>' : NULL;?>
		</div>
		<div style="padding: 10px 0;">
			<?php if(DB::$dbs->querySingle('SELECT COUNT(id) FROM notes WHERE idus = ? and chto = ?',[$qqq['id'],$chto]) == 0) { ?>
					<div class="_08f8ghrg83qgh">Пока нет заметок</div>
			<?php } else {
				$sql1 = DB::$dbs->querySql('SELECT id,name,time,textobr FROM notes WHERE idus = ? and chto = ? ORDER BY time DESC LIMIT 10',[$qqq['id'],$chto])->fetchAll(PDO::FETCH_ASSOC);
				foreach ($sql1 as $sqlls => $files) { ?>
					<div class="_iadoiwhdq9f7g72d">
						<div class="row">
							<div class="cs8">
								<div class="_notda3rfh9eh0"></div>
							</div>
							<div class="col">
								<a href="<?php echo DOMAIN2;?>/notes<?php echo $qqq['id'];?>_<?php echo $files['id'];?>"><h2><?php echo $files['name'];?></h2></a>
								<div><?php echo $functions->times($files['time']);?></div>
							</div>
						</div>
						<div class="_textas">
							<?php echo $files['textobr'];?>
						</div>
					</div>
				<?php }
			} ?>
		</div>
		<?php $title->GetFooter([]);
	break;
}