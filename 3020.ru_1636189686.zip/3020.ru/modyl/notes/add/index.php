<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		if(empty($user['id'])): header('location: /'); exit; endif;
		$chto = $functions->htmlred($_GET['chto']);
		if($chto == 'usernotes') {
			$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id']) or $qqq['id'] != $user['id']): header('location: /'); exit; endif;
		} else {
			header('location: /'); exit;
		}
		$url = '<a href="/'.$qqq['url'].'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$title->SetTitle('Заметки '.$usemi->logins(['id' => $qqq['id'], 'name' => 1]));
		$title->SetHais($url.' » Заметки '.$usemi->logins(['id' => $qqq['id'], 'name' => 1]).' » Создать заметку');
		$title->GetHeader([]); ?> 
		<div>
			<div class="_ifjaf3ht78gh9ugh _irjq38r3yr8qhw0d2">
				<form class="_formautsda" id="ajax_form" action="" method="post" onsubmit="return false;">
					<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="name" value="" autofocus="true" placeholder="Название заметки"></div>
					<div style="margin-top: 10px;">
						<textarea onkeyup="this.style.height = '1px';this.style.height = (this.scrollHeight + 6) + 'px';" class="_ijaowidj4378t9 _d98u498w9r8u9g" type="text" name="text"></textarea>
					</div>
					<div style="margin-top: 10px;text-align: left;">
						<div><input onclick="saveform ('/ajs/notes/add/<?php echo $chto;?>/<?php echo $qqq['id'];?>/','#ajax_form');return false;" style="width: 70px;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Сохранить"></div>
					</div>
				</form>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}