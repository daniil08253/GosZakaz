<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		//
		$ids = $functions->htmlred($_GET['ids']);
		$notes = DB::$dbs->queryFetch('SELECT id,chto,idus,time,name,text,closewall FROM notes WHERE id = ? LIMIT 1', [$ids]);
		if(empty($notes['id'])): header('location: /'); exit; endif;
		if($notes['chto'] == 'usernotes') {
			$qqq = DB::$dbs->queryFetch('SELECT id FROM user WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id'])): header('location: /'); exit; endif;
			$url = $usemi->logins(['id' => $qqq['id'], 'name' => 3, 'url' => 1]).' » <a href="'.DOMAIN2.'/notes'.$qqq['id'].'">Заметки '.$usemi->logins(['id' => $qqq['id'], 'name' => 1]).'</a> » '.$notes['name'];
		}
		//
		$title->SetTitle('');
		$title->SetHais($url);
		$title->GetHeader([]); ?>
		<div class="_postes _fe84tg8righ">
			<div class="row">
				<div class="cs6 _e8gh9ghffg0">
					<?php echo $usemi->avas(['id' => $qqq['id'], 'mini' => 1, 'url' => 1]);?>
				</div>
				<div class="col">
					<div class="_0q3j8guyr9w8g _wjd83t98gh9rhg9">
						<div class="_jfjw84guyiu"><span><?php echo $usemi->logins(['id' => $qqq['id'], 'name' => 3, 'url' => 1]);?></span></div>
						<div><?php echo $functions->times($notes['time']);?></div>
					</div>
				</div>
			</div>
			<div class="_textas">
				<?php echo nl2br($notes['text']);?>
			</div>
		</div>
		<div class="_0q9tgur89ug04 _grid7">
			<div>
				<div class="_fioawif38h9gh" style="display: block;">
					<?php if(isset($user['id']) and isset($notes['id']) and ($notes['closewall'] == 0 or $qqq['id'] == $user['id'])):
						echo $komm->aktivkomm(['id' => $notes['id'], 'chto' => $notes['chto']]); ?>
						<div id="moreNews33"></div>
					<?php else: ?>
						<div style="text-align: center;">Тут комментарии отключены</div>
					<?php endif;
					echo $komm->kommes(['id' => $notes['id'], 'chto' => $notes['chto']]); ?>
				</div>
			</div>
			<div class="_q3088g4w98gh">
				<div class="_iajif38h9hg9r">
					<h4>Действие</h4>
					<?php if(isset($user['id'])) { ?>
						<ul class="_menu09dwadk39">
							<li>Жалоба на заметку</li>
							<?php echo (($notes['idus'] == $user['id']) ? '<li><span class="_q3j08fh4wh9tg _dwdjaifj38g90r8" onclick="k09f48wgrgirj49(\'._q3j08fh4wh9tg\',\'/ajs/notes/dell/'.$notes['chto'].'/'.$notes['id'].'/\');">Удалить заметку</span></li>' : NULL);?>
						</ul>
					<?php } else { ?>
						<div>Зарегистрируйтесь, что бы у вас было больше возможностей.</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}