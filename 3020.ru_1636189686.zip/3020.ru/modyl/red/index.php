<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
// 3020.ru - скрипты тут
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'osn':
		$title->SetTitle('Редактировать страницу');
		$title->SetHais('Редактировать страницу');
		$title->GetHeader([]);?>
		<div>
			<div class="_grid4 _wjidj3h9euhg9">
				<a class="_39te0gr8ijgw" href="<?php echo DOMAIN2;?>/red/osn/">Основное</a>
				<a href="<?php echo DOMAIN2;?>/red/kont/">Контакты</a>
				<a href="<?php echo DOMAIN2;?>/red/inter/">Интересы</a>
				<a href="<?php echo DOMAIN2;?>/red/avatar/">Аватар</a>
			</div>
			<div class="_ifjaf3ht78gh9ugh">
				<div class="container container2">
					<form class="_formautsda" id="ajax_form" action="" method="post" onsubmit="return false;">
						<div class="_grid2">
							<div class="_name">Имя</div>
							<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="name" value="<?php echo $user['name'];?>" autofocus="true" placeholder="Имя"></div>
						</div>
						<div class="_grid2">
							<div class="_name">Фамилия</div>
							<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="fame" value="<?php echo $user['fame'];?>" autofocus="true" placeholder="Фамилия"></div>
						</div>
						<div class="_grid2">
							<div class="_name">Никнейм:</div>
							<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="nickname" value="<?php echo $user['nickname'];?>" autofocus="true" placeholder="Никнейм"></div>
						</div>
						<div class="_grid2">
							<div class="_name">Статус:</div>
							<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="status" value="<?php echo $user['status'];?>" autofocus="true" placeholder="Статус"></div>
						</div>
						<div class="_grid2">
							<div class="_name">Семейное положение:</div>
							<select name="marialstatus" class="_ijaowidj4378t9">
								<option value="0" <?php echo $user['marialstatus'] == 0 ? 'selected=""' : NULL;?>>Не выбрано</option>
								<option value="1" <?php echo $user['marialstatus'] == 1 ? 'selected=""' : NULL;?>>Не женат</option>
								<option value="2" <?php echo $user['marialstatus'] == 2 ? 'selected=""' : NULL;?>>Встречаюсь</option>
								<option value="3" <?php echo $user['marialstatus'] == 3 ? 'selected=""' : NULL;?>>Помолвлен</option>
								<option value="4" <?php echo $user['marialstatus'] == 4 ? 'selected=""' : NULL;?>>Женат</option>
								<option value="5" <?php echo $user['marialstatus'] == 5 ? 'selected=""' : NULL;?>>В гражданском браке</option>
								<option value="6" <?php echo $user['marialstatus'] == 6 ? 'selected=""' : NULL;?>>Влюблен</option>
								<option value="7" <?php echo $user['marialstatus'] == 7 ? 'selected=""' : NULL;?>>Всё сложно</option>
								<option value="8" <?php echo $user['marialstatus'] == 8 ? 'selected=""' : NULL;?>>В активном поиске</option>
							</select>
						</div>
						<div class="_grid2">
							<div class="_name">Полит. взгляды:</div>
							<select name="politviews" class="_ijaowidj4378t9">
								<option value="0" <?php echo $user['politviews'] == 0 ? 'selected=""' : NULL;?>>Не выбраны</option>
								<option value="1" <?php echo $user['politviews'] == 1 ? 'selected=""' : NULL;?>>Индифферентные</option>
								<option value="2" <?php echo $user['politviews'] == 2 ? 'selected=""' : NULL;?>>Коммунистические</option>
								<option value="3" <?php echo $user['politviews'] == 3 ? 'selected=""' : NULL;?>>Социалистические</option>
								<option value="4" <?php echo $user['politviews'] == 4 ? 'selected=""' : NULL;?>>Умеренные</option>
								<option value="5" <?php echo $user['politviews'] == 5 ? 'selected=""' : NULL;?>>Либеральные</option>
								<option value="6" <?php echo $user['politviews'] == 6 ? 'selected=""' : NULL;?>>Консервативные</option>
								<option value="7" <?php echo $user['politviews'] == 7 ? 'selected=""' : NULL;?>>Монархические</option>
								<option value="8" <?php echo $user['politviews'] == 8 ? 'selected=""' : NULL;?>>Ультраконсервативные</option>
								<option value="9" <?php echo $user['politviews'] == 9 ? 'selected=""' : NULL;?>>Либертарианские</option>
							</select>
						</div>
						<div class="_grid2">
							<div class="_name">Пол:</div>
							<select name="sex" class="_ijaowidj4378t9">
								<option value="1" <?php echo $user['sex'] == 1 ? 'selected=""' : NULL;?>>мужской</option>
								<option value="2" <?php echo $user['sex'] == 2 ? 'selected=""' : NULL;?>>женский</option>
							</select>
						</div>
						<div class="_grid2">
							<div class="_name">День рождения</div>
							<div><input max="2021-10-15" class="_ijaowidj4378t9" type="date" maxlength="100" name="dayr" value="<?php echo $user['dayr'];?>" autofocus="true"></div>
						</div>
						<div style="margin-top: 20px;text-align: center;">
							<div><input onclick="saveform ('/ajs/red/osn/','#ajax_form');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Сохранить"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
	case 'kont':
		$title->SetTitle('Редактировать страницу');
		$title->SetHais('Редактировать страницу');
		$title->GetHeader([]);?>
		<div>
			<div class="_grid4 _wjidj3h9euhg9">
				<a href="<?php echo DOMAIN2;?>/red/osn/">Основное</a>
				<a class="_39te0gr8ijgw" href="<?php echo DOMAIN2;?>/red/kont/">Контакты</a>
				<a href="<?php echo DOMAIN2;?>/red/inter/">Интересы</a>
				<a href="<?php echo DOMAIN2;?>/red/avatar/">Аватар</a>
			</div>
			<div class="_ifjaf3ht78gh9ugh">
				<div class="container container2">
					<form class="_formautsda" id="ajax_form" action="" method="post" onsubmit="return false;">
						<div class="_grid2">
							<div class="_name">Электронная почта:</div>
							<div><input class="_ijaowidj4378t9" type="email" maxlength="100" name="email" value="<?php echo $user['email2'];?>" autofocus="true" placeholder="Электронная почта"></div>
						</div>
						<div class="_grid2">
							<div class="_name">Telegram:</div>
							<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="telegram" value="<?php echo $user['telegram'];?>" autofocus="true" placeholder="Telegram"></div>
						</div>
						<div class="_grid2">
							<div class="_name">Город:</div>
							<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="city" value="<?php echo $user['city'];?>" autofocus="true" placeholder="Город"></div>
						</div>
						<div class="_grid2">
							<div class="_name">Адрес:</div>
							<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="adress" value="<?php echo $user['adress'];?>" autofocus="true" placeholder="Адрес"></div>
						</div>
						<div style="margin-top: 20px;text-align: center;">
							<div><input onclick="saveform ('/ajs/red/kont/','#ajax_form');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Сохранить"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
	case 'inter':
		$title->SetTitle('Редактировать страницу');
		$title->SetHais('Редактировать страницу');
		$title->GetHeader([]);?>
		<div>
			<div class="_grid4 _wjidj3h9euhg9">
				<a href="<?php echo DOMAIN2;?>/red/osn/">Основное</a>
				<a href="<?php echo DOMAIN2;?>/red/kont/">Контакты</a>
				<a class="_39te0gr8ijgw" href="<?php echo DOMAIN2;?>/red/inter/">Интересы</a>
				<a href="<?php echo DOMAIN2;?>/red/avatar/">Аватар</a>
			</div>
			<div class="_ifjaf3ht78gh9ugh">
				<div class="container container2">
					<form class="_formautsda" id="ajax_form" action="" method="post" onsubmit="return false;">
						<div class="_grid2">
							<div class="_name">Интересы:</div>
							<div><textarea class="_ijaowidj4378t9 _d98u498w9r8u9g" type="text" name="interests"><?php echo $user['interests'];?></textarea></div>
						</div>
						<div class="_grid2">
							<div class="_name">Любимая музыка:</div>
							<div><textarea class="_ijaowidj4378t9 _d98u498w9r8u9g" type="text" name="lovemusic"><?php echo $user['lovemusic'];?></textarea></div>
						</div>
						<div class="_grid2">
							<div class="_name">Любимые фильмы:</div>
							<div><textarea class="_ijaowidj4378t9 _d98u498w9r8u9g" type="text" name="lovemovie"><?php echo $user['lovemovie'];?></textarea></div>
						</div>
						<div class="_grid2">
							<div class="_name">Любимые ТВ-шоу:</div>
							<div><textarea class="_ijaowidj4378t9 _d98u498w9r8u9g" type="text" name="lovetvshow"><?php echo $user['lovetvshow'];?></textarea></div>
						</div>
						<div class="_grid2">
							<div class="_name">Любимые книги:</div>
							<div><textarea class="_ijaowidj4378t9 _d98u498w9r8u9g" type="text" name="lovebook"><?php echo $user['lovebook'];?></textarea></div>
						</div>
						<div class="_grid2">
							<div class="_name">Любимые цитаты:</div>
							<div><textarea class="_ijaowidj4378t9 _d98u498w9r8u9g" type="text" name="lovecit"><?php echo $user['lovecit'];?></textarea></div>
						</div>
						<div class="_grid2">
							<div class="_name">О себе:</div>
							<div><textarea class="_ijaowidj4378t9 _d98u498w9r8u9g" type="text" name="osebe"><?php echo $user['osebe'];?></textarea></div>
						</div>
						<div style="margin-top: 20px;text-align: center;">
							<div><input onclick="saveform ('/ajs/red/inter/','#ajax_form');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Сохранить"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
	case 'avatar':
		$title->SetTitle('Редактировать страницу');
		$title->SetHais('Редактировать страницу');
		$title->GetHeader([]);?>
		<div>
			<div class="_grid4 _wjidj3h9euhg9">
				<a href="<?php echo DOMAIN2;?>/red/osn/">Основное</a>
				<a href="<?php echo DOMAIN2;?>/red/kont/">Контакты</a>
				<a href="<?php echo DOMAIN2;?>/red/inter/">Интересы</a>
				<a class="_39te0gr8ijgw" href="<?php echo DOMAIN2;?>/red/avatar/">Аватар</a>
			</div>
			<div class="_ifjaf3ht78gh9ugh">
				<div class="container container2">
					<form class="_formautsda" id="ajax_form" action="" method="post" onsubmit="return false;">
						<div class="_grid2">
							<div class="_name">Изображение:</div>
							<div><input id="postFilePic" type="file" name="file" accept="image/*"></div>
						</div>
						<div style="margin-top: 20px;text-align: center;">
							<input onclick="saveform ('/upload/avatar/user/','#ajax_form');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Сохранить">
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}