<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		if(empty($user['id'])): header('location: /'); exit; endif;
		$title->SetTitle('бан');
		$title->SetHais('бан');
		$title->GetHeader([]);
		?>
		Ты забанен, по этому ты фаршмак ебаный.
		<?php
		$title->GetFooter([]);
	break;
}