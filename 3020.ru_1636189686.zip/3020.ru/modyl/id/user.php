<?php 
if(empty($qqq['id'])): header('location: /'); exit; endif;
$onl = DB::$dbs->querySingle('SELECT COUNT(id) FROM user WHERE datalast > ? and id = ?',[time() - 3000,$qqq['id']]) ? '<span title="Данный пользователь онлайн" class="_online03qt90g">Онлайн</span>' : '<span class="_online03qt90g">был в сети '.$functions->times($qqq['datalast']).'</span>';
$mus = (isset($user['id']) and $qqq['id'] == $user['id']) ? '<span>(это Вы)</span>' : NULL;
$rank1 = [0 => 'Не выбрано', 1 => 'Не женат', 2 => 'Встречаюсь', 3 => 'Помолвлен', 4 => 'Женат', 5 => 'В гражданском', 6 => 'Влюблен', 7 => 'Всё сложно', 8 => 'В активном поиске'];
$rank2 = [0 => 'Не выбрано', 1 => 'Индифферентные', 2 => 'Коммунистические', 3 => 'Социалистические', 4 => 'Умеренные', 5 => 'Либеральные', 6 => 'Консервативные', 7 => 'Монархические', 8 => 'Ультраконсервативные', 9 => 'Либертарианские'];
$basld = $qqq['ver'] == 1 ? '<span title="Подтверждённая страница" class="_veriff1"></span>' : NULL;
$rate = $usemi->reitings($qqq['id']);
$title->SetTitle($qqq['name'].' '.$qqq['fame']);
$title->SetHais('<span class="_ioef893tfg8rh9g">'.$qqq['name'].' '.$qqq['fame'].'</span> '.$mus.' '.$basld.' '.$onl);
$title->GetHeader([]); 
///
if(isset($user['id'])):
	$frend = DB::$dbs->querySingle('SELECT COUNT(id) FROM friends WHERE (idus = ? AND cogo = ?) OR (idus = ? AND cogo = ?) LIMIT 1',[$user['id'],$qqq['id'],$qqq['id'],$user['id']]);
	$frend_new = DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE idus = ? AND cogo = ? LIMIT 1',[$user['id'],$qqq['id']]);
	$frend_new2 = DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE idus = ? AND cogo = ? LIMIT 1',[$qqq['id'],$user['id']]);
endif; ?>
<div class="row _awdwdawhufh3">
	<div class="cs3 _09ug8u85uy9r8u _qgtfwuigh58gh">
		<div class="_avassqf9ej">
			<?php echo $usemi->avas(['id' => $qqq['id'], 'url' => 2]);?>
		</div>
		<div class="_menugr">
			<?php if(isset($user['id'])): ?>
				<ul>
					<?php if($qqq['id'] == $user['id']): ?>
						<li><a class="_jqufhriuif34t4" href="<?php echo DOMAIN2;?>/red/osn/">Редактировать анкету</a></li>
					<?php else: ?>
						<li><a class="_jqufhriuif34t4" href="<?php echo DOMAIN2;?>/im<?php echo $qqq['id'];?>">Написать сообщение</a></li>
						<?php if ($frend_new == 0 && $frend == 0): 
							if($frend_new2 == 0): ?>
								<li onclick="k09f48wgrgirj49('#frienadds','/ajs/update/friends/<?php echo $qqq['id'];?>/');"><span id="frienadds" class="_jqufhriuif34t4">Добавить в друзья</span></li>
							<?php else: ?>
								<li onclick="k09f48wgrgirj49('#frienadds','/ajs/update/friends/<?php echo $qqq['id'];?>/');"><span id="frienadds" class="_jqufhriuif34t4">Подтвердить заявку</span></li>
							<?php endif; ?>
						<?php elseif (isset($user['id']) and $frend_new == 1): ?>
							<li onclick="k09f48wgrgirj49('#frienadds','/ajs/update/friends/<?php echo $qqq['id'];?>/');"><span id="frienadds" class="_jqufhriuif34t4">Отменить заявку</span></li>
						<?php elseif (isset($user['id']) and $frend == 2): ?>
							<li onclick="k09f48wgrgirj49('#frienadds','/ajs/update/friends/<?php echo $qqq['id'];?>/');"><span id="frienadds" class="_jqufhriuif34t4">Удалить из друзей</span></li>
						<?php endif;
					endif; ?>
					<?php if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE cogo = ?',[$qqq['id']])): ?>
						<li><a class="_jqufhriuif34t4" href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>?act=incoming">Подписчики <?php echo $qqq['name'];?> <span><?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE cogo = ?',[$qqq['id']]);?><span class="material-icons">people</span></span></a></li>
					<?php endif; ?>
				</ul>
			<?php else: ?>
				<ul>
					<?php if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE cogo = ?',[$qqq['id']])): ?>
						<li><a class="_jqufhriuif34t4" href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>?act=incoming">Подписчики <?php echo $qqq['name'];?> <span><?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM friends_new WHERE cogo = ?',[$qqq['id']]);?><span class="material-icons">people</span></span></a></li>
					<?php endif; ?>
				</ul>
			<?php endif; ?>
			<div class="_reitda <?php echo (($rate['rate'] >= 100) ? '_fwah9fh73qh' : ''); ?>">
				<span><?php echo $rate['rate'];?></span>
				<div class="_9f90ggfw4tge" style="width: <?php echo $rate['skok'];?>%;"></div>
			</div>
		</div>
		<?php if(isset($user['id'])): ?>
			<div class="_tatings">
				<?php if(isset($user['id']) and $user['id'] == $qqq['id']): 
					if(empty($user['interests']) or empty($user['status']) or empty($user['telegram']) or empty($user['avatar'])): ?>
						<div class="_iaj08dh398ghr">
							<?php echo empty($qqq['interests']) ? '<div><span class="material-icons"> contacts </span> Интересы (+20%)</div>' : NULL;?>
							<?php echo empty($qqq['status']) ? '<div><span class="material-icons"> chat_bubble </span> Статус (+10%)</div>' : NULL;?>
							<?php echo empty($qqq['telegram']) ? '<div><span class="material-icons"> image </span> Telegram (+10%)</div>' : NULL;?>
							<?php echo empty($qqq['avatar']) ? '<div><span class="material-icons"> photo_camera </span> Аватар (+30%)</div>' : NULL;?>
						</div>
					<?php endif;
				endif; ?>
			</div>
		<?php endif;
		//echo $komm->kammid($idkommes);
		if(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends WHERE cogo = ?',[$qqq['id']])): ?>
			<div>
			 <div style="margin-top: 10px;" class="_fwpfi80ghr0 _fe_open" onclick="hidePanel(this, <?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM friends WHERE cogo = ?',[$qqq['id']]);?>);">Друзья</div>
				<div style="display:block;">
					<div class="_08f3yh9hw9uhgw7"><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM friends WHERE cogo = ?',[$qqq['id']]),['друг','друга','друзей']);?><a href="<?php echo DOMAIN2;?>/friends<?php echo $qqq['id'];?>">Все</a></div>
					<div class="_grid5 _daw44uidhuawh37hfr">
						<?php $sql1 = DB::$dbs->querySql('SELECT idus FROM friends WHERE cogo = ? ORDER BY time DESC LIMIT 6',[$qqq['id']])->fetchAll(PDO::FETCH_ASSOC);
						foreach ($sql1 as $sqlls1 => $files1): ?>
							<div>
								<div><?php echo $usemi->avas(['id' => $files1['idus'], 'mini' => 1, 'url' => 1]);?></div>
								<div class="_names"><?php echo $usemi->logins(['id' => $files1['idus'], 'name' => 1, 'url' => 1]);?></div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		<?php endif;
		if(DB::$dbs->querySingle('SELECT COUNT(id) FROM album WHERE idus = ? and intr = 0 and chto = ?',[$qqq['id'],'user'])): ?>
			<div>
				<div style="margin-top: 10px;" class="_fwpfi80ghr0 _fe_open" onclick="hidePanel(this, <?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM album WHERE idus = ? and chto = ?',[$qqq['id'],'user']);?>);">Фотоальбомы</div>
				<div style="display:block;">
					<div class="_08f3yh9hw9uhgw7"><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM album WHERE idus = ? and chto = ?',[$qqq['id'],'user']),['фотоальбом','фотоальбома','фотоальбомов']);?><a href="<?php echo DOMAIN2;?>/albums<?php echo $qqq['id'];?>">Все</a></div>
					<?php $sql = DB::$dbs->querySql('SELECT name,photosid,id,time FROM album WHERE idus = ? and chto = ? ORDER BY time DESC LIMIT 2',[$qqq['id'],'user'])->fetchAll(PDO::FETCH_ASSOC);
					foreach ($sql as $sqlls => $files): ?>
						<a href="<?php echo DOMAIN2;?>/albums<?php echo $qqq['id'];?>_<?php echo $files['id'];?>" class="row _dajwdhauh379f389wda">
							<div class="cs4 _iafiutfh398tg"><img src="<?php echo CDN;?>/photo/<?php echo $files['photosid'];?>"></div>
							<div class="col _frw8ty2g7rrgeg">
								<div class="_j8h39t8gj9dwa3"><?php echo $files['name'];?></div>
								<div class="_iawfij389tg9ri"><?php echo $functions->times($files['time']);?></div>
							</div>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif;
		// тута приватность
		$videoeye = 0;
		$onlvideo = DB::$dbs->querySingle('SELECT COUNT(id) FROM video_us WHERE idus = ? and chto = ?',[$qqq['id'],'uservideo']);
		if($qqq['eyevideo'] == 1 and $onlvideo > 0) {
			$videoeye = 1;
		} elseif($qqq['eyevideo'] == 2 and $onlvideo > 0 and isset($user['id'])) {
			$videoeye = 1;
		} elseif($qqq['eyevideo'] == 3 and $onlvideo > 0 and isset($user['id']) and ($user['id'] == $qqq['id'] or $frend == 2)) {
			$videoeye = 1;
		} elseif($qqq['eyevideo'] == 4 and $onlvideo > 0 and isset($user['id']) and $user['id'] == $qqq['id']) {
			$videoeye = 1;
		} else {
			$videoeye = 0;
		}
		//
		if($videoeye > 0): ?>
			<div>
				<div style="margin-top: 10px;" class="_fwpfi80ghr0 _fe_open" onclick="hidePanel(this, <?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM video_us WHERE idus = ? and chto = ?',[$qqq['id'],'uservideo']);?>);">Видеозаписи</div>
				<div style="display:block;">
					<div class="_08f3yh9hw9uhgw7"><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM video_us WHERE idus = ? and chto = ?',[$qqq['id'],'uservideo']),['видеозапиь','видеозаписи','видеозаписей']);?><a href="<?php echo DOMAIN2;?>/video<?php echo $qqq['id'];?>">Все</a></div>
					<div>
						<?php $sql = DB::$dbs->querySql('SELECT id,imag,name FROM video_us WHERE idus = ? and chto = ? ORDER BY time DESC LIMIT 2',[$qqq['id'],'uservideo'])->fetchAll(PDO::FETCH_ASSOC);
						foreach ($sql as $sqlls => $files): ?>
							<a href="<?php echo DOMAIN2;?>/video<?php echo $qqq['id'];?>_<?php echo $files['id'];?>" class="_dajwdhauh379f389wda _dawd3tggtrgrg">
								<img src="<?php echo CDN;?>/video/<?php echo $files['imag'];?>">
								<div class="_898t4t89rgehr9"><?php echo $files['name'];?></div>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		<?php endif;
		// тута приватность
		$noteseye = 0;
		$onlnotes = DB::$dbs->querySingle('SELECT COUNT(id) FROM notes WHERE idus = ? and chto = ?',[$qqq['id'],'usernotes']);
		if($qqq['eyenotes'] == 1 and $onlnotes > 0) {
			$noteseye = 1;
		} elseif($qqq['eyenotes'] == 2 and $onlnotes > 0 and isset($user['id'])) {
			$noteseye = 1;
		} elseif($qqq['eyenotes'] == 3 and $onlnotes > 0 and isset($user['id']) and ($user['id'] == $qqq['id'] or $frend == 2)) {
			$noteseye = 1;
		} elseif($qqq['eyenotes'] == 4 and $onlnotes > 0 and isset($user['id']) and $user['id'] == $qqq['id']) {
			$noteseye = 1;
		} else {
			$noteseye = 0;
		}
		//
		if($noteseye == 1) { ?>
			<div>
				<div style="margin-top: 10px;" class="_fwpfi80ghr0 _fe_open" onclick="hidePanel(this, <?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM notes WHERE idus = ? and chto = ?',[$qqq['id'],'usernotes']);?>);">Заметки</div>
				<div style="display:block;">
					<div class="_08f3yh9hw9uhgw7"><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM notes WHERE idus = ? and chto = ?',[$qqq['id'],'usernotes']),['заметка','заметки','заметок']);?><a href="<?php echo DOMAIN2;?>/notes<?php echo $qqq['id'];?>">Все</a></div>
					<?php $sql = DB::$dbs->querySql('SELECT id,time,name FROM notes WHERE idus = ? and chto = ? ORDER BY time DESC LIMIT 2',[$qqq['id'],'usernotes'])->fetchAll(PDO::FETCH_ASSOC);
					foreach ($sql as $sqlls => $files): ?>
						<div class="row _dwaid83hrf9e09f">
							<div class="cs9">
								<div class="_notda3rfh9eh0"></div>
							</div>
							<div class="col">
								<div><a href="<?php echo DOMAIN2;?>/notes<?php echo $qqq['id'];?>_<?php echo $files['id'];?>"><?php echo $files['name'];?></a></div>
								<div><span style="color: #777;"><?php echo $functions->times($files['time']);?></span> | <a href="<?php echo DOMAIN2;?>/notes<?php echo $qqq['id'];?>_<?php echo $files['id'];?>"><?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM komm WHERE idus = ? and chto = ?',[$files['id'],'usernotes']);?> комм.</a></div>
							</div>
						</div>
					<?php endforeach; 
					/*
					<div class="cs9">
								<span class="material-icons"> article </span>
							</div>
							<div class="col">
								<div><a href="<?php echo DOMAIN2;?>/notes<?php echo $qqq['id'];?>_<?php echo $files['id'];?>" class="row _dwaid83hrf9e09f"><?php echo $files['name'];?></a></div>
								<div style="font-size: 10px;"><span style="color: #777;"><?php echo $functions->times($files['time']);?></span> | 0 комментариев</div>
							</div>
					*/?>
				</div>
			</div>
		<?php } ?>
	</div>
	<div class="col _rffwgghirt4urhgiu">
		<div class="_oiawufhuw">
			<h1><?php echo $qqq['name'];?> <?php echo isset($qqq['nickname']) ? '('.$qqq['nickname'].')' : NULL;?> <?php echo $qqq['fame'];?></h1>
			<?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM user WHERE timeaudioupd > ? and id = ?',[time() - 300,$qqq['id']]) ? '<div class="_statusafre _fejk4wtg8rh9g"><span class="material-icons">volume_up</span>Слушает музыку</div>' : ((isset($user['id']) and $qqq['id'] == $user['id'] and empty($qqq['status'])) ? '<div class="_statusafre">Изменить статус</div>' : "<div class='_statusafre'>{$qqq['status']}</div>"); ?>
		</div>
		<div class="_9e9fggu8949tg">
			<div class="_grid3">
				<div class="_name3rf09wef">Пол:</div><div class="_fioawdhuh"><?php echo $qqq['sex'] == 1 ? 'Мужской' : 'Женский';?></div>
			</div>
			<div class="_grid3"><div class="_name3rf09wef">Семейное положение:</div><div class="_fioawdhuh"><?php echo $rank1[$qqq['marialstatus']];?></div></div>
			<?php echo isset($qqq['city']) ? '<div class="_grid3"><div class="_name3rf09wef">Родной город:</div><div class="_fioawdhuh">'.$qqq['city'].'</div></div>' : NULL;?>
			<div class="_grid3"><div class="_name3rf09wef">Дата регистрации:</div><div class="_fioawdhuh"><?php echo $functions->times($qqq['datareg']);?></div></div>
			<div class="_grid3"><div class="_name3rf09wef">Полит. взгляды:</div><div class="_fioawdhuh"><?php echo $rank2[$qqq['politviews']];?></div></div>
			<div class="_grid3"><div class="_name3rf09wef">День рождения:</div><div class="_fioawdhuh"><?php echo $qqq['dayr'];?>, <?php echo $usemi->vozrast($qqq['dayr']);?> лет</div></div>
		</div>
		<?php if(isset($qqq['email2']) or isset($qqq['telegram']) or isset($qqq['city']) or isset($qqq['interests']) or isset($qqq['lovemusic']) or isset($qqq['lovemovie']) or isset($qqq['lovetvshow']) or isset($qqq['lovebook']) or isset($qqq['lovecit']) or isset($qqq['osebe'])): ?>
			<div class="_fwpfi80ghr0 _fe_open" onclick="hidePanel(this);">Информация</div>
			<div style="display: block;">
				<div class="_fwdyh7rfhyt9g">
					<?php if(isset($qqq['email2']) or isset($qqq['telegram']) or isset($qqq['city']) or isset($qqq['adress'])): ?>
						<h2>Контактная информация</h2>
						<div class="_9e9fggu8949tg">
							<?php echo isset($qqq['email2']) ? '<div class="_grid3"><div class="_name3rf09wef">Электронная почта:</div><a target="_blank" class="_fioawdhuh" href="mailto:'.$qqq['email2'].'" rel="ugc">'.$qqq['email2'].'</a></div>' : NULL;?>
							<?php echo isset($qqq['telegram']) ? '<div class="_grid3"><div class="_name3rf09wef">Telegram:</div><a target="_blank" class="_fioawdhuh" href="https://t.me/'.$qqq['telegram'].'" rel="ugc">@'.$qqq['telegram'].'</a></div>' : NULL;?>
							<?php echo isset($qqq['city']) ? '<div class="_grid3"><div class="_name3rf09wef">Город:</div><div class="_fioawdhuh">'.$qqq['city'].'</div></div>' : NULL;?>
							<?php echo isset($qqq['adress']) ? '<div class="_grid3"><div class="_name3rf09wef">Адрес:</div><div class="_fioawdhuh">'.$qqq['adress'].'</div></div>' : NULL;?>
						</div>
					<?php endif;
					if(isset($qqq['interests']) or isset($qqq['lovemusic']) or isset($qqq['lovemovie']) or isset($qqq['lovetvshow']) or isset($qqq['lovebook']) or isset($qqq['lovecit']) or isset($qqq['osebe'])): ?>
						<h2 style="margin-top: 10px;">Личная информация</h2>
						<div class="_9e9fggu8949tg">
							<?php echo isset($qqq['interests']) ? '<div class="_grid3"><div class="_name3rf09wef">Интересы:</div><div class="_fioawdhuh">'.$qqq['interests'].'</div></div>' : NULL;?>
							<?php echo isset($qqq['lovemusic']) ? '<div class="_grid3"><div class="_name3rf09wef">Любимая музыка:</div><div class="_fioawdhuh">'.$qqq['lovemusic'].'</div></div>' : NULL;?>
							<?php echo isset($qqq['lovemovie']) ? '<div class="_grid3"><div class="_name3rf09wef">Любимые фильмы:</div><div class="_fioawdhuh">'.$qqq['lovemovie'].'</div></div>' : NULL;?>
							<?php echo isset($qqq['lovetvshow']) ? '<div class="_grid3"><div class="_name3rf09wef">Любимые ТВ-шоу:</div><div class="_fioawdhuh">'.$qqq['lovetvshow'].'</div></div>' : NULL;?>
							<?php echo isset($qqq['lovebook']) ? '<div class="_grid3"><div class="_name3rf09wef">Любимые книги:</div><div class="_fioawdhuh">'.$qqq['lovebook'].'</div></div>' : NULL;?>
							<?php echo isset($qqq['lovecit']) ? '<div class="_grid3"><div class="_name3rf09wef">Любимые цитаты:</div><div class="_fioawdhuh">'.$qqq['lovecit'].'</div></div>' : NULL;?>
							<?php echo isset($qqq['osebe']) ? '<div class="_grid3"><div class="_name3rf09wef">О себе:</div><div class="_fioawdhuh">'.$qqq['osebe'].'</div></div>' : NULL;?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		<?php endif; ?>
		<div class="_fwpfi80ghr0 _fe_open" onclick="hidePanel(this, <?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM komm WHERE ids = ? and chto = ?',[$qqq['id'],'user']);?>);">Стена <?php echo $qqq['closewall'] == 1 ? '(закрыта)' : NULL;?></div>
		<div style="display: block;">
			<?php if(isset($user['id']) and ($qqq['closewall'] == 0 or $qqq['id'] == $user['id'])):
				echo $komm->aktivkomm(['id' => $qqq['id'], 'chto' => 'user']);
			endif;?>
			<div id="moreNews33"></div>
			<?php echo $komm->kommes(['id' => $qqq['id'], 'chto' => 'user']); ?>
		</div>
	</div>
</div>
<?php $title->GetFooter([]);