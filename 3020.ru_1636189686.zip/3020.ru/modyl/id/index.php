<?php require_once($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
$chto = $functions->htmlred($_GET['chto']);
switch ($act) {
	default:
		if(DB::$dbs->querySingle('SELECT COUNT(id) FROM url WHERE url = ?',[$chto]) > 0):
			$urlss = DB::$dbs->queryFetch('SELECT chto,url,ads FROM url WHERE url = ? LIMIT 1', [$chto]);
			if($urlss['chto'] == 'user'):
				$qqq = DB::$dbs->queryFetch('SELECT ver,name,fame,id,status,sex,dayr,city,marialstatus,politviews,email2,city,adress,telegram,interests,lovemusic,lovemovie,lovetvshow,lovebook,lovecit,osebe,datareg,nickname,avatar,closewall,audioupd,timeaudioupd,eyevideo,eyenotes,datalast FROM user WHERE url = ? and id = ? LIMIT 1', [$chto,$urlss['ads']]);
				require($_SERVER['DOCUMENT_ROOT'].'/modyl/id/user.php');
			else:
				echo 1;
			endif;
		else:
			header('location: /');
		endif;
	break;
}