<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		//if(empty($user['id'])): header('location: /'); exit; endif;
		$chto = $functions->htmlred($_GET['chto']);
		// проверка пользователя
		$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		// проверка фотографии
		$idal = $functions->ints($_GET['idal']);
		$qqq222 = DB::$dbs->queryFetch('SELECT id,id_album,photo,opis,time,closewall,idus FROM photo WHERE id = ? and idus = ? and chto = ? LIMIT 1', [$idal,$qqq['id'],$chto]);
		if(empty($qqq222['id'])): header('location: /'); exit; endif;
		// узнаем альбом
		$album = DB::$dbs->queryFetch('SELECT id,name FROM album WHERE id = ? and chto = ? and idus = ? LIMIT 1', [$qqq222['id_album'],$chto,$qqq['id']]);
		$alburl = '<a href="'.DOMAIN2.'/albums'.$qqq['id'].'_'.$album['id'].'">'.$album['name'].'</a>';
		//
		$chto = $functions->htmlred($_GET['chto']);
		$title->SetTitle($usemi->logins(['id' => $qqq['id'], 'name' => 3]));
		$url = '<a href="/'.$qqq['url'].'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$title->SetHais($url.' » <a href="'.DOMAIN2.'/albums'.$qqq['id'].'">Альбомы</a> » '.$alburl.' » Фотография');
		$title->GetHeader([]); ?>
		<div>
			<div class="_ifjaf3ht78gh9ugh _iawjofafh38wg3g" style="border-top: 0;">
				<div class="_fe84tg8righ">
					<img src="<?php echo CDN;?>/photo/<?php echo $qqq222['photo'];?>">
				</div>
				<div class="_0q9tgur89ug04 _grid7">
					<div>
						<div class="_fioawif38h9gh" style="display: block;">
							<?php if(isset($user['id']) and ($qqq222['closewall'] == 0 or $qqq['id'] == $user['id'])):
								echo $komm->aktivkomm(['id' => $qqq222['id'], 'chto' => 'photo']); ?>
								<div id="moreNews33"></div>
							<?php else: ?>
								<div style="text-align: center;">Тут комментарии отключены</div>
							<?php endif;
							echo $komm->kommes(['id' => $qqq222['id'], 'chto' => 'photo']); ?>
						</div>
					</div>
					<div class="_q3088g4w98gh">
						<h4>Информация</h4>
						<div><span class="_jf3f00fwwd2">Описание:</span> <?php echo $qqq222['opis'];?></div>
						<div style="margin-bottom: 10px;"><span class="_jf3f00fwwd2">Дата загрузки:</span> <?php echo $functions->times($qqq222['time']);?></div>
							<?php if(isset($user['id'])): ?>
								<div class="_iajif38h9hg9r">
									<h4>Действия</h4>
									<ul class="_menu09dwadk39">
										<li><span onclick="return false;" href="/ajs/pr/repost/photo/<?php echo $qqq222['id'];?>/" class="_dawd021hhwggh">Поделиться</a></span>
										<li><a target="_blank" href="<?php echo CDN;?>/photo/<?php echo $qqq222['photo'];?>">Открыть оригинал</a></span>
										<?php if(isset($user['id']) and $qqq222['idus'] == $user['id']): ?>
											<li class="_q3j08fh4wh9tg" onclick="k09f48wgrgirj49('._q3j08fh4wh9tg','/ajs/all/dellphoto/<?php echo $qqq222['id'];?>/<?php echo $chto;?>/');">Удалить фото</li>
											<li class="_wdadh82hr9dwaawd" onclick="k09f48wgrgirj49('._wdadh82hr9dwaawd','/ajs/all/closekommphoto/<?php echo $qqq222['id'];?>/<?php echo $chto;?>/');"><?php echo $qqq222['closewall'] == 0 ? 'Закрыть комментарии' : 'Открыть комментарии';?></li>
										<?php endif; ?>
									</ul>
								</div>
							<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}


