<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		if(empty($user['id'])): header('location: /'); exit; endif;
		$chto = $functions->htmlred($_GET['chto']);
		if($chto == 'user'):
			$qqq = DB::$dbs->queryFetch('SELECT id FROM user WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id'])): exit('Ошибка, такого пользователя нет.'); endif;
			if($qqq['id'] != $user['id']): exit('Тут вам нельзя создавать альбомы.'); endif;
		else:
			exit('Тут вам нельзя создавать альбомы.');
		endif;
		$title->SetTitle('Создание альбома');
		$title->SetHais('Создание альбома');
		$title->GetHeader([]); ?>
		<div>
			<div class="_ifjaf3ht78gh9ugh" style="border-top: 0;">
				<div class="container container2">
					<form class="_formautsda" id="ajax_form" action="" method="post" onsubmit="return false;">
						<div class="_grid2">
							<div class="_name">Назваиние альбома:</div>
							<div><input class="_ijaowidj4378t9" type="email" maxlength="100" name="name" value="" autofocus="true" placeholder="Назваиние альбома"></div>
						</div>
						<div class="_grid2">
							<div class="_name">Описание альбома:</div>
							<div><textarea placeholder="Описание вашего альбома" class="_ijaowidj4378t9 _d98u498w9r8u9g" type="text" name="opis"></textarea></div>
						</div>
						<div style="margin-top: 20px;text-align: center;">
							<div><input onclick="saveform ('/ajs/addalbums/<?php echo $chto;?>/<?php echo $id;?>/','#ajax_form');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Создать"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}
?>