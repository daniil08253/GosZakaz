<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		if(empty($user['id'])): header('location: /'); exit; endif;
		$chto = $functions->htmlred($_GET['chto']);
		//
		$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		//
		$idal = $functions->ints($_GET['idal']);
		$qqq222 = DB::$dbs->queryFetch('SELECT id,name,intr,chto,idus FROM album WHERE id = ? and chto = ? and idus = ? LIMIT 1', [$idal,$chto,$qqq['id']]);
		if(empty($qqq222['id'])): header('location: /'); exit; endif;
		//
		$title->SetTitle($usemi->logins(['id' => $qqq['id'], 'name' => 3]));
		$url = '<a href="/'.$qqq['url'].'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$title->SetHais($url.' » <a href="'.DOMAIN2.'/albums'.$qqq['id'].'">Альбомы</a> » '.$qqq222['name']);
		$title->GetHeader([]); ?>
		<div class="_fjw0fh9uf97q9f8">
			<div class="_fowhadfh397yfh9">
				<span class="_ifawouifh397yhf9e" style="margin-right: 5px;"><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM photo WHERE id_album = ? and chto = ?',[$idal,$chto]),['фотаграфия','фотографии','фотографий']);?></span>
				<?php if($qqq222['intr'] == 3 and $qqq222['chto'] == 'user' and $qqq222['idus'] == $user['id']): ?>
					 | <form action="/upload/albums/<?php echo $chto;?>/<?php echo $qqq222['id'];?>/" style="display: inline;margin-left: 5px;margin-right: 5px;" method="post" enctype="multipart/form-data">
						<input type="file" name="file" id="file" class="_e4tgrethn" onchange="this.form.submit ()">
						<label for="file">Загрузить фотографию</label>
					</form> | <span onclick="k09f48wgrgirj49('._fjw0fh9uf97q9f8','/ajs/dellalbums/<?php echo $chto;?>/<?php echo $qqq222['id'];?>/');" style="margin-left: 5px;">Удалить альбом</span>
				<?php endif; ?>
			</div>
			<div>
				<?php if(DB::$dbs->querySingle('SELECT COUNT(id) FROM photo WHERE id_album = ? and chto = ?',[$idal,$chto])): ?>
					<div class="_ifjaf3ht78gh9ugh _grid6 _iawjofafh38wg3g" style="border-top: 0;">
						<?php $sql1 = DB::$dbs->querySql('SELECT photo,id FROM photo WHERE id_album = ? and chto = ? ORDER BY time DESC LIMIT 10',[$idal,$chto])->fetchAll(PDO::FETCH_ASSOC);
						foreach ($sql1 as $sqlls => $files): ?>
							<a href="<?php echo DOMAIN2;?>/photo<?php echo $qqq['id'];?>_<?php echo $files['id'];?>"><img src="<?php echo CDN;?>/photo/<?php echo $files['photo'];?>"></a>
						<?php endforeach; ?>
					</div>
				<?php else: ?>
					<div style="margin-top: 15px;margin-bottom: 10px;" class="_08f8ghrg83qgh">Пока нет фотографий</div>
				<?php endif; ?>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}