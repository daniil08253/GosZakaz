<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
// 3020.ru - скрипты тут
switch ($act) {
	default:
		if(empty($user['id'])): header('location: /'); exit; endif;
		$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		$chto = $functions->htmlred($_GET['chto']);
		$title->SetTitle($usemi->logins(['id' => $qqq['id'], 'name' => 3]));
		$url = '<a href="/'.$qqq['url'].'">'.$usemi->logins(['id' => $qqq['id'], 'name' => 3]).'</a>';
		$add = (isset($user['id']) and $qqq['id'] == $user['id']) ? '<a href="'.DOMAIN2.'/albums'.$qqq['id'].'/'.$chto.'/add/" class="_online03qt90g">Создать альбом</a>' : NULL;
		$title->SetHais($url.' » Альбомы '.$add);
		$title->GetHeader([]); ?>
		<div>
			<div class="_fowhadfh397yfh9"><span class="_ifawouifh397yhf9e" style="margin-right: 5px;"><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM album WHERE idus = ? and chto = ?',[$qqq['id'],$chto]),['альбом','альбома','альбомов']);?></span></div>
			<div class="_ifjaf3ht78gh9ugh" style="border-top: 0;">
				<?php if(DB::$dbs->querySingle('SELECT COUNT(id) FROM album WHERE idus = ? and chto = ?',[$qqq['id'],$chto])): ?>
					<div class="">
						<?php $sql1 = DB::$dbs->querySql('SELECT name,time,updatealb,photosid,id FROM album WHERE idus = ? and chto = ? ORDER BY time DESC LIMIT 10',[$qqq['id'],$chto])->fetchAll(PDO::FETCH_ASSOC);
						foreach ($sql1 as $sqlls => $files): 
							//$qqq = DB::$dbs->queryFetch('SELECT sex,datareg FROM user WHERE id = ? LIMIT 1', [$files['idus']]);?>
							<a href="<?php echo DOMAIN2;?>/albums<?php echo $qqq['id'];?>_<?php echo $files['id'];?>" class="row _08f8ghrg83qgh">
								<div class="cs5"><img src="<?php echo CDN;?>/photo/<?php echo $files['photosid'];?>"></div>
								<div class="col">
									<div><h4><?php echo $files['name'];?></h4></div>
									<div class="_fj08tgyhg0rhg83">
										<div><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM photo WHERE id_album = ?',[$files['id']]),['фотография','фотографии','фотографий']);?></div>
										<div>Обновлен <?php echo $functions->times($files['updatealb']);?></div>
									</div>
								</div>
							</a>
						<?php endforeach; ?>
					</div>
				<?php else: ?>
					<div class="_08f8ghrg83qgh">Пока нет альбом</div>
				<?php endif; ?>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}