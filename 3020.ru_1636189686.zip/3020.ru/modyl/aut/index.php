<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		if(isset($user['id'])): header('location: /'); exit; endif;
		$title->SetTitle('Авторизация');
		$title->SetHais('Авторизация');
		$title->GetHeader([]);
		$reg = 1;
		if($reg == 1): ?>
			<div class="container container2">
				<form class="_formautsda" id="ajax_form32" action="" method="post" onsubmit="return false;">
					<div class="_grid2">
						<div class="_name">Электронная почта:</div>
						<div><input class="_ijaowidj4378t9" type="email" maxlength="100" name="email" value="" autofocus="true" placeholder="Электронная почта"></div>
					</div>
					<div class="_grid2">
						<div class="_name">Пароль:</div>
						<div><input class="_ijaowidj4378t9" type="password" maxlength="100" name="password" value="" autofocus="true" placeholder="Пароль"></div>
					</div>
					<div class="_grid1" style="margin-top: 20px;text-align: center;">
						<div><input onclick="saveform ('/ajs/aut/','#ajax_form32');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Авторизация"></div>
						<div><a class="_30tuq8euf9ufgw _3r09g0frw0" href="<?php echo DOMAIN2;?>/reg/">Регистрация</a></div>
					</div>
				</div>
			</div>
		<?php else: ?>
			<div class="container container2">
				Регистрация отключена администратором
			</div>
		<?php endif;
		$title->GetFooter([]);
	break;
}