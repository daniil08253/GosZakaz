<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
//////////////////////////////////////////////////
// Системная настройка
define('R', $_SERVER['DOCUMENT_ROOT']);
/// Выбран ли файл
if(!empty($_FILES['file']['name'])):

else:
	header('location: /'); exit;
endif;
//
////////////////////////////////////////////////////////////
if($user['datalast'] > (time() - 2)) {
	DB::$dbs->querySql('UPDATE user SET updatedei = updatedei + 1 WHERE id = ?',[$user['id']]);
	if($user['updatedei'] > 5) {
		$naskb = $user['naskokban'] * 2;
		DB::$dbs->querySql('UPDATE user SET updatedei = 0, naskokban = ?, timeban = ? WHERE id = ?',[$naskb,time() + $naskb,$user['id']]); 
		$d = ['message' => 'Вы забанены.', 'type' => 'error'];
		echo json_encode($d); exit;
	} else {
		$d = ['message' => 'Давай не так быстро.', 'type' => 'error'];
		echo json_encode($d); exit;
	}
}
////////////////////////////////////////////////////////////
$chto = $functions->htmlred($_GET['chto']);
$name = $functions->htmlred(basename($_FILES['file']['name'])); // фильтруем

if($chto == 'useraudio'): // аудио пользователя загрузка
	$whitelist = ['mp3']; // разрешения
	$maxsize = 20; // максимальный размер в мегабайтах
else:
	$whitelist = ['jpg', 'jpeg', 'png', 'svg', 'gif']; // разрешения
	$maxsize = 10; // максимальный размер в мегабайтах
endif;
$dir = R.'/files/photo'; // куда загружаем
$dirm = R.'/files/photo/m'; // куда загружаем меньше версию
$indos = new SplFileInfo($name);
$ext = $indos->getExtension();
$size = $_FILES['file']['size']; // вес файла
if ($size > (1048576 * $maxsize)): // если большой размер
	$err = "Максимальный вес файла $maxsize МБ.";
elseif(!in_array($ext, $whitelist)): // если расширение файла не допустимо
	$err = 'Такое разрешение не допустимо.';
endif;
if(isset($err)):
	$_SESSION['err'] = $err;
	header('location: /'); exit;
endif;
//////////////////////////////////////////////////
// Основные разделы
switch ($act) {
	default:
		header('location: /'); exit;
	break;
	case 'avatar':
		//
		$fasa = ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? 1 : 0; 
		if($fasa == 0): exit('Ошибка'); endif;
		//
		$tmp_name = $functions->htmlred($_FILES["file"]["tmp_name"]);
		$avas = DOMAIN.'_'.mt_rand(9999,999999).time().'.'.$ext;
		move_uploaded_file($tmp_name, "$dir/$avas");
		if ($functions->img_resize($dir.'/'.$avas, $dirm.'/'.$avas, 60, 60)):
			/*
			// сначала смотрим есть ли системный альбом
			if(DB::$dbs->querySingle('SELECT COUNT(id) FROM album WHERE idus = ? and intr = 0 and chto = ?',[$user['id'],$chto]) == 0):
				// создаем альбом потому что его нет
				DB::$dbs->querySql('INSERT INTO album SET idus = ?, name = ?, opis = ?, dell = 0, intr = 0, time = ?, updatealb = ?, chto = ?',[$user['id'],'Фотографии со страницы','Фотографии со страницы',time(),time(),$chto]);
				$idalb = DB::$dbs->lastInsertId(); // сюда заливаем фото
			else: // Если альбом есть смотрим его id
				$qqq = DB::$dbs->queryFetch('SELECT id FROM album WHERE idus = ? and intr = 0 and dell = 0 and chto = ? LIMIT 1', [$user['id'],$chto]);
				$idalb = $qqq['id']; // сюда заливаем фото
			endif;
			*/
			$qqq = DB::$dbs->queryFetch('SELECT id FROM album WHERE idus = ? and intr = 0 and dell = 0 and chto = ? LIMIT 1', [$user['id'],$chto]);
			// добавляем саму фотографию
			DB::$dbs->querySql('INSERT INTO photo SET idus = ?, id_album = ?, name = ?, time = ?, opis = ?, photo = ?, chto = ?, razr = ?',[$user['id'],$qqq['id'],'Фотография на аватар',time(),'Фотография на аватар',$avas,$chto,$ext]);
			$idphoto = DB::$dbs->lastInsertId();
			if($chto == 'user'):
				DB::$dbs->querySql('UPDATE user SET avatar = ? WHERE id = ?',[$idphoto,$user['id']]);
			endif;
			///
			$curl_files1 = ['file[0]' => curl_file_create($dir.'/'.$avas, 'mimetype')];
			$curl_files2 = ['file[0]' => curl_file_create($dirm.'/'.$avas, 'mimetype')];
			$json = $curl->curlload($curl_files1,'photo/');
			$json2 = $curl->curlload($curl_files2,'photo/m/');
			if($json->type == 'error' or $json2->type == 'error'):
				$d = ['message' => $json->message, 'type' => 'error'];
				echo json_encode($d); exit;
			else:
				unlink($dir.'/'.$avas);
				unlink($dirm.'/'.$avas);
				// Обновляем альбом
				DB::$dbs->querySql('UPDATE album SET photosid = ?, updatealb = ? WHERE id = ? and chto = ?',[$avas,time(),$qqq['id'],$chto]);
			endif; 
		else:
			unlink($dir.'/'.$avas);
			$d = ['message' => 'Ошибка обработки изображений.', 'type' => 'error'];
			echo json_encode($d); exit;
		endif;
		$d = ['bizes' => 7, 'message' => 'Аватар успешно обновлен.', 'type' => 'success'];
		echo json_encode($d); exit;
	break;
	case 'albums':
		if($chto == 'user'): // албомы пользователей
			// Смотрим есть ли такой альбом
			$qqq = DB::$dbs->queryFetch('SELECT id FROM album WHERE id = ? LIMIT 1', [$id]);
			if(empty($qqq['id'])): header('location: /'); exit; endif;
		endif;
		$tmp_name = $functions->htmlred($_FILES["file"]["tmp_name"]);
		$avas = DOMAIN.'_'.mt_rand(9999,999999).time().'.'.$ext;
		$curl_files1 = ['file[0]' => curl_file_create($tmp_name, 'mimetype', $avas)];
		$json = $curl->curlload($curl_files1,'photo/');
		if($json->type == 'error'):
			echo $json->message; exit;
		else:
			DB::$dbs->querySql('INSERT INTO photo SET idus = ?, id_album = ?, name = ?, time = ?, opis = ?, photo = ?, chto = ?, razr = ?',[$user['id'],$qqq['id'],'Фотография в альбом',time(),'Фотография в альбом',$avas,$chto,$ext]);
			// Обновляем альбом
			DB::$dbs->querySql('UPDATE album SET photosid = ?, updatealb = ? WHERE id = ? and chto = ?',[$avas,time(),$qqq['id'],$chto]);
			header('location: /albums'.$user['id'].'_'.$qqq['id']); exit;
		endif;
	break;
	case 'audio':
		$tmp_name = $functions->htmlred($_FILES["file"]["tmp_name"]);
		require_once($_SERVER['DOCUMENT_ROOT'].'/system/lib/getID3/getid3/getid3.php');
		$getID3 = new getID3;
		$file = $getID3->analyze($tmp_name);
		$artis = isset($file['tags']['id3v2']['artist'][0]) ? $file['tags']['id3v2']['artist'][0] : 'unknown';
		$title = isset($file['tags']['id3v2']['title'][0]) ? $file['tags']['id3v2']['title'][0] : 'unknown';
		$avas = DOMAIN.'_'.mt_rand(9999,999999).time().'.'.$ext;
		//$dirmusic = R.'/files/photo'; // куда загружаем
		$curl_files1 = ['file[0]' => curl_file_create($tmp_name, 'mimetype', $avas)];
		$json = $curl->curlload($curl_files1,'music/');
		if($json->type == 'error'):
			echo $json->message; exit;
		else:
			DB::$dbs->querySql('INSERT INTO audio SET idus = ?, file = ?, time = ?, name = ?, opis = ?, chto = ?, razr = ?',[$user['id'],$avas,time(),$artis,$title,$chto,$ext]);
			$idalb = DB::$dbs->lastInsertId();
			DB::$dbs->querySql('INSERT INTO audio_us SET idus = ?, id_audio = ?, time = ?, name = ?, opis = ?, chto = ?',[$user['id'],$idalb,time(),$artis,$title,$chto]);
			header('location: /audio'.$user['id']); exit;
		endif;


		/*
		if($json->type == 'error'):
			echo 'Не удалось загрузить';
		else:
			echo 'Успешно';
		endif;
		*/
	break;
}