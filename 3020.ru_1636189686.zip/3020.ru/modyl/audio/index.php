<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
// 3020.ru - скрипты тут
switch ($act) {
	default:
		if(empty($user['id'])): header('location: /'); exit; endif;
		$chto = $functions->htmlred($_GET['chto']);
		$qqq = DB::$dbs->queryFetch('SELECT id,url FROM user WHERE id = ? LIMIT 1', [$id]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		$title->SetTitle('Аудиозаписи '.$usemi->logins(['id' => $qqq['id'], 'name' => 1]));
		$title->SetHais('Аудиозаписи '.$usemi->logins(['id' => $qqq['id'], 'name' => 1, 'url' => 1]));
		$title->GetHeader([]); ?> 
			<div class="_fowhadfh397yfh9">
				<span class="_ifawouifh397yhf9e" style="margin-right: 5px;"><?php echo $functions->slv(DB::$dbs->querySingle('SELECT COUNT(id) FROM audio_us WHERE idus = ? and chto = ?',[$qqq['id'],$chto]),['аудиозапись','аудиозаписи','аудиозаписей']);?></span>
				<?php if(isset($user['id']) and $user['id'] == $qqq['id']): ?>
					| <form action="/upload/audio/useraudio/<?php echo $user['id'];?>/" style="display: inline;margin-left: 5px;" method="post" enctype="multipart/form-data">
						<input type="file" name="file" id="file" class="_e4tgrethn" onchange="this.form.submit ()">
						<label for="file">Загрузить аудио</label>
					</form>
				<?php endif; ?>
			</div>
			<?php if(DB::$dbs->querySingle('SELECT COUNT(id) FROM audio_us WHERE idus = ? and chto = ?',[$qqq['id'],$chto]) == 0): ?>
				<div><div style="margin-top: 15px;margin-bottom: 10px;" class="_08f8ghrg83qgh">Пока нет аудиозаписей</div></div>
			<?php else:
				$sql1 = DB::$dbs->querySql('SELECT name,opis,id,id_audio FROM audio_us WHERE idus = ? and chto = ? ORDER BY time DESC LIMIT 30',[$qqq['id'],$chto])->fetchAll(PDO::FETCH_ASSOC);
				foreach ($sql1 as $sqlls => $files): 
					$audio = DB::$dbs->queryFetch('SELECT * FROM audio WHERE id = ? LIMIT 1', [$files['id_audio']]); 
					if(isset($audio['id'])): ?>
						<div class="_dwia89tgeg9" id="addaudio_<?php echo $files['id_audio'];?>gl">
							<button action="/sess/audio/?id_music=<?php echo $files['id_audio'];?>" id="play-status<?php echo $audio['id'];?>" onclick="MusicPlay('<?php echo $files['id_audio'];?>','<?php echo $audio['file'];?>')" class="play-status-off play-button-style"><?php echo (isset($_SESSION['id_music']) and $_SESSION['id_music'] == $files['id_audio']) ? '<span class="material-icons">pause</span>' : '<span class="material-icons">play_arrow</span>';?> </button> <div class="_namer333"><?php echo $audio['name'];?></div> - <div class="_opis"><?php echo $audio['opis'];?></div><div class="_88ygrgh47g9erhg9"> <?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM audio_us WHERE idus = ? and id_audio = ?',[$user['id'],$files['id_audio']]) > 0 ? '<span onclick="k09f48wgrgirj49(\'#addaudio_'.$files['id_audio'].'\',\'/ajs/audio/add/'.$chto.'/'.$files['id_audio'].'/\');" id="addaudio_'.$files['id_audio'].'"><span class="material-icons"> delete </span></span>' : '<span onclick="k09f48wgrgirj49(\'#addaudio_'.$files['id_audio'].'\',\'/ajs/audio/add/'.$chto.'/'.$files['id_audio'].'/\');" id="addaudio_'.$files['id_audio'].'"><span class="material-icons"> add </span></span>';?></div>
						</div>
					<?php else: ?>
						<div class="_dwia89tgeg9" id="addaudio_<?php echo $files['id_audio'];?>gl">
							<div class="_namer333">Удалено</div>
							<div class="_88ygrgh47g9erhg9"> <?php echo DB::$dbs->querySingle('SELECT COUNT(id) FROM audio_us WHERE idus = ? and id_audio = ?',[$user['id'],$files['id_audio']]) > 0 ? '<span onclick="k09f48wgrgirj49(\'#addaudio_'.$files['id_audio'].'\',\'/ajs/audio/add/'.$chto.'/'.$files['id_audio'].'/\');" id="addaudio_'.$files['id_audio'].'"><span class="material-icons"> delete </span></span>' : NULL;?></div>
						</div>
					<?php endif;
				endforeach;
			endif;
		$title->GetFooter([]);
	break;
}