<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
switch ($act) {
	default:
		$ids = $functions->ints($_GET['ids']);
		$qqq = DB::$dbs->queryFetch('SELECT id,closewall FROM user WHERE id = ? LIMIT 1', [$ids]);
		if(empty($qqq['id'])): header('location: /'); exit; endif;
		$kommes = DB::$dbs->queryFetch('SELECT id FROM komm WHERE id = ? LIMIT 1', [$id]);
		if(empty($kommes['id'])): header('location: /'); exit; endif;
		///
		$title->SetTitle($usemi->logins(['id' => $qqq['id'], 'name' => 3]));
		$title->SetHais($usemi->logins(['id' => $qqq['id'], 'name' => 3]).' » Стена » Запись');
		$title->GetHeader([]); ?>
		<div class="_podawd3ruf8uf">
			<?php echo $komm->kammid($kommes['id']);?>
		</div>
		<div class="_0q9tgur89ug04 _grid7">
			<div>
				<div class="_fioawif38h9gh" style="display: block;">
					<?php if(isset($user['id']) and ($qqq['closewall'] == 0 or $qqq['id'] == $user['id'])):
						echo $komm->aktivkomm(['id' => $id, 'chto' => 'userwallkomm']); ?>
						<div id="moreNews33"></div>
					<?php elseif(isset($user['id'])): ?>
						<div style="text-align: center;">Тут комментарии отключены</div>
					<?php endif;
					echo $komm->kommes(['id' => $id, 'chto' => 'userwallkomm']); ?>
				</div>
			</div>
			<div class="_q3088g4w98gh">
				<h4>Действие</h4>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}
