<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
// 3020.ru - скрипты тут
switch ($act) {
	default:
		if(isset($user['id'])): header('location: /'); exit; endif;
		$title->SetTitle('Регистрация');
		$title->SetHais('Регистрация');
		$title->GetHeader([]);
		$qqq = DB::$dbs->queryFetch('SELECT id,datareg FROM user ORDER BY datareg DESC LIMIT 1');
		if($qqq['datareg'] < (time() - 43200)) { //43200 ?>
			<div class="container container2">
				<form class="_formautsda" id="ajax_form" action="" method="post" onsubmit="return false;">
					<div class="_grid2">
						<div class="_name">Имя</div>
						<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="name" value="" autofocus="true" placeholder="Имя"></div>
					</div>
					<div class="_grid2">
						<div class="_name">Фамилия</div>
						<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="fame" value="" autofocus="true" placeholder="Фамилия"></div>
					</div>
					<div class="_grid2">
						<div class="_name">Пол</div>
						<select name="sex" class="_ijaowidj4378t9">
							<option value="1">мужской</option>
							<option value="2" selected="">женский</option>
						</select>
					</div>
					<div class="_grid2">
						<div class="_name">День рождения</div>
						<div><input max="2021-10-15" class="_ijaowidj4378t9" type="date" maxlength="100" name="dayr" value="" autofocus="true"></div>
					</div>
					<div class="_grid2">
						<div class="_name">Электронная почта:</div>
						<div><input class="_ijaowidj4378t9" type="email" maxlength="100" name="email" value="" autofocus="true" placeholder="Электронная почта"></div>
					</div>
					<div class="_grid2">
						<div class="_name">Пароль</div>
						<div><input class="_ijaowidj4378t9" type="password" maxlength="100" name="password" value="" autofocus="true" placeholder="Пароль"></div>
					</div>
					<div class="_grid1" style="margin-top: 20px;text-align: center;">
						<div><input onclick="saveform ('/ajs/reg/','#ajax_form');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Регистрация"></div>
						<div><a class="_30tuq8euf9ufgw _3r09g0frw0" href="<?php echo DOMAIN2;?>/aut/">Авторизация</a></div>
					</div>
				</div>
			</div>
		<?php } else {
			echo 'Пока нельзя зарегистрироваться';
		}
		$title->GetFooter([]);
	break;
}