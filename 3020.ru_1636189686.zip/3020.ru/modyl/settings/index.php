<?php require($_SERVER['DOCUMENT_ROOT'].'/system/system.php');
if(empty($user['id'])): header('location: /'); exit; endif;
switch ($act) {
	default:
	break;
	case 'osn':
		$title->SetTitle('Мои Настройки');
		$title->SetHais('Мои Настройки');
		$title->GetHeader([]);?>
		<div>
			<div class="_grid4 _wjidj3h9euhg9">
				<a class="_39te0gr8ijgw" href="<?php echo DOMAIN2;?>/settings">Основное</a>
				<a href="<?php echo DOMAIN2;?>/settings/privacy/">Приватность</a>
				<a href="<?php echo DOMAIN2;?>/settings/interface/">Внешний вид</a>
				<a href="<?php echo DOMAIN2;?>/settings/goloca/">Голоса</a>
			</div>
			<div class="_ifjaf3ht78gh9ugh">
				<div class="_frj8fh8f7g9r">
					<h2>Изменить пароль</h2>
					<div class="container container2">
						<form class="_formautsda" id="ajax_form2" action="" method="post" onsubmit="return false;">
							<div class="_grid2">
								<div class="_name">Старый пароль</div>
								<div><input class="_ijaowidj4378t9" type="text" maxlength="100" name="passwordst" value="" autocomplete="off" placeholder="Старый пароль"></div>
							</div>
							<div class="_grid2">
								<div class="_name">Новый пароль</div>
								<div><input class="_ijaowidj4378t9" type="password" maxlength="100" name="password" value="" autocomplete="off" placeholder="Новый пароль"></div>
							</div>
							<div class="_grid2">
								<div class="_name">Повторите пароль</div>
								<div><input class="_ijaowidj4378t9" type="password" maxlength="100" name="password2" value="" autocomplete="off" placeholder="Повторите пароль"></div>
							</div>
							<div style="margin-top: 20px;text-align: center;">
								<div><input onclick="saveform ('/ajs/red/osn/','#ajax_form2');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Изменить пароль"></div>
							</div>
						</form>
					</div>
				</div>
				<div class="_frj8fh8f7g9r">
					<h2>Адрес Вашей электронной почты</h2>
					<div class="container container2">
						<div class="_grid2">
							<div class="_name">Текущий адрес</div>
							<div><?php echo $user['email'];?></div>
						</div>
					</div>
				</div>
				<div class="_frj8fh8f7g9r">
					<h2>Адрес Вашей страницы</h2>
					<div class="container container2">
						<form class="_formautsda" id="ajax_form3" action="" method="post" onsubmit="return false;">
							<div class="_grid2">
								<div class="_name">ID страницы</div>
								<div><?php echo $user['id'];?></div>
							</div>
							<div class="_grid2">
								<div class="_name">Адрес страницы</div>
								<div>
									<div class="_f9gw08gh0rhg840g">
										<div class="_39e9f0wg0r4tgre"><?php echo DOMAIN2;?>/</div>
										<div class="_dawwrf83yt8wg0">
											<input class="_awdtrgtreg4g" type="text" maxlength="100" name="url" value="<?php echo $user['url'];?>" autocomplete="off" placeholder="Ваша короткая сслыка">
											<div class="_dwaj9d38hf09gr"></div>
										</div>
									</div>
								</div>
							</div>
							<div style="margin-top: 20px;text-align: center;">
								<div><input onclick="saveform ('/ajs/settings/urlstr/','#ajax_form3');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Сохранить"></div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
	case 'privacy':
		$title->SetTitle('Приватность');
		$title->SetHais('Приватность');
		$title->GetHeader([]); ?>
		<div>
			<div class="_grid4 _wjidj3h9euhg9">
				<a href="<?php echo DOMAIN2;?>/settings">Основное</a>
				<a class="_39te0gr8ijgw" href="<?php echo DOMAIN2;?>/settings/privacy/">Приватность</a>
				<a href="<?php echo DOMAIN2;?>/settings/interface/">Внешний вид</a>
				<a href="<?php echo DOMAIN2;?>/settings/goloca/">Голоса</a>
			</div>
			<div class="_ifjaf3ht78gh9ugh">
				<div class="container container2">
					<form class="_formautsda" id="ajax_form" action="" method="post" onsubmit="return false;">
						<div class="_grid2">
							<div class="_name">Кому видно мои видеозаписи:</div>
							<select name="eyevideo" class="_ijaowidj4378t9">
								<option value="1" <?php echo $user['eyevideo'] == 1 ? 'selected=""' : NULL;?>>Всем желающим</option>
								<option value="2" <?php echo $user['eyevideo'] == 2 ? 'selected=""' : NULL;?>>Пользователям <?php echo DOMAIN3;?></option>
								<option value="3" <?php echo $user['eyevideo'] == 3 ? 'selected=""' : NULL;?>>Друзьям</option>
								<option value="4" <?php echo $user['eyevideo'] == 4 ? 'selected=""' : NULL;?>>Только мне</option>
							</select>
						</div>
						<div class="_grid2">
							<div class="_name">Кому видно мои заметки:</div>
							<select name="eyenotes" class="_ijaowidj4378t9">
								<option value="1" <?php echo $user['eyenotes'] == 1 ? 'selected=""' : NULL;?>>Всем желающим</option>
								<option value="2" <?php echo $user['eyenotes'] == 2 ? 'selected=""' : NULL;?>>Пользователям <?php echo DOMAIN3;?></option>
								<option value="3" <?php echo $user['eyenotes'] == 3 ? 'selected=""' : NULL;?>>Друзьям</option>
								<option value="4" <?php echo $user['eyenotes'] == 4 ? 'selected=""' : NULL;?>>Только мне</option>
							</select>
						</div>
						<div style="margin-top: 20px;text-align: center;">
							<div><input onclick="saveform ('/ajs/settings/privacy/','#ajax_form');return false;" style="width: 60%;display: inline-block;" class="_30tuq8euf9ufgw" type="submit" name="add" value="Сохранить"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php $title->GetFooter([]);
	break;
}