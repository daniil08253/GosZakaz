-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: 10.0.0.241:3306
-- Время создания: Ноя 06 2021 г., 08:51
-- Версия сервера: 10.5.12-MariaDB-log
-- Версия PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `j23271815_wiq`
--

-- --------------------------------------------------------

--
-- Структура таблицы `album`
--

CREATE TABLE `album` (
  `id` int(15) NOT NULL,
  `idus` int(15) DEFAULT NULL COMMENT 'ид пользователя',
  `name` varchar(200) DEFAULT NULL COMMENT 'название альбома',
  `opis` varchar(200) DEFAULT NULL COMMENT 'описание альбома',
  `dell` int(1) NOT NULL DEFAULT 1 COMMENT 'можно ли удалять альбом',
  `intr` int(2) DEFAULT NULL COMMENT 'системный альбом',
  `time` int(15) DEFAULT NULL COMMENT 'время создания альбома',
  `updatealb` int(15) DEFAULT NULL COMMENT 'время обновления альбома',
  `photosid` varchar(100) DEFAULT NULL COMMENT 'последняя залитая фотка',
  `chto` varchar(100) DEFAULT NULL COMMENT 'от куда альбом'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `album`
--

INSERT INTO `album` (`id`, `idus`, `name`, `opis`, `dell`, `intr`, `time`, `updatealb`, `photosid`, `chto`) VALUES
(1, 1, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1634497604, 1635356737, 'vkphp.ru_2422421635356737.jpg', 'user'),
(2, 1, 'Фотографии со стены', 'Фотографии со стены', 0, 1, 1634497634, 1634840704, 'camera_200.png', 'user'),
(3, 2, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1634501039, 1634501039, 'vkphp.ru_2531634501039.jpg', 'user'),
(8, 2, 'test', 'test', 1, 3, 1634653340, 1634653387, 'vkphp.ru_754581634653387.jpg', 'user'),
(13, 4, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1634757678, 1634757678, NULL, 'user'),
(14, 5, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1634757727, 1634757727, 'camera_200.png', 'user'),
(15, 6, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1634757877, 1634757877, 'camera_200.png', 'user'),
(17, 7, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1634977794, 1634978572, 'vkphp.ru_6588981634978572.jpg', 'user'),
(18, 7, 'Фотографии со стены', 'Фотографии со стены', 0, 1, 1634977794, 1634995528, 'vkphp.ru_301671634995528.png', 'user'),
(19, 8, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1635086522, 1635086522, 'camera_200.png', 'user'),
(20, 8, 'Фотографии со стены', 'Фотографии со стены', 0, 1, 1635086522, 1635086522, 'camera_200.png', 'user'),
(21, 9, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1635087249, 1635087763, 'vkphp.ru_495601635087762.jpeg', 'user'),
(22, 9, 'Фотографии со стены', 'Фотографии со стены', 0, 1, 1635087249, 1636143921, 'vkphp.ru_799001636143921.jpeg', 'user'),
(23, 10, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1635087421, 1635087605, 'vkphp.ru_3362771635087605.jpg', 'user'),
(24, 10, 'Фотографии со стены', 'Фотографии со стены', 0, 1, 1635087421, 1635087421, 'camera_200.png', 'user'),
(25, 9, 'Порно', NULL, 1, 3, 1635091982, 1635092702, 'vkphp.ru_1532781635092702.png', 'user'),
(26, 1, 'яяя', 'яяяя', 1, 3, 1635092229, 1635092381, 'vkphp.ru_9431041635092381.jpg', 'user'),
(27, 11, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1635197166, 1635197370, 'vkphp.ru_8541241635197370.jpg', 'user'),
(28, 11, 'Фотографии со стены', 'Фотографии со стены', 0, 1, 1635197166, 1635726922, 'vkphp.ru_637101635726922.jpg', 'user'),
(29, 11, 'Тест', NULL, 1, 3, 1635199701, 1635201526, 'vkphp.ru_7907001635201526.jpg', 'user'),
(31, 11, 'Ыыыыы', NULL, 1, 3, 1635199871, 1635199871, 'camera_200.png', 'user'),
(32, 12, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1635250515, 1635250515, 'camera_200.png', 'user'),
(33, 12, 'Фотографии со стены', 'Фотографии со стены', 0, 1, 1635250515, 1635250515, 'camera_200.png', 'user'),
(34, 13, 'Фотографии со страницы', 'Фотографии со страницы', 0, 0, 1636188630, 1636188630, 'camera_200.png', 'user'),
(35, 13, 'Фотографии со стены', 'Фотографии со стены', 0, 1, 1636188630, 1636188630, 'camera_200.png', 'user');

-- --------------------------------------------------------

--
-- Структура таблицы `audio`
--

CREATE TABLE `audio` (
  `id` int(15) NOT NULL COMMENT 'ид',
  `idus` int(15) DEFAULT NULL COMMENT 'ид пользователя кто добавил',
  `file` varchar(100) DEFAULT NULL COMMENT 'файл',
  `time` int(15) DEFAULT NULL COMMENT 'время',
  `name` varchar(150) DEFAULT NULL COMMENT 'название',
  `opis` varchar(150) DEFAULT NULL COMMENT 'описание',
  `chto` varchar(50) DEFAULT NULL COMMENT 'куда добавлено видео',
  `razr` varchar(50) DEFAULT NULL COMMENT 'разрешение файла'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `audio`
--

INSERT INTO `audio` (`id`, `idus`, `file`, `time`, `name`, `opis`, `chto`, `razr`) VALUES
(1, 7, 'vkphp.ru_2374511634988836.mp3', 1634988836, 'Stormzy', 'Own It (feat. Ed Sheeran & Burna Boy)', 'useraudio', 'mp3'),
(2, 7, 'vkphp.ru_6576091634988937.mp3', 1634988937, 'Maroon 5', 'Sugar (zaycev.net)', 'useraudio', 'mp3'),
(3, 7, 'vkphp.ru_9035461634989139.mp3', 1634989139, 'unknown', 'unknown', 'useraudio', 'mp3'),
(4, 7, 'vkphp.ru_7170681634989212.mp3', 1634989212, 'unknown', 'unknown', 'useraudio', 'mp3'),
(5, 1, 'vkphp.ru_7251911635080978.mp3', 1635080979, 'Boris Brejcha', 'Redemption', 'useraudio', 'mp3'),
(6, 1, 'vkphp.ru_8124501635081914.mp3', 1635081914, 'Calvin Harris and Tom Grennan', 'By Your Side', 'useraudio', 'mp3'),
(8, 11, 'vkphp.ru_1339001635197686.mp3', 1635197686, 'Blue Foundation', 'Eyes On Fire (Zeds Dead Remix) (Sefon.me)', 'useraudio', 'mp3');

-- --------------------------------------------------------

--
-- Структура таблицы `audio_us`
--

CREATE TABLE `audio_us` (
  `id` int(15) NOT NULL COMMENT 'ид',
  `idus` int(15) DEFAULT NULL COMMENT 'кто добавил',
  `id_audio` int(15) DEFAULT NULL COMMENT 'ид аудио',
  `time` int(15) NOT NULL COMMENT 'время',
  `name` varchar(150) DEFAULT NULL COMMENT 'артист',
  `opis` varchar(150) DEFAULT NULL COMMENT 'название',
  `chto` varchar(50) DEFAULT NULL COMMENT 'куда добавлено'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `audio_us`
--

INSERT INTO `audio_us` (`id`, `idus`, `id_audio`, `time`, `name`, `opis`, `chto`) VALUES
(1, 7, 1, 1634988836, 'Stormzy', 'Own It (feat. Ed Sheeran & Burna Boy)', 'useraudio'),
(2, 7, 2, 1634988937, 'Maroon 5', 'Sugar (zaycev.net)', 'useraudio'),
(3, 7, 3, 1634989139, 'unknown', 'unknown', 'useraudio'),
(4, 7, 4, 1634989212, 'unknown', 'unknown', 'useraudio'),
(5, 1, 4, 1635002845, 'unknown', 'unknown', 'useraudio'),
(6, 1, 3, 1635002846, 'unknown', 'unknown', 'useraudio'),
(7, 1, 2, 1635002847, 'Maroon 5', 'Sugar (zaycev.net)', 'useraudio'),
(8, 1, 1, 1635002847, 'Stormzy', 'Own It (feat. Ed Sheeran & Burna Boy)', 'useraudio'),
(9, 1, 5, 1635080979, 'Boris Brejcha', 'Redemption', 'useraudio'),
(10, 1, 6, 1635081914, 'Calvin Harris and Tom Grennan', 'By Your Side', 'useraudio'),
(12, 11, 8, 1635197688, 'Blue Foundation', 'Eyes On Fire (Zeds Dead Remix) (Sefon.me)', 'useraudio');

-- --------------------------------------------------------

--
-- Структура таблицы `friends`
--

CREATE TABLE `friends` (
  `id` int(15) NOT NULL,
  `idus` int(15) DEFAULT NULL,
  `cogo` int(15) DEFAULT NULL,
  `time` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `friends`
--

INSERT INTO `friends` (`id`, `idus`, `cogo`, `time`) VALUES
(25, 1, 9, 1635091364),
(26, 9, 1, 1635091364),
(27, 10, 9, 1635094868),
(28, 9, 10, 1635094868),
(33, 1, 2, 1635181929),
(34, 2, 1, 1635181929),
(35, 1, 11, 1635237656),
(36, 11, 1, 1635237656),
(37, 9, 11, 1635263863),
(38, 11, 9, 1635263863);

-- --------------------------------------------------------

--
-- Структура таблицы `friends_new`
--

CREATE TABLE `friends_new` (
  `id` int(15) NOT NULL,
  `idus` int(15) DEFAULT NULL,
  `cogo` int(15) DEFAULT NULL,
  `time` int(15) DEFAULT NULL,
  `uved` int(1) NOT NULL DEFAULT 1 COMMENT 'заявка'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `friends_new`
--

INSERT INTO `friends_new` (`id`, `idus`, `cogo`, `time`, `uved`) VALUES
(19, 1, 6, 1634801205, 1),
(26, 9, 2, 1635091960, 1),
(28, 10, 1, 1635097293, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `komm`
--

CREATE TABLE `komm` (
  `id` int(15) NOT NULL,
  `idus` int(15) DEFAULT NULL,
  `time` int(15) DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 DEFAULT NULL,
  `chto` varchar(100) DEFAULT NULL,
  `ids` int(15) DEFAULT NULL COMMENT 'где оставлена',
  `otv` int(15) DEFAULT NULL COMMENT 'считалось ли это ответом',
  `images` int(15) DEFAULT NULL COMMENT 'изображение если есть',
  `repost` int(1) DEFAULT NULL COMMENT 'ид репоста',
  `zakrep` int(1) NOT NULL DEFAULT 0 COMMENT 'закреплено или нет',
  `url` varchar(150) DEFAULT NULL COMMENT 'ссылка где оставлен пост',
  `repostchto` varchar(100) DEFAULT NULL COMMENT 'если репост то чего',
  `messageobr` text DEFAULT NULL COMMENT 'обрезанное сообщение'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `komm`
--

INSERT INTO `komm` (`id`, `idus`, `time`, `message`, `chto`, `ids`, `otv`, `images`, `repost`, `zakrep`, `url`, `repostchto`, `messageobr`) VALUES
(2, 2, 1634501101, 'Не пишите мне, я все равно бот и создан для уведомлений пользователей. Спасибо, что не забиваете мою личку сообщениями.', 'user', 2, NULL, NULL, NULL, 0, NULL, NULL, NULL),
(48, 1, 1634587068, 'ffe', 'photo', 22, NULL, 27, NULL, 0, 'photo1_22', NULL, NULL),
(84, 1, 1634659006, 'какакакакак', 'photo', 52, NULL, NULL, NULL, 0, 'photo10_52', NULL, NULL),
(90, 1, 1634676577, 'Где нет конкуренции — нет прогресса.', 'user', 1, NULL, NULL, NULL, 0, 'id1', NULL, NULL),
(92, 1, 1634676997, '&quot;Насколько человек побеждает страх, настолько он человек.&quot; (Томас Карлейль)', 'user', 1, NULL, NULL, NULL, 0, 'id1', NULL, NULL),
(93, 1, 1634677042, 'ммммм', 'user', 1, NULL, NULL, 2, 0, NULL, 'komm', NULL),
(95, 1, 1634752983, 'Самый опасный яд — информационный.', 'user', 1, NULL, NULL, NULL, 0, 'id1', NULL, NULL),
(104, 1, 1634762240, 'Мда, исправил сегодня кучу ошибок, радует то, что их (ошибок) становиться все меньше, так же из классных нововведений сделал аудиозаписи.\r\n\r\nТеперь можно добавлять свои аудиозаписи или слушать у друзей. Так же если слушать музыку, то она будет транслироваться к вам в статус.', 'user', 1, NULL, NULL, NULL, 0, 'id1', NULL, NULL),
(105, 1, 1634802127, 'Решил отказаться от раздела &quot;Подписчики&quot; на странице в пользу места, ведь не загарами новые разделы: Видеозаписи, заметки, группы и все это надо где-то размещать. Теперь раздел ушёл вверх и появилось свободное местечко 🥳', 'user', 1, NULL, NULL, NULL, 0, 'id1', NULL, NULL),
(133, 1, 1634916901, 'Лавина обновлений...\r\n\r\nЗавтра будет ровно неделя, когда ночью по приколу я запили первую страницу с регистрацией, a сегодня уже более 7 разделов и более 40 функций сайта. Фотоальбомы, видеозаписи, друзья, настройки, анкета и многие другие мелочи, которые были успешно позаимствованы с вконтакте 2011 годов.\r\n\r\nРаботы ещё много, но не так много, сколько я уже сделал. Модульность системы позволит вставить комментарии, фотоальбомы и видео на любую страницу без больших знаний php,mysql. Чем горжусь. В выходные открою регистрацию по инвайтам, что бы определить как можно больше ошибок, а уже через недельку-две выложу релиз первой версии на git.\r\n\r\nМобильную версию буду делать позднее, как только сделаю основное, ведь под мобильные устройства надо подгонять отдельно.', 'user', 1, NULL, NULL, NULL, 0, 'id1', NULL, 'Лавина обновлений...\r\n\r\nЗавтра будет ровно неделя, когда ночью по приколу я запили первую страницу с регистрацией, a сегодня уже более 7 разделов и более 40 функций сайта. Фотоальбомы, видеозаписи, друзья, настройки, анкета и многие другие мелочи, которые были успешно'),
(134, 2, 1634916942, 'Шик', 'user', 2, NULL, NULL, 133, 0, NULL, 'komm', NULL),
(153, 1, 1634991808, 'DWADDWADWDWADWADW', 'userwallkomm', 151, NULL, NULL, NULL, 0, 'wall1_151', NULL, NULL),
(190, 10, 1635087690, 'Когда будут группы?', 'userwallkomm', 133, NULL, NULL, NULL, 0, 'wall1_133', NULL, NULL),
(192, 10, 1635087774, 'Классно 😏', 'user', 10, NULL, NULL, 133, 0, NULL, 'komm', NULL),
(193, 9, 1635087814, '😁😜', 'user', 9, NULL, 98, NULL, 0, 'id9', NULL, NULL),
(195, 9, 1635087846, 'Соска', 'userwallkomm', 193, NULL, NULL, NULL, 0, 'wall9_193', NULL, NULL),
(196, 9, 1635087856, '', 'userwallkomm', 193, NULL, 100, NULL, 0, 'wall9_193', NULL, NULL),
(198, 9, 1635087935, 'Чел', 'user', 9, NULL, 101, NULL, 0, 'id9', NULL, NULL),
(199, 9, 1635087953, '&amp;&amp;&amp;&amp;-', 'userwallkomm', 198, NULL, NULL, NULL, 0, 'wall9_198', NULL, NULL),
(200, 9, 1635088056, 'Хех', 'usernotes', 9, NULL, NULL, NULL, 0, 'notes9_9', NULL, NULL),
(212, 9, 1635090781, 'Лол, коменты закрыты', 'photo', 97, NULL, NULL, NULL, 0, 'photo21_97', NULL, NULL),
(213, 9, 1635090993, '', 'user', 9, NULL, NULL, 198, 0, NULL, 'komm', NULL),
(214, 9, 1635091006, '', 'user', 9, NULL, NULL, 213, 0, NULL, 'komm', NULL),
(215, 9, 1635091020, '', 'user', 9, NULL, NULL, 214, 0, NULL, 'komm', NULL),
(217, 9, 1635091313, '', 'user', 9, NULL, NULL, 190, 0, NULL, 'komm', NULL),
(218, 9, 1635091321, 'Lil Pump', 'userwallkomm', 133, NULL, NULL, NULL, 0, 'wall1_133', NULL, NULL),
(219, 1, 1635091519, 'гггг', 'userwallkomm', 216, NULL, NULL, NULL, 0, 'wall9_216', NULL, NULL),
(220, 1, 1635091754, 'писька вонючая', 'user', 9, NULL, NULL, NULL, 0, 'id9', NULL, NULL),
(221, 9, 1635091947, '////', 'user', 9, NULL, NULL, 197, 0, NULL, 'komm', NULL),
(222, 9, 1635108065, '', 'user', 9, NULL, 108, NULL, 0, 'id9', NULL, NULL),
(224, 9, 1635156181, '', 'user', 9, NULL, NULL, 223, 0, NULL, 'komm', NULL),
(225, 9, 1635196536, '', 'user', 9, NULL, NULL, 222, 0, NULL, 'komm', NULL),
(226, 9, 1635196667, '', 'user', 9, NULL, NULL, 5, 0, 'video9_5', 'video', NULL),
(2232, 9, 1635279351, '', 'user', 9, NULL, NULL, 133, 0, NULL, 'komm', NULL),
(2235, 9, 1635928988, 'Ну и где?', 'user', 1, NULL, NULL, NULL, 0, 'id1', NULL, NULL),
(2236, 9, 1636143921, '', 'user', 9, NULL, 9456, NULL, 0, 'id9', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `notes`
--

CREATE TABLE `notes` (
  `id` int(15) NOT NULL,
  `idus` int(15) DEFAULT NULL COMMENT 'ид пользователя',
  `time` int(15) DEFAULT NULL COMMENT 'время создания заметки',
  `name` varchar(100) DEFAULT NULL COMMENT 'название',
  `text` text CHARACTER SET utf8mb4 DEFAULT NULL COMMENT 'текст заметки',
  `chto` varchar(50) DEFAULT NULL COMMENT 'где создана заметка',
  `textobr` text DEFAULT NULL,
  `closewall` int(1) NOT NULL DEFAULT 0,
  `timeread` int(15) DEFAULT NULL COMMENT 'время редактирования'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `notes`
--

INSERT INTO `notes` (`id`, `idus`, `time`, `name`, `text`, `chto`, `textobr`, `closewall`, `timeread`) VALUES
(1, 1, 1635066373, 'Вера', 'Вы знаете этих людей – они возникают всякий раз, когда кто-то из нас предлагает цель или решение. Скептики, материалисты, кухонные интеллигенты, которые не уверены ни в чем, кроме одного: проблемы вечны, мир сложен, все решено за них.\r\n\r\nЭто неверие в возможность менять мир страшнее лени, пьянства или наркомании. Потому что именно оно является их причиной. Часто скепсис подается под видом &quot;опыта&quot;, &quot;знания жизни&quot; или логики; часто камуфлируется словами &quot;это не профессионально&quot;, &quot;так никто не делает&quot; или &quot;так не принято&quot;.\r\n\r\nСегодня мы знаем, что изменить можно все, и каждый из нас обладает возможностью реализовать любую идею. Недавно в центре SCNARC подсчитали, что идее достаточно 10% убежденных сторонников, чтобы сконвертировать остальные 90% общества на свою сторону.\r\n\r\nУбежденных в чем-то людей может быть меньше 10% - 5, 2, даже тысячная процента населения. Но если их вера в успех и преданность идее непоколебимы, им невозможно противостоять.\r\n\r\nВ экстремальном случае для изменений любого масштаба достаточно веры одного человека. Вашей, например.', 'usernotes', 'Вы знаете этих людей – они возникают всякий раз, когда кто-то из нас предлагает цель или решение. Скептики, материалисты, кухонные интеллигенты, которые не уверены ни в чем, кроме одного: проблемы вечны, мир сложен, все решено за них.\r\n\r\nЭто неверие в возможность менять мир страшнее лени, пьянства или наркомании. Потому что именно оно является их причиной. Часто скепсис подается под видом &quot;опыта&quot;, &quot;знания жизни&quot; или логики; часто камуфлируется словами &quot;это не', 0, NULL),
(2, 1, 1635066403, 'Победа!', 'Сегодня в Орландо на ежегодном всемирном чемпионате по программированию (ACM ICPC) российская команда, которая представляет СПбГУ и полностью состоит из сотрудников ВКонтакте, заняла первое место в Европе и четвертое в мире, завоевав золотую медаль. Команда победителей состоит из Алексея Левина, Арсения Смирнова и Валентина Фондаратова – людей, которые подарили нам самообучающийся спам-фильтр, рекомендации в аудиозаписях, возможных друзей, умный подсказчик и многое другое.\r\n\r\nЭто победа в ежегодном многоэтапном соревновании, в котором за весь период отборов участвовало 25 000 человек из 2070 университетов 88 стран мира. Олимпиадное движение по программированию в СПбГУ традиционно курирует Андрей Лопатин при поддержке ВКонтакте. Андрей Лопатин и Николай Дуров, главные технические умы ВКонтакте, в 2000 и 2001 году уже становились абсолютными чемпионами мира ACM ICPC.\r\n\r\nВ этом году остальные золотые медали (1, 2, 3 место) выиграли китайцы и американцы китайского происхождения, но более половины из всех 12 призовых мест снова заняли команды из славянских стран. Команда СПбГУ получила золотую медаль за 4ое место, на 5м месте – команда из Нижнего Новгорода, на 6м – из Саратова, на 8м – из Донецка (серебро), на 10м – из Москвы, на 11м – с Урала (бронза).\r\n\r\nМы снова убеждаемся в том, что в России, Украине и Беларуси живут одни из самых умных людей в мире. Поздравляю победителей и желаю дальнейших подвигов!', 'usernotes', 'Сегодня в Орландо на ежегодном всемирном чемпионате по программированию (ACM ICPC) российская команда, которая представляет СПбГУ и полностью состоит из сотрудников ВКонтакте, заняла первое место в Европе и четвертое в мире, завоевав золотую медаль. Команда победителей состоит из Алексея Левина, Арсения Смирнова и Валентина Фондаратова – людей, которые подарили нам самообучающийся спам-фильтр, рекомендации в аудиозаписях, возможных друзей, умный подсказчик и многое другое.\r\n\r\nЭто победа в', 0, NULL),
(5, 1, 1635073041, 'Лучший путь – Ваш собственный', 'Помните те случаи, когда Ваше мнение шло полностью вразрез с мнением окружающих? Это – самые ценные моменты, в которые нужно вцепляться мертвой хваткой. Мир вокруг нас развивается так быстро, что общепринятые убеждения на наших глазах становятся издевательством над здравым смыслом. Сопротивление шума вокруг – устойчивый ориентир для всех желающих внести весомый вклад в развитие человечества. Слушать внутренний голос не означает оставаться глухим к мнению окружающих. Однако забудьте про демократию среди тех, кто Вас окружает, – голос деятельного мыслителя, меняющего мир, должен быть для Вас стократ более значим, чем голос праздного обывателя с его правом на мнение. Но менее значим, чем Ваш собственный. Ваша вера в возможность иного пути намного важнее для человечества и для всех нас, чем Ваше умение приспосабливаться и вторить безличному эху конформистов.', 'usernotes', 'Помните те случаи, когда Ваше мнение шло полностью вразрез с мнением окружающих? Это – самые ценные моменты, в которые нужно вцепляться мертвой хваткой. Мир вокруг нас развивается так быстро, что общепринятые убеждения на наших глазах становятся издевательством над здравым смыслом. Сопротивление шума вокруг – устойчивый ориентир для всех желающих внести весомый вклад в развитие человечества. Слушать внутренний голос не означает оставаться глухим к мнению окружающих. Однако забудьте про', 0, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `photo`
--

CREATE TABLE `photo` (
  `id` int(15) NOT NULL,
  `idus` int(15) DEFAULT NULL COMMENT 'ид пльзователя',
  `id_album` int(15) DEFAULT NULL COMMENT 'ид альбома',
  `name` varchar(200) DEFAULT NULL COMMENT 'название',
  `time` int(15) DEFAULT NULL COMMENT 'время',
  `opis` varchar(200) DEFAULT NULL COMMENT 'описание',
  `photo` varchar(100) DEFAULT NULL COMMENT 'ссылка на фото',
  `chto` varchar(100) DEFAULT NULL COMMENT 'чья фотография',
  `ids` int(15) DEFAULT NULL COMMENT 'откуда фото',
  `closewall` int(1) NOT NULL DEFAULT 0 COMMENT 'закрыты ли комментарии',
  `razr` varchar(50) DEFAULT NULL COMMENT 'разрешение фотографии'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `photo`
--

INSERT INTO `photo` (`id`, `idus`, `id_album`, `name`, `time`, `opis`, `photo`, `chto`, `ids`, `closewall`, `razr`) VALUES
(6, 2, 3, 'Фотография на аватар', 1634501039, 'Фотография на аватар', 'vkphp.ru_2531634501039.jpg', 'user', NULL, 1, NULL),
(10, 1, 0, 'Фотография со стены', 1634542016, 'Фотография со стены', 'vkphp.ru_141081634542016.jpg', 'photo', 20, 0, NULL),
(11, 1, 0, 'Фотография со стены', 1634542081, 'Фотография со стены', 'vkphp.ru_825311634542081.jpg', 'photo', 21, 0, NULL),
(12, 1, 0, 'Фотография со стены', 1634542102, 'Фотография со стены', 'vkphp.ru_384001634542102.jpg', 'photo', 22, 0, NULL),
(23, 1, 0, 'Фотография со стены', 1634586866, 'Фотография со стены', 'vkphp.ru_67521634586866.jpg', 'photo', 44, 0, NULL),
(25, 1, 0, 'Фотография со стены', 1634586934, 'Фотография со стены', 'vkphp.ru_109011634586934.jpg', 'photo', 46, 0, NULL),
(27, 1, 0, 'Фотография со стены', 1634587068, 'Фотография со стены', 'vkphp.ru_637381634587068.jpg', 'photo', 48, 0, NULL),
(50, 2, 8, 'Фотография в альбом', 1634653387, 'Фотография в альбом', 'vkphp.ru_754581634653387.jpg', 'user', NULL, 1, 'jpg'),
(88, 7, 17, 'Фотография на аватар', 1634978572, 'Фотография на аватар', 'vkphp.ru_6588981634978572.jpg', 'user', NULL, 0, 'jpg'),
(90, 7, 18, 'Фотография со стены', 1634992721, 'Фотография со стены', 'vkphp.ru_859821634992721.jpg', 'user', 154, 0, 'jpg'),
(91, 7, 18, 'Фотография со стены', 1634995528, 'Фотография со стены', 'vkphp.ru_301671634995528.png', 'user', 159, 0, 'png'),
(96, 10, 23, 'Фотография на аватар', 1635087605, 'Фотография на аватар', 'vkphp.ru_3362771635087605.jpg', 'user', NULL, 0, 'jpg'),
(97, 9, 21, 'Фотография на аватар', 1635087762, 'Фотография на аватар', 'vkphp.ru_495601635087762.jpeg', 'user', NULL, 1, 'jpeg'),
(100, 9, 0, 'Фотография со стены', 1635087856, 'Фотография со стены', 'vkphp.ru_117951635087856.png', 'userwallkomm', 196, 0, NULL),
(105, 1, 26, 'Фотография в альбом', 1635092381, 'Фотография в альбом', 'vkphp.ru_9431041635092381.jpg', 'user', NULL, 0, 'jpg'),
(106, 9, 25, 'Фотография в альбом', 1635092677, 'Фотография в альбом', 'vkphp.ru_2170661635092677.png', 'user', NULL, 0, 'png'),
(107, 9, 25, 'Фотография в альбом', 1635092702, 'Фотография в альбом', 'vkphp.ru_1532781635092702.png', 'user', NULL, 0, 'png'),
(9452, 1, 1, 'Фотография на аватар', 1635356689, 'Фотография на аватар', 'vkphp.ru_5375461635356689.jpg', 'user', NULL, 0, 'jpg'),
(9453, 1, 1, 'Фотография на аватар', 1635356737, 'Фотография на аватар', 'vkphp.ru_2422421635356737.jpg', 'user', NULL, 0, 'jpg'),
(9454, 11, 28, 'Фотография со стены', 1635706363, 'Фотография со стены', 'vkphp.ru_781771635706362.jpg', 'user', 2233, 0, 'jpg'),
(9455, 11, 28, 'Фотография со стены', 1635726922, 'Фотография со стены', 'vkphp.ru_637101635726922.jpg', 'user', 2234, 0, 'jpg'),
(9456, 9, 22, 'Фотография со стены', 1636143921, 'Фотография со стены', 'vkphp.ru_799001636143921.jpeg', 'user', 2236, 0, 'jpeg');

-- --------------------------------------------------------

--
-- Структура таблицы `url`
--

CREATE TABLE `url` (
  `id` int(15) NOT NULL,
  `chto` varchar(50) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `ads` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `url`
--

INSERT INTO `url` (`id`, `chto`, `url`, `ads`) VALUES
(1, 'user', 'truniov', 1),
(2, 'user', 'ad', 2),
(3, 'user', 'syka', 7),
(4, 'user', 'id8', 8),
(5, 'user', 'Romka', 9),
(6, 'user', 'id10', 10),
(7, 'user', 'Xaotik', 11),
(8, 'user', 'id12', 12),
(9, 'user', 'id13', 13);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(15) NOT NULL,
  `name` varchar(100) DEFAULT NULL COMMENT 'имя',
  `fame` varchar(100) DEFAULT NULL COMMENT 'фамилия',
  `sex` int(1) NOT NULL DEFAULT 2 COMMENT 'пол',
  `dayr` date DEFAULT NULL COMMENT 'день рождения',
  `email` varchar(100) DEFAULT NULL COMMENT 'емайл',
  `datareg` int(15) DEFAULT NULL COMMENT 'дата регистрации',
  `datalast` int(15) DEFAULT NULL COMMENT 'время последнего захода',
  `password` text DEFAULT NULL,
  `token` text DEFAULT NULL,
  `lvl` int(3) NOT NULL DEFAULT 1 COMMENT 'уровень',
  `ver` int(1) NOT NULL DEFAULT 0 COMMENT 'верификация',
  `rate` int(3) DEFAULT 30,
  `status` varchar(190) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT 'статус',
  `city` varchar(100) DEFAULT NULL COMMENT 'Родной город',
  `marialstatus` int(1) DEFAULT 0 COMMENT 'семейное положение',
  `nickname` varchar(100) DEFAULT NULL COMMENT 'никнейм',
  `politviews` int(1) NOT NULL DEFAULT 0 COMMENT 'политические взгялды',
  `email2` varchar(100) DEFAULT NULL COMMENT 'email контактный',
  `telegram` varchar(100) DEFAULT NULL COMMENT 'телеграмм',
  `adress` varchar(100) DEFAULT NULL COMMENT 'адресс',
  `interests` varchar(200) DEFAULT NULL,
  `lovemusic` varchar(200) DEFAULT NULL,
  `lovemovie` varchar(200) DEFAULT NULL,
  `lovetvshow` varchar(200) DEFAULT NULL,
  `lovebook` varchar(200) DEFAULT NULL,
  `lovecit` varchar(200) DEFAULT NULL,
  `osebe` varchar(200) DEFAULT NULL,
  `avatar` int(15) DEFAULT NULL COMMENT 'ид аватара',
  `updatedei` int(15) DEFAULT 0 COMMENT 'обновление действий',
  `closewall` int(1) NOT NULL DEFAULT 0 COMMENT 'закрыта ли стена',
  `audioupd` int(15) DEFAULT NULL COMMENT 'что за музыка id',
  `timeaudioupd` int(15) DEFAULT NULL COMMENT 'когда слушал',
  `gorate` int(15) NOT NULL DEFAULT 100 COMMENT 'сколько до следующего рейтинга',
  `url` varchar(50) DEFAULT NULL,
  `bot` int(1) NOT NULL DEFAULT 0 COMMENT 'бот или нет',
  `ref` int(15) DEFAULT NULL COMMENT 'кто пригласил',
  `invite` varchar(100) DEFAULT NULL,
  `eyevideo` int(1) NOT NULL DEFAULT 1 COMMENT 'Кому видно мои видеозаписи',
  `eyenotes` int(1) NOT NULL DEFAULT 1 COMMENT 'Кому видно мои заметки',
  `timeban` int(15) DEFAULT NULL COMMENT 'если бан то до скольки',
  `naskokban` int(15) DEFAULT 15 COMMENT 'на сколько бан'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `name`, `fame`, `sex`, `dayr`, `email`, `datareg`, `datalast`, `password`, `token`, `lvl`, `ver`, `rate`, `status`, `city`, `marialstatus`, `nickname`, `politviews`, `email2`, `telegram`, `adress`, `interests`, `lovemusic`, `lovemovie`, `lovetvshow`, `lovebook`, `lovecit`, `osebe`, `avatar`, `updatedei`, `closewall`, `audioupd`, `timeaudioupd`, `gorate`, `url`, `bot`, `ref`, `invite`, `eyevideo`, `eyenotes`, `timeban`, `naskokban`) VALUES
(1, 'Михаил', 'Трунев', 1, '1995-03-29', '3020@3020.ru', 1634320259, 1636188660, '$2y$10$RWRYMU.Fe63ozUM.ERtsH.9kCgt6uaT/qxXyNxurDz96b44mh.dkK', '$2y$10$.LxZowIs/nvzLRmqO0BQ8eiNy58ebcnmO6ehM7Hiy5DS5vwNGcAnW', 100, 1, 98, 'Случайностей не бывает.', 'Санкт-Петербург', 4, NULL, 7, 'swicee65@gmail.com', 'flowap', 'Улица пушкина, дом колотушкина', 'Рисование линий', 'Тишина', NULL, NULL, NULL, 'Дорога возникает под шагами идущего.', 'VK, NWO', 9453, 0, 0, 6, 1636188372, 200, 'truniov', 1, NULL, 'lpqbwg4j8570zmk', 1, 1, NULL, 15),
(2, 'Bot', 'Bot', 2, '1995-03-29', 'wapxak@yandex.ru', 1634393301, 1636188602, '$2y$10$d62nljewgKiJw81kNTDOi.hMZCacYpoil2u5SvaOUJMMpmukZTiOm', '$2y$10$c6frHeWmdoXWcfdPTouNeeH/hcky.UHdsOs/kFpraVng0Kv.frRiW', 1, 0, 30, 'Ля, не пишите мне и так заебали', NULL, 0, 'Bot', 9, NULL, 'admin', NULL, 'готика, кладбища, вампиры, ночь, холод, снег, цвет мрака, волки, красное вино, бисексуализм, психология, суицид, bdsm, мистика', 'Kevin McLeod', 'The Heathers (1988), Riddle of the Rocks (2018)', 'ненавижу Дом-2', 'Мiсто', '&quot;I&#039;d just like to interject for a moment. What you&#039;re referring to as Linux, is in fact, GNU/Linux, or as I&#039;ve recently taken to calling it, GNU plus Linux.&quot;', NULL, 6, 0, 1, NULL, NULL, 100, 'ad', 1, NULL, NULL, 1, 1, NULL, 15),
(5, 'Lindsey', 'Stirling', 1, '0000-00-00', NULL, 1634757727, 1634757727, NULL, NULL, 1, 0, 30, NULL, '', 0, NULL, 0, NULL, NULL, NULL, 'Family, Friends, Dancing, Music', 'David Garrett, Bond, Barrage, Michael Jackson, electronic, etc.  I like songs from all types and genres of uplifting music except \"country western\" and \"heavy metal.\"  Sheet Music/mp3 http://lindseyst', 'Anne of Green Gables, That\'s Dancing, Freedom Writers  My \"Movies:\" http://www.youtube.com/user/lindseystomp http://www.youtube.com/user/lindseytime', NULL, NULL, 'If we did all the things we are capable of, we would literally astound ourselves.\n-Thomas Edison\n', NULL, NULL, 0, 0, NULL, NULL, 100, 'id5', 0, NULL, NULL, 1, 1, NULL, 15),
(6, 'Diana', 'Marinskaya', 1, '0000-00-00', NULL, 1634757877, 1634757877, NULL, NULL, 1, 0, 30, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 100, 'id6', 0, NULL, NULL, 1, 1, NULL, 15),
(9, 'Ромка', 'Бойчук', 1, '2003-05-02', 'mrromanko.br@gmail.com', 1635087249, 1636143935, '$2y$10$eC0c/rNTeg2.3zK0NhNXi.V50Wpii.Rj3HiDhAWCLRsXko3Tnjdg6', '$2y$10$9E9CL6PiFtkJxEMRWdIq2O7garznzdAdS7BG76Tef1p2yuLSC3X06', 1, 0, 30, 'Нюхай бебру', 'Луцьк', 0, 'Romka', 0, 'test@mail.com', 'mr_Romanko', 'Улица скварцова, дом пездицова', 'Порно', 'Лол', 'Кек', 'Чебурек', 'Книга', 'Хуй пизда сковорода', 'Ахуенный', 97, 0, 0, 7, 1635097518, 100, 'Romka', 0, NULL, 'gsdnbykezhf3uw6', 1, 1, NULL, 15),
(10, 'Максим', 'Μакаров', 1, '1996-07-07', 'vk@vk.ru', 1635087421, 1636188483, '$2y$10$H.rMtTBsrhyFhTVGryY1gezZMQPcFdKCfaSOjHvNfxcPjn.p5qsf2', '$2y$10$Zo9grplehGRDHxW89nclEeHS2ZgFgeKYWsTVf/S3E5jZhCNiWQaeS', 1, 0, 30, 'Ну просто так', NULL, 2, NULL, 1, NULL, NULL, NULL, 'Программирование', NULL, NULL, NULL, NULL, NULL, NULL, 96, 0, 0, NULL, NULL, 100, 'id10', 1, NULL, '2yat0denj8g3ui7', 1, 1, NULL, 15),
(11, 'Сергей', 'Туманов', 1, '2021-10-15', 'Xaotik1998@gmail.com', 1635197166, 1635975660, '$2y$10$TfKjHlQAaMPGCOj8tW18suzC6k.TEq7BvV.FXWc0dAII.PeSUG4NG', '$2y$10$A.ssCvYkITH0MeQ16BxVt.sRkdzqFpgmrnOWq8lwux11rhhNLsNPW', 1, 0, 30, 'Ыыыыыыыыыыыы', NULL, 0, 'Xaotik', 0, NULL, 'Xaotik', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 8, 1635254887, 100, 'Xaotik', 0, NULL, 'shwki13yteluv6b', 1, 1, NULL, 15),
(12, 'Вася', 'Чанский', 1, '1996-09-04', 'slowmrzlo@gmail.com', 1635250515, 1635309990, '$2y$10$TWNnjV0G9QW2FnNrVfB7eutpoAbIfjZDf8ikyawI7BtyTfEM1/syC', '$2y$10$B7p6W8ItUiJIPrXcJZiSb.f4sn6tKaM4h2hIoPe0tTZEp1VG2DkH2', 1, 0, 30, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 100, 'id12', 0, NULL, '01aly3fxbeu8z4n', 1, 1, NULL, 15),
(13, 'testa', 'testa', 2, '1111-03-29', '3020@3020300.ru', 1636188630, 1636188630, '$2y$10$RWRYMU.Fe63ozUM.ERtsH.9kCgt6uaT/qxXyNxurDz96b44mh.dkK', '$2y$10$EGsjTEbObPl4r.yh7T6UgOoOZH6Gk/qBeR2TaLp519qted2h5eSGu', 1, 0, 30, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 100, 'id13', 0, NULL, 'x1g42usv9kywcnl', 1, 1, NULL, 15);

-- --------------------------------------------------------

--
-- Структура таблицы `video`
--

CREATE TABLE `video` (
  `id` int(15) NOT NULL COMMENT 'ид',
  `idus` int(15) DEFAULT NULL COMMENT 'идюс',
  `chto` varchar(50) DEFAULT NULL COMMENT 'куда',
  `time` int(15) DEFAULT NULL COMMENT 'время',
  `url` text DEFAULT NULL COMMENT 'ссылка',
  `imag` varchar(100) DEFAULT NULL COMMENT 'изображение',
  `name` text CHARACTER SET utf8mb4 DEFAULT NULL COMMENT 'название',
  `opis` text CHARACTER SET utf8mb4 COLLATE utf8mb4_german2_ci DEFAULT NULL COMMENT 'описание'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `video`
--

INSERT INTO `video` (`id`, `idus`, `chto`, `time`, `url`, `imag`, `name`, `opis`) VALUES
(3, 1, 'uservideo', 1634929336, 'BbRanPMUl_A', 'vkphp.ru_350271634929336.jpg', 'Magic Color', 'this magic trick boggles the viewer\'s imagination\n\nhe is simple and brilliant\n\ndifficulty level: simple\n\nsuitable for beginners\n\nbuy 5 $\n\nif you want to buy, write to the mail: mattmellis@icloud.com'),
(5, 9, 'uservideo', 1635196654, 'U57YpwY1hF8', 'vkphp.ru_345961635196654.jpg', 'Barlas & Mert, Emrah Turken - Whiskey & Vodka', '✔ Turn on notifications (🔔) to stay updated with new uploads.\n\n✔ Stream/Download: https://music.soaverecords.com/whiskeyvodka\n\n✔ Follow Car Music\n\nhttps://spoti.fi/2ME34zR​​​​\nhttps://www.facebook.com/CarMusicBB​​\n\n✔ Follow Barlas & Mert\n\nhttps://soundcloud.com/barlasmert \nhttps://www.instagram.com/barlasandmert\n\n✔ Follow Emrah Turken\n\nhttps://instagram.com/emrahturkenmusic\nhttps://soundcloud.com/emrahturkenmusic\n\n---');

-- --------------------------------------------------------

--
-- Структура таблицы `video_us`
--

CREATE TABLE `video_us` (
  `id` int(15) NOT NULL,
  `idus` int(15) DEFAULT NULL,
  `chto` varchar(50) DEFAULT NULL,
  `id_video` int(15) DEFAULT NULL,
  `time` int(15) DEFAULT NULL,
  `imag` varchar(100) DEFAULT NULL,
  `name` text CHARACTER SET utf8mb4 DEFAULT NULL COMMENT 'название',
  `opis` text CHARACTER SET utf8mb4 DEFAULT NULL COMMENT 'описание',
  `closewall` int(1) NOT NULL DEFAULT 0 COMMENT 'закрыты ли комментарии'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `video_us`
--

INSERT INTO `video_us` (`id`, `idus`, `chto`, `id_video`, `time`, `imag`, `name`, `opis`, `closewall`) VALUES
(17, 1, 'uservideo', 3, 1634929336, 'vkphp.ru_350271634929336.jpg', 'Magic Color', 'this magic trick boggles the viewer\'s imagination\n\nhe is simple and brilliant\n\ndifficulty level: simple\n\nsuitable for beginners\n\nbuy 5 $\n\nif you want to buy, write to the mail: mattmellis@icloud.com', 0),
(21, 9, 'uservideo', 5, 1635196654, 'vkphp.ru_345961635196654.jpg', 'Barlas & Mert, Emrah Turken - Whiskey & Vodka', '✔ Turn on notifications (🔔) to stay updated with new uploads.\n\n✔ Stream/Download: https://music.soaverecords.com/whiskeyvodka\n\n✔ Follow Car Music\n\nhttps://spoti.fi/2ME34zR​​​​\nhttps://www.facebook.com/CarMusicBB​​\n\n✔ Follow Barlas & Mert\n\nhttps://soundcloud.com/barlasmert \nhttps://www.instagram.com/barlasandmert\n\n✔ Follow Emrah Turken\n\nhttps://instagram.com/emrahturkenmusic\nhttps://soundcloud.com/emrahturkenmusic\n\n---', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`idus`,`name`,`opis`,`dell`),
  ADD KEY `intr` (`intr`);

--
-- Индексы таблицы `audio`
--
ALTER TABLE `audio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`idus`,`file`,`time`,`name`,`opis`),
  ADD KEY `chto` (`chto`);

--
-- Индексы таблицы `audio_us`
--
ALTER TABLE `audio_us`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`idus`,`id_audio`,`time`),
  ADD KEY `name` (`name`,`opis`);

--
-- Индексы таблицы `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `friends_new`
--
ALTER TABLE `friends_new`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`idus`,`cogo`,`time`,`uved`);

--
-- Индексы таблицы `komm`
--
ALTER TABLE `komm`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`idus`,`time`,`chto`),
  ADD KEY `ids` (`ids`),
  ADD KEY `otv` (`otv`),
  ADD KEY `images` (`images`),
  ADD KEY `repost` (`repost`,`zakrep`),
  ADD KEY `url` (`url`),
  ADD KEY `repostchto` (`repostchto`);

--
-- Индексы таблицы `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`idus`,`time`,`name`),
  ADD KEY `chto` (`chto`),
  ADD KEY `closewall` (`closewall`,`timeread`);

--
-- Индексы таблицы `photo`
--
ALTER TABLE `photo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`idus`,`id_album`,`name`,`time`,`opis`),
  ADD KEY `photo` (`photo`),
  ADD KEY `chto` (`chto`,`ids`,`closewall`);

--
-- Индексы таблицы `url`
--
ALTER TABLE `url`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`chto`,`url`),
  ADD KEY `ads` (`ads`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`name`,`fame`,`sex`,`dayr`,`email`),
  ADD KEY `datareg` (`datareg`),
  ADD KEY `datalast` (`datalast`),
  ADD KEY `lvl` (`lvl`,`ver`),
  ADD KEY `rate` (`rate`),
  ADD KEY `status` (`status`),
  ADD KEY `marialstatus` (`marialstatus`,`nickname`),
  ADD KEY `politviews` (`politviews`),
  ADD KEY `city` (`city`),
  ADD KEY `email2` (`email2`,`telegram`,`adress`),
  ADD KEY `osebe` (`osebe`),
  ADD KEY `lovecit` (`lovecit`),
  ADD KEY `lovebook` (`lovebook`),
  ADD KEY `lovetvshow` (`lovetvshow`),
  ADD KEY `lovemovie` (`lovemovie`),
  ADD KEY `lovemusic` (`lovemusic`),
  ADD KEY `interests` (`interests`),
  ADD KEY `avatar` (`avatar`),
  ADD KEY `updatedei` (`updatedei`),
  ADD KEY `closewall` (`closewall`),
  ADD KEY `audioupd` (`audioupd`,`timeaudioupd`),
  ADD KEY `gorate` (`gorate`),
  ADD KEY `url` (`url`,`bot`),
  ADD KEY `ref` (`ref`),
  ADD KEY `invite` (`invite`,`eyevideo`,`eyenotes`),
  ADD KEY `timeban` (`timeban`);

--
-- Индексы таблицы `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`idus`,`chto`,`time`,`imag`);

--
-- Индексы таблицы `video_us`
--
ALTER TABLE `video_us`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`idus`,`chto`,`id_video`,`time`),
  ADD KEY `closewall` (`closewall`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `album`
--
ALTER TABLE `album`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT для таблицы `audio`
--
ALTER TABLE `audio`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT COMMENT 'ид', AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `audio_us`
--
ALTER TABLE `audio_us`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT COMMENT 'ид', AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT для таблицы `friends_new`
--
ALTER TABLE `friends_new`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT для таблицы `komm`
--
ALTER TABLE `komm`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2237;

--
-- AUTO_INCREMENT для таблицы `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `photo`
--
ALTER TABLE `photo`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9457;

--
-- AUTO_INCREMENT для таблицы `url`
--
ALTER TABLE `url`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `video`
--
ALTER TABLE `video`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT COMMENT 'ид', AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `video_us`
--
ALTER TABLE `video_us`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
