<?php
$dir = isset($_GET['dir']) ? $_GET['dir'] : NULL;
$uploaddir = realpath('./') . '/'.$dir;
$total_files = count($_FILES['file']['name']);
for($key = 0; $key < $total_files; $key++) {
	if(isset($_FILES['file']['name'][$key]) && $_FILES['file']['size'][$key] > 0):
		$original_filename = $_FILES['file']['name'][$key];
	  if (move_uploaded_file($_FILES['file']['tmp_name'][$key], $uploaddir . basename($original_filename))) {
	  	$d = ['message' => 'Файлы загружены', 'type' => 'success'];
	  } else {
	    $d = ['message' => 'Файлы не загружены', 'type' => 'success'];
	  }
	endif;
}
echo json_encode($d);exit;
?>
