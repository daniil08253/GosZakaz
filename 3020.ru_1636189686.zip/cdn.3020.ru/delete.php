<?php
define('R', $_SERVER['DOCUMENT_ROOT']);
$file = isset($_GET['dir']) ? trim(htmlspecialchars($_GET['dir'], ENT_QUOTES, 'UTF-8')) : NULL;

if (file_exists(R.$file)) {
	unlink(R.$file);
	$d = ['message' => 'Файл удален', 'type' => 'success'];
} else {
	$d = ['message' => 'Файл не существует', 'type' => 'error'];
}
echo json_encode($d);
exit;
//unlink(R.$file);
//